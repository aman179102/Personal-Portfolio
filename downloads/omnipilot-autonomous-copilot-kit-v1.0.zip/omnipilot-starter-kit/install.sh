#!/usr/bin/env bash
# ==============================================================================
# OmniPilot OS - 1-Click Production Installer & Daemon Setup
# ==============================================================================
set -euo pipefail

COLOR_RESET="\033[0m"
COLOR_CYAN="\033[1;36m"
COLOR_GREEN="\033[1;32m"
COLOR_YELLOW="\033[1;33m"
COLOR_RED="\033[1;31m"

echo -e "${COLOR_CYAN}"
echo "======================================================================"
echo "    🚀 OmniPilot OS: 24/7 Autonomous AI Copilot & Growth Engine       "
echo "    Built for Linux, Cloud VMs & Systems Engineers                   "
echo "======================================================================"
echo -e "${COLOR_RESET}"

INSTALL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${INSTALL_DIR}"

# 1. Check Python
echo -e "${COLOR_YELLOW}[1/5] Checking Python environment...${COLOR_RESET}"
if ! command -v python3 &>/dev/null; then
    echo -e "${COLOR_RED}Error: Python 3 is not installed. Please run: sudo apt install python3 python3-venv python3-pip${COLOR_RESET}"
    exit 1
fi

PY_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo -e "${COLOR_GREEN}✓ Found Python ${PY_VERSION}${COLOR_RESET}"

# 2. Virtual Environment
echo -e "${COLOR_YELLOW}[2/5] Creating dedicated virtualenv (.venv)...${COLOR_RESET}"
if [ ! -d ".venv" ]; then
    python3 -m venv .venv
fi
source .venv/bin/activate
pip install --upgrade pip --quiet
echo -e "${COLOR_GREEN}✓ Virtualenv initialized.${COLOR_RESET}"

# 3. Dependencies
echo -e "${COLOR_YELLOW}[3/5] Installing production requirements...${COLOR_RESET}"
pip install -r requirements.txt --quiet
echo -e "${COLOR_GREEN}✓ All dependencies installed.${COLOR_RESET}"

# 4. Environment Configuration
echo -e "${COLOR_YELLOW}[4/5] Checking environment settings (.env)...${COLOR_RESET}"
if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo -e "${COLOR_GREEN}✓ Created .env from .env.example template.${COLOR_RESET}"
        echo -e "${COLOR_YELLOW}👉 Please edit .env with your Gemini API key and Telegram Bot Token!${COLOR_RESET}"
    fi
else
    echo -e "${COLOR_GREEN}✓ Existing .env file found.${COLOR_RESET}"
fi

# 5. Systemd Units Setup
echo -e "${COLOR_YELLOW}[5/5] Configuring systemd 24/7 background daemons...${COLOR_RESET}"
CURRENT_USER=$(whoami)
CURRENT_PATH=$(pwd)

sed -i "s|/home/ubuntu/free-automations|${CURRENT_PATH}|g" systemd/*.service || true
sed -i "s|User=ubuntu|User=${CURRENT_USER}|g" systemd/*.service || true

echo -e "\n${COLOR_CYAN}======================================================================${COLOR_RESET}"
echo -e "${COLOR_GREEN}🎉 OmniPilot OS setup complete!${COLOR_RESET}"
echo -e "======================================================================"
echo -e "Quick Commands:"
echo -e "  • Run Dry-Run Test:        ${COLOR_CYAN}source .venv/bin/activate && python3 main.py --linkedin-radar --dry-run${COLOR_RESET}"
echo -e "  • Start 24/7 Daemon:       ${COLOR_CYAN}source .venv/bin/activate && python3 main.py --daemon --live --interval 15${COLOR_RESET}"
echo -e "  • Start Telegram Bot:      ${COLOR_CYAN}source .venv/bin/activate && python3 -m hermes.poll${COLOR_RESET}"
echo -e "  • Install Systemd:         ${COLOR_CYAN}sudo cp systemd/*.service /etc/systemd/system/ && sudo systemctl daemon-reload${COLOR_RESET}"
echo -e "                             ${COLOR_CYAN}sudo systemctl enable --now free-automations.service hermes.service${COLOR_RESET}"
echo -e "======================================================================\n"
