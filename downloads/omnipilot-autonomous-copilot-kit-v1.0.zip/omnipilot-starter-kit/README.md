# 🚀 OmniPilot OS: 24/7 Autonomous AI Copilot & Multi-Platform Growth Engine

> **Production-grade autonomous growth engine and multi-platform AI copilot for engineers, creators, and agency founders.**  
> Runs continuously 24/7 on Linux/Cloud VMs with **$0/month infrastructure cost** and **100% free-tier APIs**.

---

## ⚡ What is OmniPilot OS?

OmniPilot is an end-to-end autonomous software system designed to build technical brand authority, drive high-intent engineering traffic, and streamline engagement across major developer networks:

1. **LinkedIn 1-Tap Mobile Copilot**:
   - Analyzes real engineering discussions dynamically.
   - Generates warm, conversational, human comments (35–75 words) that add substantive technical nuance.
   - Dispatches instant 1-tap alerts to your private Telegram bot with `<code>` auto-copy and direct 1-click links to the exact post.
   - **Zero 404s & Never redirects to search result pages.**
2. **Quora 1-Click Direct Answer Engine**:
   - Generates authoritative, deeply structured technical answers across Systems Architecture, Python, Linux, and Databases.
   - Automatically injects canonical portfolio backlinks (1-in-3 safety cadence).
   - Provides direct `/answer` slug URLs that open Quora's native Answer Editor modal immediately.
3. **Hermes On-Demand Telegram Cockpit**:
   - Send or forward ANY LinkedIn post or Quora question to your private Telegram bot on the go.
   - The bot reads the exact text/URL and replies in 2 seconds with a custom high-signal response ready to paste.
4. **24/7 Self-Healing Systemd Daemons**:
   - Operates in background as modern Linux systemd services.
   - Low resource footprint (<60 MB RAM total).
   - Automated error recovery, round-robin multi-key Gemini failover, and rate-limit backoff.

---

## 💰 Architecture & Zero-Cost Stack

| Component | Technology | Monthly Cost |
| :--- | :--- | :--- |
| **Compute & Host** | Oracle Cloud Always-Free Compute (or AWS Free Tier / Local Ubuntu) | **$0.00 / month** |
| **LLM Engine** | Google Gemini 2.5/3.5 Flash via AI Studio | **$0.00 / month** |
| **Mobile Interface** | Telegram Bot API (via HTTPS Long Polling) | **$0.00 / month** |
| **State Persistence** | Atomic JSON File Engine with Daily Wave Tracking | **$0.00 / month** |
| **Total Operating Cost** | | **$0.00 / month** |

---

## 📦 Quick Start (3 Steps)

### Step 1: Run the 1-Click Installer
```bash
git clone <your-repo> omnipilot
cd omnipilot
./install.sh
```

### Step 2: Configure `.env`
Edit `.env` with your free Google Gemini API key and Telegram Bot token:
```ini
GEMINI_API_KEY=your_gemini_api_key_here
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrSTUvwxYZ
TELEGRAM_CHAT_ID=your_telegram_user_id
```

### Step 3: Run & Verify
```bash
# Test simulated alert output
source .venv/bin/activate
python3 main.py --linkedin-radar --dry-run
python3 main.py --quora-radar --dry-run

# Start live daemon
python3 main.py --daemon --live --interval 15
```

---

## 🛠️ Deploy as a 24/7 Background Service (Systemd)

To make OmniPilot run non-stop in the background even when you log off:

```bash
sudo cp systemd/*.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now free-automations.service hermes.service

# Check live status
systemctl status free-automations.service hermes.service
```

---

## 📚 Documentation
- See `DEPLOYMENT_ORACLE_FREE_TIER.md` for a complete step-by-step walkthrough on setting up an Oracle Cloud Always-Free VM for 24/7 autonomous operation.
- See `LICENSE.md` for commercial licensing terms.

---

© 2026 Aman Kumar (@aman179102). All rights reserved.
