"""Hermes FastAPI server: health endpoint + Telegram webhook. Render-ready."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from hermes.config import Settings, settings
from hermes.instagram.buffer_publisher import BufferInstagramPublisher
from hermes.meme.provider import MemeApiProvider
from hermes.storage.database import PendingStore
from hermes.telegram.bot import TelegramBot
from hermes.telegram.handlers import HandlerDeps, handle_update

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s: %(message)s")
log = logging.getLogger("hermes.app")


def build_app(cfg: Settings | None = None) -> FastAPI:
    cfg = cfg or settings
    store = PendingStore(cfg.db_path)
    bot = TelegramBot(cfg.telegram_bot_token)
    memes = MemeApiProvider(api_url=cfg.meme_api_url, timeout=cfg.http_timeout)
    # Buffer-backed official safe publisher
    publisher = BufferInstagramPublisher()
    deps = HandlerDeps(settings=cfg, bot=bot, memes=memes, publisher=publisher, store=store)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        log.info("Hermes starting (db=%s, ig_mode=%s)", cfg.db_path, cfg.instagram_mode)
        yield
        log.info("Hermes shutting down")

    app = FastAPI(title="Hermes", lifespan=lifespan)
    app.state.deps = deps
    app.state.settings = cfg

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/")
    async def root():
        return {"service": "hermes", "status": "ok"}

    @app.post("/telegram/webhook")
    async def telegram_webhook(request: Request):
        # Optional shared-secret check: Telegram allows a secret_token on setWebhook;
        # we accept it as ?secret= or X-Telegram-Bot-Api-Secret-Token header.
        if cfg.telegram_webhook_secret:
            provided = request.query_params.get("secret", "") or request.headers.get(
                "x-telegram-bot-api-secret-token", ""
            )
            if provided != cfg.telegram_webhook_secret:
                return JSONResponse({"ok": False, "error": "forbidden"}, status_code=403)
        try:
            update = await request.json()
        except Exception:
            return JSONResponse({"ok": False, "error": "invalid JSON"}, status_code=400)
        try:
            await handle_update(update, deps)
        except Exception:
            log.exception("error handling Telegram update")
        # Always 200 so Telegram doesn't retry a poisoned update forever.
        return {"ok": True}

    return app


app = build_app()
