"""Meme provider abstraction + default public-API implementation.

Default source: https://meme-api.com/gimme (no API key, public Reddit memes).
Swap it later by subclassing MemeProvider — the bot only depends on the
base class interface.
"""
from __future__ import annotations

import asyncio
import logging
import random
from urllib.parse import urlparse

import httpx

from .models import Meme

log = logging.getLogger("hermes.meme")

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".gif"}
MAX_IMAGE_BYTES = 10 * 1024 * 1024  # 10 MB
DEV_SUBREDDITS = ["ProgrammerHumor", "linuxmemes", "wholesomememes", "devhumor"]


class MemeFetchError(Exception):
    """Raised when a random meme cannot be retrieved/validated."""


class MemeProvider:
    """Interface. Subclass and override get_random_meme()."""

    async def get_random_meme(self) -> Meme:
        raise NotImplementedError


def _looks_like_image_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
    except Exception:
        return False
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return False
    path = parsed.path.lower()
    return any(path.endswith(ext) for ext in ALLOWED_EXTENSIONS)


class MemeApiProvider(MemeProvider):
    """Fetches random memes from meme-api.com with validation + retries."""

    def __init__(
        self,
        api_url: str = "https://meme-api.com/gimme",
        timeout: float = 10.0,
        max_retries: int = 3,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.api_url = api_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client = client  # injectable for tests

    def _client_ctx(self) -> httpx.AsyncClient:
        if self._client is not None:
            return self._client
        return httpx.AsyncClient(timeout=self.timeout, follow_redirects=True)

    async def get_random_meme(self, subreddit: str | None = None) -> Meme:
        last_err: Exception | None = None
        client = self._client_ctx()
        owns_client = self._client is None
        try:
            for attempt in range(1, self.max_retries + 1):
                try:
                    meme = await self._fetch_once(client, subreddit=subreddit)
                    await self._verify_image(client, meme.image_url)
                    return meme
                except MemeFetchError as e:
                    last_err = e
                    log.warning("meme fetch attempt %d/%d failed: %s", attempt, self.max_retries, e)
                    if attempt < self.max_retries:
                        await asyncio.sleep(0.5 * attempt)
        finally:
            if owns_client:
                await client.aclose()
        raise MemeFetchError(f"Could not fetch a valid meme after {self.max_retries} tries: {last_err}")

    async def _fetch_once(self, client: httpx.AsyncClient, subreddit: str | None = None) -> Meme:
        url = self.api_url
        if subreddit:
            url = f"{self.api_url}/{subreddit.lstrip('/')}"
        elif self.api_url.endswith("/gimme"):
            sub = random.choice(DEV_SUBREDDITS)
            url = f"{self.api_url}/{sub}"

        try:
            resp = await client.get(url, timeout=self.timeout)
        except (httpx.TimeoutException, httpx.NetworkError) as e:
            raise MemeFetchError(f"meme API unreachable: {type(e).__name__}") from e
        if resp.status_code != 200:
            raise MemeFetchError(f"meme API returned HTTP {resp.status_code}")
        try:
            data = resp.json()
        except Exception as e:
            raise MemeFetchError("meme API returned malformed (non-JSON) response") from e
        if not isinstance(data, dict):
            raise MemeFetchError("meme API returned malformed response")
        image_url = data.get("url", "")
        if not isinstance(image_url, str) or not image_url:
            raise MemeFetchError("meme API response has no image URL")
        if not _looks_like_image_url(image_url):
            raise MemeFetchError(f"meme API returned unsupported image URL: {image_url[:80]}")
        title = data.get("title", "") if isinstance(data.get("title"), str) else ""
        post = data.get("postLink", "") if isinstance(data.get("postLink"), str) else ""
        sub = data.get("subreddit", "") if isinstance(data.get("subreddit"), str) else ""
        return Meme(title=title, image_url=image_url, source_url=post, subreddit=sub)

    async def _verify_image(self, client: httpx.AsyncClient, url: str) -> None:
        """HEAD-check that the URL really serves an image of sane size."""
        try:
            resp = await client.head(url, timeout=self.timeout)
        except (httpx.TimeoutException, httpx.NetworkError) as e:
            raise MemeFetchError(f"image URL unreachable: {type(e).__name__}") from e
        if resp.status_code >= 400:
            raise MemeFetchError(f"image URL returned HTTP {resp.status_code}")
        ctype = resp.headers.get("content-type", "").split(";")[0].strip().lower()
        if ctype and not ctype.startswith("image/"):
            raise MemeFetchError(f"URL does not serve an image (content-type: {ctype})")
        length = resp.headers.get("content-length")
        if length and length.isdigit() and int(length) > MAX_IMAGE_BYTES:
            raise MemeFetchError("image too large for Instagram/Telegram")
