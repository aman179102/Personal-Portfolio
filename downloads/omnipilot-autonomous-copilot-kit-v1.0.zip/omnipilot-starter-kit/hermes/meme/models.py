"""Meme domain model."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Meme:
    title: str
    image_url: str
    source_url: str = ""
    subreddit: str = ""
