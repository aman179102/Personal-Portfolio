"""Hermes configuration — environment variables only, no hardcoded secrets."""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _load_dotenv(path: str = ".env") -> None:
    """Minimal .env loader (no dependency). Does not override real env vars."""
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key, value = key.strip(), value.strip().strip("'").strip('"')
            if key and key not in os.environ:
                os.environ[key] = value


_load_dotenv()


def _get_int(name: str) -> int | None:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return None
    try:
        return int(raw)
    except ValueError:
        return None


@dataclass
class Settings:
    telegram_bot_token: str = field(default_factory=lambda: os.environ.get("TELEGRAM_BOT_TOKEN", ""))
    telegram_allowed_user_id: int | None = field(default_factory=lambda: _get_int("TELEGRAM_ALLOWED_USER_ID"))
    telegram_webhook_secret: str = field(default_factory=lambda: os.environ.get("TELEGRAM_WEBHOOK_SECRET", ""))
    instagram_access_token: str = field(default_factory=lambda: os.environ.get("INSTAGRAM_ACCESS_TOKEN", ""))
    instagram_user_id: str = field(default_factory=lambda: os.environ.get("INSTAGRAM_USER_ID", ""))
    instagram_sessionid: str = field(default_factory=lambda: os.environ.get("INSTAGRAM_SESSIONID", ""))
    instagram_csrf: str = field(default_factory=lambda: os.environ.get("INSTAGRAM_CSRFTOKEN", ""))
    public_base_url: str = field(default_factory=lambda: os.environ.get("PUBLIC_BASE_URL", ""))
    db_path: str = field(default_factory=lambda: os.environ.get("DB_PATH", "data/hermes.db"))
    port: int = field(default_factory=lambda: int(os.environ.get("PORT", "8000")))
    meme_api_url: str = field(default_factory=lambda: os.environ.get("MEME_API_URL", "https://meme-api.com/gimme"))
    http_timeout: float = 10.0

    @property
    def instagram_configured(self) -> bool:
        return True

    @property
    def instagram_mode(self) -> str:
        if self.instagram_sessionid:
            return "session"
        if self.instagram_access_token and self.instagram_user_id:
            return "graph"
        return "buffer"


settings = Settings()
