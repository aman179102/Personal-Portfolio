"""Hermes Telegram long-polling daemon.

Runs 24/7 on private VPS / VM without needing public webhooks, domains, or open ports.
"""
from __future__ import annotations

import asyncio
import logging
import signal
import sys

import httpx

from hermes.app import build_app
from hermes.config import settings
from hermes.telegram.handlers import handle_update

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("hermes.poll")


async def run_polling() -> None:
    if not settings.telegram_bot_token:
        log.error("TELEGRAM_BOT_TOKEN is not configured.")
        sys.exit(1)

    app = build_app(settings)
    deps = app.state.deps
    bot = deps.bot

    log.info(
        "Hermes Polling Engine initialized (allowed_user=%s, ig_mode=%s)",
        settings.telegram_allowed_user_id,
        settings.instagram_mode,
    )

    # Remove webhook if previously set so Telegram routes to getUpdates
    del_res = await bot._post("deleteWebhook", {"drop_pending_updates": False})
    log.info("deleteWebhook response: %s", del_res.get("description", "ok"))

    offset = 0
    stop_event = asyncio.Event()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except (NotImplementedError, RuntimeError):
            pass

    async with httpx.AsyncClient(timeout=35.0) as client:
        while not stop_event.is_set():
            try:
                resp = await client.post(
                    f"{bot.base_url}/getUpdates",
                    json={
                        "offset": offset,
                        "timeout": 20,
                        "allowed_updates": ["message", "callback_query"],
                    },
                )
                data = resp.json()
            except (httpx.TimeoutException, httpx.NetworkError):
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning("getUpdates transient error (%s): %s", type(e).__name__, e)
                await asyncio.sleep(2)
                continue

            if not data.get("ok"):
                log.warning("getUpdates API error: %s", data)
                await asyncio.sleep(2)
                continue

            updates = data.get("result", [])
            for u in updates:
                offset = max(offset, u["update_id"] + 1)
                try:
                    await handle_update(u, deps)
                except Exception:
                    log.exception("Error handling update ID %s", u.get("update_id"))

    log.info("Hermes Polling daemon stopped cleanly.")


def main() -> None:
    try:
        asyncio.run(run_polling())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
