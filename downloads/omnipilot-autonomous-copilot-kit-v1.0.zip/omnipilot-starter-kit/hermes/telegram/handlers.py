"""Telegram update routing + /meme approval workflow.

Pure logic lives in HandlerDeps-injected functions so tests can pass fakes
without touching the network.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

from hermes.config import Settings
from hermes.instagram.publisher import InstagramPublishError, InstagramPublisher
from hermes.meme.models import Meme
from hermes.meme.provider import MemeFetchError, MemeProvider
from hermes.storage.database import PendingStore
from hermes.telegram.bot import TelegramBot
from hermes.telegram.keyboards import CB_ANOTHER, CB_APPROVE, CB_CANCEL, approval_keyboard

log = logging.getLogger("hermes.handlers")

WELCOME = "👋 Hermes Autonomous Cockpit Online — Aman's Omnichannel Engine.\nUse /help to see all mobile publishing commands."
HELP = (
    "🤖 <b>Hermes Autonomous Cockpit</b> (@aman179102):\n\n"
    "📱 <b>On-Demand Mobile Publishing:</b>\n"
    "• <code>/comment &lt;url or topic&gt;</code> — Generate 1-tap comment for ANY LinkedIn post\n"
    "• <i>(Or simply send any LinkedIn post link directly to this chat!)</i>\n"
    "• <code>/quora &lt;question or url&gt;</code> — Generate 1-tap authoritative Quora answer\n"
    "• <i>(Or simply send any Quora question link directly to this chat!)</i>\n"
    "• <code>/tweet &lt;text&gt;</code> — Instantly publish tweet to X/Twitter\n"
    "• <code>/linkedin &lt;text&gt;</code> — Instantly publish post to LinkedIn\n"
    "• <code>/post &lt;text&gt;</code> — Broadcast to Twitter & LinkedIn\n\n"
    "📸 <b>Instagram Meme Approval:</b>\n"
    "• <code>/meme</code> — Preview top developer meme with 1-tap Approve\n"
    "• <code>/dev</code> — Top ProgrammerHumor meme\n"
    "• <code>/linux</code> — Top linuxmemes meme\n"
    "• <code>/cancel</code> — Discard pending meme\n\n"
    "📊 <b>System & Health:</b>\n"
    "• <code>/status</code> — Daily post limits & engine metrics"
)
UNAUTHORIZED = "⛔ Unauthorized user."
NO_PENDING = "Nothing pending. Use /meme first."
FETCHING = "🎲 Fetching a top developer meme…"
FETCH_FAILED = "❌ Could not fetch a meme right now. Try /meme again in a bit."
CANCELLED = "❌ Cancelled."
APPROVED = "✅ Posted successfully on Instagram."
PREVIEW_CAPTION = "🖼️ {title}\nApprove to post on Instagram, or fetch another."


@dataclass
class HandlerDeps:
    settings: Settings
    bot: TelegramBot
    memes: MemeProvider
    publisher: InstagramPublisher
    store: PendingStore


def is_authorized(user_id: int | None, settings: Settings) -> bool:
    if settings.telegram_allowed_user_id is None:
        return False  # fail-closed: no admin configured => nobody allowed
    return user_id == settings.telegram_allowed_user_id


async def send_meme_preview(chat_id: int, user_id: int, deps: HandlerDeps, subreddit: str | None = None) -> None:
    """Fetch a meme, persist as pending, send preview with buttons."""
    try:
        try:
            meme: Meme = await deps.memes.get_random_meme(subreddit=subreddit)
        except TypeError:
            meme = await deps.memes.get_random_meme()
    except MemeFetchError as e:
        log.warning("meme fetch failed for user %s: %s", user_id, e)
        await deps.bot.send_message(chat_id, f"{FETCH_FAILED}\nReason: {e}")
        return

    sub_tag = f" (r/{meme.subreddit})" if meme.subreddit else ""
    dev_caption = (
        f"{meme.title or 'Relatable dev life'} 💻☕\n\n"
        "Drop a ☕ if you relate.\n"
        ".\n.\n"
        f"#{meme.subreddit.lower() if meme.subreddit else 'dev'} #developer #coderlife #programming #softwareengineer #techmemes #programmerhumor"
    )
    deps.store.save_pending(
        user_id, image_url=meme.image_url, title=dev_caption, source_url=meme.source_url, chat_id=chat_id
    )
    preview_title = f"{meme.title or 'Random dev meme'}{sub_tag}"
    caption = PREVIEW_CAPTION.format(title=preview_title)
    result = await deps.bot.send_photo(chat_id, meme.image_url, caption=caption, reply_markup=approval_keyboard())
    if not result.get("ok"):
        # Telegram couldn't deliver the photo (bad URL etc.) — drop pending state.
        deps.store.clear_pending(user_id)
        await deps.bot.send_message(chat_id, f"{FETCH_FAILED}\nReason: Telegram rejected the image.")


async def handle_message(message: dict, deps: HandlerDeps) -> None:
    chat = message.get("chat", {})
    chat_id = chat.get("id")
    from_user = message.get("from", {})
    user_id = from_user.get("id")
    text = (message.get("text") or "").strip()
    if chat_id is None or user_id is None:
        return

    if not is_authorized(user_id, deps.settings):
        await deps.bot.send_message(chat_id, UNAUTHORIZED)
        return

    command = text.split()[0].split("@")[0] if text.startswith("/") else ""
    if command == "/start":
        await deps.bot.send_message(chat_id, WELCOME)
    elif command == "/help":
        await deps.bot.send_message(chat_id, HELP)
    elif command == "/tweet":
        content = text[len(command):].strip()
        if not content:
            await deps.bot.send_message(chat_id, "ℹ️ <b>Usage:</b> <code>/tweet &lt;your tweet content&gt;</code>")
            return
        await deps.bot.send_message(chat_id, "⏳ Publishing tweet to X via Buffer…")
        try:
            from common.config import load_settings
            from automations.buffer.api import BufferClient
            client = BufferClient(load_settings())
            res = client.post_twitter(content, mode="shareNow")
            post_id = res.get("id", "ok")
            await deps.bot.send_message(chat_id, f"✅ <b>Tweet Live on X!</b>\n\n📝 <i>\"{content}\"</i>\n🆔 ID: <code>{post_id}</code>")
        except Exception as exc:
            log.error("Failed to post tweet via telegram: %s", exc)
            await deps.bot.send_message(chat_id, f"❌ Failed publishing tweet:\n{exc}")
    elif command == "/linkedin":
        content = text[len(command):].strip()
        if not content:
            await deps.bot.send_message(chat_id, "ℹ️ <b>Usage:</b> <code>/linkedin &lt;your post content&gt;</code>")
            return
        await deps.bot.send_message(chat_id, "⏳ Publishing post to LinkedIn via Buffer…")
        try:
            from common.config import load_settings
            from automations.buffer.api import BufferClient
            client = BufferClient(load_settings())
            res = client.post_linkedin(content, mode="shareNow")
            post_id = res.get("id", "ok")
            await deps.bot.send_message(chat_id, f"✅ <b>Post Live on LinkedIn!</b>\n\n📝 <i>\"{content[:150]}...\"</i>\n🆔 ID: <code>{post_id}</code>")
        except Exception as exc:
            log.error("Failed to post to linkedin via telegram: %s", exc)
            await deps.bot.send_message(chat_id, f"❌ Failed publishing to LinkedIn:\n{exc}")
    elif command == "/post":
        content = text[len(command):].strip()
        if not content:
            await deps.bot.send_message(chat_id, "ℹ️ <b>Usage:</b> <code>/post &lt;content to broadcast to Twitter & LinkedIn&gt;</code>")
            return
        await deps.bot.send_message(chat_id, "⏳ Broadcasting post to Twitter & LinkedIn via Buffer…")
        try:
            from common.config import load_settings
            from automations.buffer.api import BufferClient
            client = BufferClient(load_settings())
            client.post_twitter(content, mode="shareNow")
            client.post_linkedin(content, mode="shareNow")
            await deps.bot.send_message(chat_id, f"✅ <b>Broadcast Complete!</b>\nPublished to both Twitter and LinkedIn!\n\n📝 <i>\"{content}\"</i>")
        except Exception as exc:
            log.error("Failed to broadcast via telegram: %s", exc)
            await deps.bot.send_message(chat_id, f"❌ Broadcast failed:\n{exc}")
    elif command == "/status":
        from common.state import load_state
        from pathlib import Path
        state = load_state(Path("state/buffer_state.json"))
        daily = state.get("daily_stats", {})
        status_msg = (
            "📊 <b>Omnichannel Engine Status:</b>\n\n"
            f"📅 <b>Date:</b> {daily.get('date', 'today')}\n"
            f"🐦 <b>X (Twitter):</b> {daily.get('twitter', 0)}/2 posts\n"
            f"💼 <b>LinkedIn:</b> {daily.get('linkedin', 0)}/2 posts\n"
            f"📸 <b>Instagram:</b> {daily.get('instagram', 0)}/2 posts\n\n"
            "🛡️ <b>Provider:</b> Official Buffer API (0% Ban Risk)\n"
            "☁️ <b>Host:</b> Oracle Cloud VM (24/7 Autopilot)"
        )
        await deps.bot.send_message(chat_id, status_msg)
    elif command == "/comment" or "linkedin.com" in text:
        post_url = ""
        for word in text.split():
            if "linkedin.com" in word:
                post_url = word.strip().strip("<>\"'()")
                break

        custom_prompt = text
        if command == "/comment":
            custom_prompt = text[len(command):].strip()

        await deps.bot.send_message(chat_id, "🧠 <i>Analyzing post context & drafting thoughtful comment…</i>")
        try:
            from common.config import load_settings
            from automations.linkedin.content import generate_comment_from_raw_post
            from common.telegram import build_inline_keyboard
            import html

            settings = load_settings()
            comment_text = generate_comment_from_raw_post(custom_prompt, settings)

            if comment_text.startswith("⚠️"):
                failure_msg = (
                    "⚠️ <b>LinkedIn Extraction Restricted (Auth Wall / Private Post)</b>\n"
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    "LinkedIn requires a logged-in session to view this specific post URL.\n\n"
                    "👉 <b>Quick Solution:</b> Copy the post text from your LinkedIn app/browser and <b>paste it directly here</b> — I will analyze it and generate your 1-tap comment instantly!"
                )
                await deps.bot.send_message(chat_id, failure_msg)
                return

            reply_text = (
                "🎯 <b>[LINKEDIN 1-TAP COMMENT READY]</b>\n"
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                "💬 <b>Tap comment below to AUTO-COPY:</b>\n"
                f"<code>{html.escape(comment_text)}</code>\n\n"
                "📲 <i>How to post:</i>\n"
                "1. Tap the code box above 👆 <i>(Auto-copied!)</i>\n"
            )
            buttons = []
            if post_url:
                reply_text += "2. Tap <b>[🚀 Open This Exact Post]</b> below\n3. Paste & post! 🔥"
                buttons.append([{"text": "🚀 Open This Exact Post", "url": post_url}])
            else:
                reply_text += "2. Paste on your target LinkedIn discussion! 🔥"

            buttons.append([{"text": "🌐 Aman's Hub", "url": "https://aman179102.netlify.app"}])
            keyboard = build_inline_keyboard(buttons)

            await deps.bot.send_message(chat_id, reply_text, reply_markup=keyboard)
        except Exception as exc:
            log.error("Failed to generate custom LinkedIn comment: %s", exc)
            await deps.bot.send_message(chat_id, f"❌ Failed generating comment:\n{exc}")
    elif command == "/quora" or "quora.com" in text:
        quora_url = ""
        for word in text.split():
            if "quora.com" in word:
                quora_url = word.strip().strip("<>\"'()")
                break

        question_input = text
        if command == "/quora":
            question_input = text[len(command):].strip()

        await deps.bot.send_message(chat_id, "🧠 <i>Drafting authoritative Quora answer…</i>")
        try:
            from common.config import load_settings
            from automations.quora.content import generate_quora_answer
            from common.telegram import build_inline_keyboard
            import html

            settings = load_settings()
            answer_text = generate_quora_answer(question_input, settings, include_canonical=True)

            reply_text = (
                "💡 <b>[QUORA 1-TAP ANSWER READY]</b>\n"
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                "📝 <b>Tap answer below to AUTO-COPY:</b>\n"
                f"<code>{html.escape(answer_text)}</code>\n\n"
                "📲 <i>How to post in 5 seconds (1-Click Direct Composer):</i>\n"
                "1. Tap the code box above 👆 <i>(Auto-copied!)</i>\n"
            )
            buttons = []
            if quora_url:
                if quora_url.rstrip("/").endswith("/answer"):
                    direct_answer_url = quora_url
                    question_url = quora_url.rstrip("/")[:-7]
                else:
                    direct_answer_url = f"{quora_url.rstrip('/')}/answer"
                    question_url = quora_url

                reply_text += (
                    "2. Tap <b>[✍️ 1-Click Direct Answer on Quora]</b> below <i>(Opens editor directly!)</i>\n"
                    "3. Paste & Submit! 🔥"
                )
                buttons.append([{"text": "✍️ 1-Click Direct Answer on Quora", "url": direct_answer_url}])
                buttons.append([
                    {"text": "❓ View Question Page", "url": question_url},
                    {"text": "📋 Quora Answer Hub", "url": "https://www.quora.com/answer"},
                ])
            else:
                reply_text += "2. Tap <b>[📋 Open Quora Answer Hub]</b> or paste on your target question! 🔥"
                buttons.append([{"text": "📋 Open Quora Answer Hub", "url": "https://www.quora.com/answer"}])

            buttons.append([
                {"text": "🌐 Aman's Hub", "url": "https://aman179102.netlify.app"},
                {"text": "🐙 GitHub @aman179102", "url": "https://github.com/aman179102"},
            ])
            keyboard = build_inline_keyboard(buttons)

            await deps.bot.send_message(chat_id, reply_text, reply_markup=keyboard)
        except Exception as exc:
            log.error("Failed to generate custom Quora answer: %s", exc)
            await deps.bot.send_message(chat_id, f"❌ Failed generating Quora answer:\n{exc}")
    elif command in ("/meme", "/dev"):
        await deps.bot.send_message(chat_id, FETCHING)
        await send_meme_preview(chat_id, user_id, deps, subreddit="ProgrammerHumor" if command == "/dev" else None)
    elif command == "/linux":
        await deps.bot.send_message(chat_id, "🎲 Fetching a top Linux/sysadmin meme…")
        await send_meme_preview(chat_id, user_id, deps, subreddit="linuxmemes")
    elif command == "/cancel":
        had = deps.store.clear_pending(user_id)
        await deps.bot.send_message(chat_id, CANCELLED if had else NO_PENDING)
    else:
        await deps.bot.send_message(chat_id, HELP)


async def handle_callback(callback: dict, deps: HandlerDeps) -> None:
    cb_id = callback.get("id", "")
    from_user = callback.get("from", {})
    user_id = from_user.get("id")
    message = callback.get("message", {})
    chat_id = message.get("chat", {}).get("id")
    data = callback.get("data", "")
    if user_id is None or chat_id is None:
        return

    if not is_authorized(user_id, deps.settings):
        await deps.bot.answer_callback(cb_id, UNAUTHORIZED)
        return

    if data == CB_APPROVE:
        pending = deps.store.get_pending(user_id)
        if pending is None:
            await deps.bot.answer_callback(cb_id, NO_PENDING)
            await deps.bot.send_message(chat_id, NO_PENDING)
            return
        await deps.bot.answer_callback(cb_id, "Posting to Instagram…")
        caption = pending.title or "Posted via Hermes 🤖"
        try:
            await deps.publisher.publish_image(pending.image_url, caption=caption)
        except InstagramPublishError as e:
            log.warning("instagram publish failed for user %s: %s", user_id, e)
            # Keep pending meme so the user can retry with Approve again.
            await deps.bot.send_message(chat_id, f"❌ Instagram posting failed.\n\nReason:\n{e}")
            return
        deps.store.clear_pending(user_id)
        await deps.bot.send_message(chat_id, APPROVED)
    elif data == CB_ANOTHER:
        await deps.bot.answer_callback(cb_id, "Fetching another…")
        deps.store.clear_pending(user_id)
        await send_meme_preview(chat_id, user_id, deps)
    elif data == CB_CANCEL:
        await deps.bot.answer_callback(cb_id, CANCELLED)
        deps.store.clear_pending(user_id)
        await deps.bot.send_message(chat_id, CANCELLED)
    else:
        await deps.bot.answer_callback(cb_id, "Unknown action.")


async def handle_update(update: dict, deps: HandlerDeps) -> None:
    if "callback_query" in update:
        await handle_callback(update["callback_query"], deps)
    elif "message" in update:
        await handle_message(update["message"], deps)
    else:
        log.debug("ignoring unsupported update keys: %s", list(update.keys()))
