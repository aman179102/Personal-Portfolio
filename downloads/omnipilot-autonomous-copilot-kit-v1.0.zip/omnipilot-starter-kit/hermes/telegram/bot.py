"""Thin async wrapper over the Telegram Bot HTTPS API (no heavy framework)."""
from __future__ import annotations

import logging

import httpx

log = logging.getLogger("hermes.telegram")


class TelegramBot:
    def __init__(self, token: str, timeout: float = 15.0, client: httpx.AsyncClient | None = None) -> None:
        self._token = token
        self.timeout = timeout
        self._client = client

    @property
    def base_url(self) -> str:
        return f"https://api.telegram.org/bot{self._token}"

    def _client_ctx(self) -> httpx.AsyncClient:
        if self._client is not None:
            return self._client
        return httpx.AsyncClient(timeout=self.timeout)

    async def _post(self, method: str, payload: dict) -> dict:
        client = self._client_ctx()
        owns = self._client is None
        try:
            resp = await client.post(f"{self.base_url}/{method}", json=payload, timeout=self.timeout)
        finally:
            if owns:
                await client.aclose()
        try:
            data = resp.json()
        except Exception:
            data = {}
        if not data.get("ok"):
            log.warning("telegram %s failed: %s", method, str(data)[:200])
        return data

    async def send_message(self, chat_id: int, text: str, reply_markup: dict | None = None) -> dict:
        payload: dict = {"chat_id": chat_id, "text": text}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return await self._post("sendMessage", payload)

    async def send_photo(
        self, chat_id: int, photo_url: str, caption: str = "", reply_markup: dict | None = None
    ) -> dict:
        payload: dict = {"chat_id": chat_id, "photo": photo_url, "caption": caption[:1024]}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return await self._post("sendPhoto", payload)

    async def answer_callback(self, callback_id: str, text: str = "") -> dict:
        return await self._post("answerCallbackQuery", {"callback_query_id": callback_id, "text": text[:200]})
