"""Telegram Bot API inline keyboard for meme approval."""
from __future__ import annotations

CB_APPROVE = "approve"
CB_ANOTHER = "another"
CB_CANCEL = "cancel"


def approval_keyboard() -> dict:
    return {
        "inline_keyboard": [
            [
                {"text": "✅ Approve", "callback_data": CB_APPROVE},
                {"text": "🔄 Another", "callback_data": CB_ANOTHER},
            ],
            [{"text": "❌ Cancel", "callback_data": CB_CANCEL}],
        ]
    }
