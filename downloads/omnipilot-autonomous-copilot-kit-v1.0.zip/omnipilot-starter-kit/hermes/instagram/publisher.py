"""Instagram Graph API publisher (official API — no scraping/login automation).

Flow (Content Publishing API):
  1. POST /{ig-user-id}/media  {image_url, caption} -> creation id (container)
  2. POST /{ig-user-id}/media_publish {creation_id} -> published media id

Requires: a Facebook Page connected Instagram Business/Creator account,
a Meta app with instagram_content_publish permission, and a long-lived
User/Page access token. See README for setup steps.
"""
from __future__ import annotations

import logging

import httpx

log = logging.getLogger("hermes.instagram")

GRAPH_VERSION = "v19.0"
GRAPH_BASE = f"https://graph.facebook.com/{GRAPH_VERSION}"


class InstagramPublishError(Exception):
    """Safe-to-display publishing failure (never contains the token)."""


class InstagramPublisher:
    def __init__(
        self,
        access_token: str,
        ig_user_id: str,
        timeout: float = 30.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._token = access_token
        self._user_id = ig_user_id
        self.timeout = timeout
        self._client = client

    @property
    def configured(self) -> bool:
        return bool(self._token and self._user_id)

    def _client_ctx(self) -> httpx.AsyncClient:
        if self._client is not None:
            return self._client
        return httpx.AsyncClient(timeout=self.timeout)

    @staticmethod
    def _safe_error(payload: object, status: int) -> str:
        """Extract a safe message from Graph API error payload (no secrets)."""
        try:
            if isinstance(payload, dict):
                err = payload.get("error")
                if isinstance(err, dict):
                    msg = err.get("message") or err.get("error_user_msg") or ""
                    code = err.get("code", "")
                    if msg:
                        return f"Graph API error {code}: {msg}".strip()
        except Exception:
            pass
        return f"Instagram API request failed (HTTP {status})"

    async def publish_image(self, image_url: str, caption: str | None = None) -> str:
        """Publish a publicly-accessible image URL. Returns published media id."""
        if not self.configured:
            raise InstagramPublishError(
                "Instagram is not configured. Set INSTAGRAM_ACCESS_TOKEN and INSTAGRAM_USER_ID."
            )
        if not image_url.startswith("https://"):
            raise InstagramPublishError("Image URL must be a public https:// URL for Instagram.")

        client = self._client_ctx()
        owns_client = self._client is None
        try:
            # Step 1: create media container
            try:
                r1 = await client.post(
                    f"{GRAPH_BASE}/{self._user_id}/media",
                    data={
                        "image_url": image_url,
                        "caption": caption or "",
                        "access_token": self._token,
                    },
                    timeout=self.timeout,
                )
            except (httpx.TimeoutException, httpx.NetworkError) as e:
                raise InstagramPublishError(f"Instagram unreachable: {type(e).__name__}") from e
            if r1.status_code != 200:
                try:
                    payload = r1.json()
                except Exception:
                    payload = None
                raise InstagramPublishError(self._safe_error(payload, r1.status_code))
            try:
                creation_id = r1.json().get("id")
            except Exception as e:
                raise InstagramPublishError("Instagram returned malformed response") from e
            if not creation_id:
                raise InstagramPublishError("Instagram did not return a media container id")

            # Step 2: publish the container
            try:
                r2 = await client.post(
                    f"{GRAPH_BASE}/{self._user_id}/media_publish",
                    data={"creation_id": creation_id, "access_token": self._token},
                    timeout=self.timeout,
                )
            except (httpx.TimeoutException, httpx.NetworkError) as e:
                raise InstagramPublishError(f"Instagram unreachable: {type(e).__name__}") from e
            if r2.status_code != 200:
                try:
                    payload = r2.json()
                except Exception:
                    payload = None
                raise InstagramPublishError(self._safe_error(payload, r2.status_code))
            try:
                media_id = r2.json().get("id", "")
            except Exception as e:
                raise InstagramPublishError("Instagram returned malformed response") from e
            log.info("published Instagram media id=%s", media_id)
            return media_id
        finally:
            if owns_client:
                await client.aclose()
