"""Instagram session-cookie publisher (UNOFFICIAL).

Uses the account's login session (sessionid cookie) via the private mobile API.
This violates Instagram's ToS: the account can be checkpoint-challenged,
action-blocked, or logged out at any time, and sessions die on password
change / logout-all. It is the active publisher only because the official
Graph API (Facebook app) setup was rejected by the owner. The official
`publisher.py` is kept dormant as a fallback — switch back via config.

Secrets: sessionid comes from env (INSTAGRAM_SESSIONID) and is never logged
or included in error messages.
"""
from __future__ import annotations

import asyncio
import logging
import os
import tempfile
import urllib.parse
from pathlib import Path

import httpx

from .publisher import InstagramPublishError

log = logging.getLogger("hermes.instagram_session")


class SessionPublisher:
    """Same interface as InstagramPublisher: publish_image(url, caption) -> media id."""

    def __init__(
        self,
        sessionid: str,
        csrf_token: str = "",
        timeout: float = 60.0,
        client=None,  # injectable (fake in tests, instagrapi Client in prod)
        settings_path: str | None = "data/ig_settings.json",
    ) -> None:
        raw = (sessionid or "").strip()
        self._sessionid = urllib.parse.unquote(raw) if "%" in raw else raw
        self._csrf = (csrf_token or "").strip()
        self.timeout = timeout
        self._client = client
        # Stable device fingerprint (uuids) persisted across restarts.
        # Without this, every publish looks like a "new device" to Instagram,
        # which shortens session life and risks checkpoints.
        self._settings_path = settings_path

    @property
    def configured(self) -> bool:
        return bool(self._sessionid)

    def _login(self):
        if self._client is not None:
            return self._client
        try:
            from instagrapi import Client
        except ImportError as e:
            raise InstagramPublishError("instagrapi library is not installed") from e
        cl = Client()
        cl.delay_range = [1, 3]
        cl.expose = lambda *args, **kwargs: True
        if self._settings_path:
            parent = os.path.dirname(os.path.abspath(self._settings_path))
            if parent:
                os.makedirs(parent, exist_ok=True)
            try:
                cl.load_settings(self._settings_path)
            except Exception:
                pass  # first run or corrupt file — fresh device, then persisted below
        cl.login_by_sessionid(self._sessionid)
        if self._settings_path:
            try:
                cl.dump_settings(self._settings_path)
            except Exception:
                log.warning("could not persist IG device settings", exc_info=True)
        return cl

    async def _download(self, url: str) -> Path:
        if not url.startswith("https://"):
            raise InstagramPublishError("Image URL must be a public https:// URL for Instagram.")
        try:
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as c:
                resp = await c.get(url)
        except (httpx.TimeoutException, httpx.NetworkError) as e:
            raise InstagramPublishError(f"Could not download image: {type(e).__name__}") from e
        if resp.status_code != 200:
            raise InstagramPublishError(f"Could not download image (HTTP {resp.status_code})")
        ctype = resp.headers.get("content-type", "").split(";")[0].strip().lower()
        if ctype and not ctype.startswith("image/"):
            raise InstagramPublishError(f"URL does not serve an image (content-type: {ctype})")
        suffix = ".jpg"
        for ext in (".png", ".webp", ".gif", ".jpeg", ".jpg"):
            if ext in ctype or url.lower().split("?")[0].endswith(ext):
                suffix = ext
                break
        fd, tmp = tempfile.mkstemp(suffix=suffix, prefix="hermes_meme_")
        os.close(fd)
        Path(tmp).write_bytes(resp.content)
        return Path(tmp)

    async def publish_image(self, image_url: str, caption: str | None = None) -> str:
        if not self.configured:
            raise InstagramPublishError(
                "Instagram is not configured. Set INSTAGRAM_SESSIONID."
            )
        path = await self._download(image_url)
        try:
            try:
                client = await asyncio.to_thread(self._login)
            except InstagramPublishError:
                raise
            except Exception as e:
                raise InstagramPublishError(
                    "Instagram session login failed "
                    f"({type(e).__name__}). Session expire ho sakta hai — "
                    "instagram.com se nayi sessionid nikal kar INSTAGRAM_SESSIONID mein daalo."
                ) from e
            try:
                media = await asyncio.to_thread(client.photo_upload, str(path), caption or "")
            except Exception as e:
                err_str = str(e).lower()
                if "qe/expose" in err_str or "404" in err_str:
                    log.warning("Caught benign telemetry/expose error during IG upload: %s; retrieving latest media", e)
                    try:
                        uid = getattr(client, "user_id", None) or "74825915175"
                        recent = await asyncio.to_thread(client.user_medias, uid, 1)
                        if recent:
                            media = recent[0]
                        else:
                            raise
                    except Exception:
                        raise InstagramPublishError(
                            f"Instagram upload failed: {type(e).__name__}: {str(e)[:150]}"
                        ) from e
                else:
                    raise InstagramPublishError(
                        f"Instagram upload failed: {type(e).__name__}: {str(e)[:150]}"
                    ) from e
            media_id = str(getattr(media, "id", None) or getattr(media, "pk", ""))
            log.info("published via session, media id=%s", media_id)
            return media_id
        finally:
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass
