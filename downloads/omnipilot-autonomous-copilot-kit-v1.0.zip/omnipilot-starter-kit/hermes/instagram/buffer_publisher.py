"""Buffer-backed safe Instagram publisher for Hermes Telegram Cockpit."""
from __future__ import annotations

import logging
from typing import Any

from common.config import load_settings
from automations.buffer.api import BufferAPIError, BufferClient

logger = logging.getLogger(__name__)


class BufferInstagramPublisher:
    """Publishes images to Instagram via the official Buffer GraphQL API."""

    def __init__(self, settings: Any = None):
        self.settings = settings or load_settings()
        self.client = BufferClient(self.settings)

    async def publish_image(self, image_url: str, caption: str) -> str:
        try:
            try:
                from common.watermark import prepare_instagram_meme_canvas
                _, cdn_url = prepare_instagram_meme_canvas(image_url)
                target_url = cdn_url
            except Exception as e:
                logger.warning("Failed formatting Instagram meme canvas in Hermes: %s. Using raw image URL.", e)
                target_url = image_url

            res = self.client.post_instagram(caption, image_url=target_url, mode="shareNow")
            post_id = res.get("id", "ok")
            logger.info("Successfully published meme via Hermes Buffer publisher: ID %s", post_id)
            return post_id
        except BufferAPIError as exc:
            logger.error("Hermes Buffer publisher error: %s", exc)
            raise RuntimeError(f"Buffer publish error: {exc}") from exc
