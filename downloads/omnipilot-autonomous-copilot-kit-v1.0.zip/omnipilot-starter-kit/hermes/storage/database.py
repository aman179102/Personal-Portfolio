"""SQLite-backed pending-meme state. Survives process restarts (local file).

NOTE on Render: the default Render Web Service filesystem is ephemeral —
files under DATA dir survive restarts but NOT redeploys/deploys. For the MVP
single-instance bot this is acceptable (worst case: a pending meme awaiting
approval is lost on redeploy and the user just runs /meme again). If you need
durable state, attach a Render Disk (same DB_PATH on the disk) or migrate to
Render Postgres later. See README for details.
"""
from __future__ import annotations

import logging
import os
import sqlite3
import threading
from dataclasses import dataclass
from datetime import datetime, timezone

log = logging.getLogger("hermes.storage")


@dataclass
class PendingMeme:
    user_id: int
    image_url: str
    title: str
    source_url: str
    status: str
    created_at: str
    chat_id: int | None = None


class PendingStore:
    """Thread-safe SQLite store. One pending meme per Telegram user."""

    def __init__(self, db_path: str = "data/hermes.db") -> None:
        self.db_path = db_path
        self._lock = threading.Lock()
        parent = os.path.dirname(os.path.abspath(db_path))
        if parent:
            os.makedirs(parent, exist_ok=True)
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self) -> None:
        with self._lock, self._connect() as conn:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS pending_memes (
                    user_id INTEGER PRIMARY KEY,
                    image_url TEXT NOT NULL,
                    title TEXT NOT NULL DEFAULT '',
                    source_url TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'pending',
                    created_at TEXT NOT NULL,
                    chat_id INTEGER
                )
                """
            )

    def save_pending(
        self,
        user_id: int,
        image_url: str,
        title: str = "",
        source_url: str = "",
        chat_id: int | None = None,
    ) -> PendingMeme:
        created_at = datetime.now(timezone.utc).isoformat()
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO pending_memes
                    (user_id, image_url, title, source_url, status, created_at, chat_id)
                VALUES (?, ?, ?, ?, 'pending', ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    image_url=excluded.image_url,
                    title=excluded.title,
                    source_url=excluded.source_url,
                    status='pending',
                    created_at=excluded.created_at,
                    chat_id=excluded.chat_id
                """,
                (user_id, image_url, title, source_url, created_at, chat_id),
            )
        log.info("saved pending meme for user_id=%s", user_id)
        return PendingMeme(user_id, image_url, title, source_url, "pending", created_at, chat_id)

    def get_pending(self, user_id: int) -> PendingMeme | None:
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM pending_memes WHERE user_id = ? AND status = 'pending'",
                (user_id,),
            ).fetchone()
        if row is None:
            return None
        return PendingMeme(
            user_id=row["user_id"],
            image_url=row["image_url"],
            title=row["title"] or "",
            source_url=row["source_url"] or "",
            status=row["status"],
            created_at=row["created_at"],
            chat_id=row["chat_id"],
        )

    def clear_pending(self, user_id: int) -> bool:
        """Delete pending meme. Returns True if something was pending."""
        with self._lock, self._connect() as conn:
            cur = conn.execute("DELETE FROM pending_memes WHERE user_id = ?", (user_id,))
        deleted = cur.rowcount > 0
        log.info("cleared pending meme for user_id=%s (had_pending=%s)", user_id, deleted)
        return deleted
