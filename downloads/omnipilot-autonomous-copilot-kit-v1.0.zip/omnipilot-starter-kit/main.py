from __future__ import annotations

import argparse
import logging
import sys
import time

from common.config import load_settings
from common.ai import test_ai_connectivity
from common.telegram import test_telegram_ping

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("free-automations")


def _cli_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Free-Automations Platform – Autonomous Tech Growth & Outreach Engine for Aman Kumar (@aman179102)."
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--test-telegram", action="store_true", help="Send test ping to verify Telegram Bot configuration")
    group.add_argument("--test-ai", action="store_true", help="Test connectivity to Gemini, Groq, and OpenRouter AI models")
    group.add_argument("--hn-hiring", action="store_true", help="Run HN Who is Hiring radar & draft 100%% remote outreach pitches")
    group.add_argument("--hn-discussion", action="store_true", help="Find top Ask HN engineering questions and draft senior architecture answers")
    group.add_argument("--hn-showcase", action="store_true", help="Draft Show HN posts showcasing Aman's systems engineering projects")
    group.add_argument("--hn-all", action="store_true", help="Run full suite of Hacker News automations")
    group.add_argument("--itch-devlog", action="store_true", help="Generate/publish high-signal systems & simulation devlog to itch.io")
    group.add_argument("--itch-radar", action="store_true", help="Scan game jams filtering for AI, systems, tools, Python, Go, and Rust")
    group.add_argument("--itch-analytics", action="store_true", help="Track project views, downloads, and purchases on itch.io")
    group.add_argument("--itch-all", action="store_true", help="Run full suite of itch.io automations and send consolidated digest")
    group.add_argument("--qiita-article", action="store_true", help="Generate/publish high-signal Tech Japanese article to Qiita")
    group.add_argument("--qiita-radar", action="store_true", help="Scan Qiita tech trends & tag radar (#Python, #AI, #FastAPI, #Go, #Rust)")
    group.add_argument("--qiita-analytics", action="store_true", help="Track Qiita LGTM, Stocks, and Views with delta computation")
    group.add_argument("--qiita-all", action="store_true", help="Run full suite of Qiita automations and send consolidated digest")
    group.add_argument("--velog-article", action="store_true", help="Generate/publish high-signal Tech Korean article to Velog")
    group.add_argument("--velog-radar", action="store_true", help="Scan Velog tech trends & weekly trending radar")
    group.add_argument("--velog-analytics", action="store_true", help="Track Velog Likes, Comments, and Views with delta computation")
    group.add_argument("--velog-all", action="store_true", help="Run full suite of Velog automations and send consolidated digest")
    group.add_argument("--devto-article", action="store_true", help="Generate/publish deep-dive technical article to Dev.to")
    group.add_argument("--devto-radar", action="store_true", help="Scan Dev.to rising tech trend radar (#python, #architecture, #webdev, #ai, #devops)")
    group.add_argument("--devto-analytics", action="store_true", help="Track Dev.to Page Views, Reactions, and Comments with delta computation")
    group.add_argument("--devto-all", action="store_true", help="Run full suite of Dev.to automations and send consolidated digest")
    group.add_argument("--gist-post", action="store_true", help="Generate/publish senior systems engineering Gist to GitHub")
    group.add_argument("--gist-analytics", action="store_true", help="Track GitHub Gist Stars and Forks with delta computation")
    group.add_argument("--gist-all", action="store_true", help="Run full suite of GitHub Gist automations and send consolidated digest")
    group.add_argument("--hf-dataset", action="store_true", help="Generate/publish senior engineering benchmark dataset to Hugging Face")
    group.add_argument("--hf-analytics", action="store_true", help="Track Hugging Face Likes and Downloads with delta computation")
    group.add_argument("--hf-all", action="store_true", help="Run full suite of Hugging Face automations and send consolidated digest")
    group.add_argument("--kaggle-dataset", action="store_true", help="Generate/publish senior engineering benchmark dataset to Kaggle")
    group.add_argument("--kaggle-analytics", action="store_true", help="Track Kaggle Upvotes, Views, and Downloads with delta computation")
    group.add_argument("--kaggle-all", action="store_true", help="Run full suite of Kaggle automations and send consolidated digest")
    group.add_argument("--gitlab-snippet", action="store_true", help="Generate/publish production systems engineering snippet to GitLab")
    group.add_argument("--gitlab-analytics", action="store_true", help="Track GitLab Snippet Stars and Files with delta computation")
    group.add_argument("--gitlab-all", action="store_true", help="Run full suite of GitLab automations and send consolidated digest")
    group.add_argument("--codeberg-repo", action="store_true", help="Generate/publish open-source systems engineering toolkit to Codeberg")
    group.add_argument("--codeberg-analytics", action="store_true", help="Track Codeberg Stars, Forks, and Watchers with delta computation")
    group.add_argument("--codeberg-all", action="store_true", help="Run full suite of Codeberg automations and send consolidated digest")
    group.add_argument("--dockerhub-repo", action="store_true", help="Generate/publish enterprise systems container to Docker Hub")
    group.add_argument("--dockerhub-analytics", action="store_true", help="Track Docker Hub Pull Count and Stars with delta computation")
    group.add_argument("--dockerhub-all", action="store_true", help="Run full suite of Docker Hub automations and send consolidated digest")
    group.add_argument("--pypi-package", action="store_true", help="Generate/publish open-source Python library to PyPI")
    group.add_argument("--pypi-analytics", action="store_true", help="Track PyPI download statistics with delta computation")
    group.add_argument("--pypi-all", action="store_true", help="Run full suite of PyPI automations and send consolidated digest")
    group.add_argument("--bluesky-post", action="store_true", help="Generate/publish viral tech post to Bluesky")
    group.add_argument("--bluesky-engagement", action="store_true", help="Run community AI auto-replies on trending tech discussions on Bluesky")
    group.add_argument("--bluesky-all", action="store_true", help="Run full suite of Bluesky automations (post + engagement)")
    group.add_argument("--instagram-post", action="store_true", help="Publish curated developer tech meme/timeline card to Instagram")
    group.add_argument("--instagram-all", action="store_true", help="Run full suite of Instagram automations")
    group.add_argument("--mastodon-post", action="store_true", help="Publish systems engineering status to Mastodon (mstdn.party & mstdn.plus)")
    group.add_argument("--mastodon-engagement", action="store_true", help="Run community pulse favourites/reblogs on #linux, #python, #foss")
    group.add_argument("--mastodon-all", action="store_true", help="Run full suite of Mastodon automations (posts + engagement)")
    group.add_argument("--youtube-short", action="store_true", help="Generate/render Tokyo Night systems engineering YouTube Short")
    group.add_argument("--buffer-twitter", action="store_true", help="Publish tech insight tweet to X/Twitter via Buffer")
    group.add_argument("--buffer-instagram", action="store_true", help="Publish programmer meme to Instagram via Buffer")
    group.add_argument("--buffer-linkedin", action="store_true", help="Publish technical engineering post to LinkedIn via Buffer")
    group.add_argument("--buffer-all", action="store_true", help="Run full suite of Buffer multi-channel automations (Twitter + Instagram + LinkedIn)")
    group.add_argument("--linkedin-radar", action="store_true", help="Run LinkedIn Opportunity Radar & dispatch 1-tap mobile comment draft to Telegram")
    group.add_argument("--linkedin-all", action="store_true", help="Run full LinkedIn Opportunity Radar suite")
    group.add_argument("--quora-radar", action="store_true", help="Run Quora Question Radar & dispatch 1-tap mobile answer draft to Telegram")
    group.add_argument("--quora-all", action="store_true", help="Run full Quora Question Radar suite")
    group.add_argument("--hermes-bot", "--hermes-poll", action="store_true", help="Launch Hermes Telegram approval bot in 24/7 long-polling mode")
    group.add_argument("--omni-all", action="store_true", help="Run full cross-platform distribution sweep across all social & technical channels")
    group.add_argument("--server", action="store_true", help="Launch lightweight HTTP health check and webhook server")

    parser.add_argument("--daemon", action="store_true", help="Run in continuous background loop")
    parser.add_argument("--interval", type=int, default=60, help="Daemon cycle interval in minutes (default: 60)")
    parser.add_argument("--dry-run", action="store_true", help="Run automation without sending messages to Telegram")
    parser.add_argument("--live", "--auto-publish", action="store_true", dest="live", help="Autonomously publish comments and Show HN posts live to Hacker News")
    parser.add_argument("--discussion-mode", choices=["all", "popular", "rising", "ask_hn"], default="all", help="Target discussion type (popular top stories vs fresh rising threads)")
    parser.add_argument("--port", type=int, default=None, help="Custom server port (overrides PORT env)")

    return parser


def run_hn_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
    discussion_mode: str = "all",
) -> bool:
    """Invokes the HN automation runner if installed."""
    try:
        from automations.hn import runner
    except ImportError as exc:
        logger.error("HN automation module not available: %s", exc)
        print("⚠️  automations.hn is currently not installed or under construction.")
        return False

    dispatch_map = {
        "hiring": "run_hiring_radar",
        "discussion": "run_discussion",
        "showcase": "run_showcase",
        "all": "run_all",
    }
    func_name = dispatch_map.get(action)
    if not func_name or not hasattr(runner, func_name):
        logger.error("Runner method %s not found in automations.hn.runner", func_name)
        return False

    func = getattr(runner, func_name)
    try:
        logger.info(
            "Executing HN action '%s' (dry_run=%s, auto_publish=%s, discussion_mode=%s)...",
            action,
            dry_run,
            auto_publish,
            discussion_mode,
        )
        kwargs: dict[str, Any] = {"dry_run": dry_run}
        import inspect
        sig = inspect.signature(func)
        if "auto_publish" in sig.parameters:
            kwargs["auto_publish"] = auto_publish
        if "mode" in sig.parameters and action == "discussion":
            kwargs["mode"] = discussion_mode

        func(settings, **kwargs)
        return True
    except Exception as exc:
        logger.error("Failed to execute HN %s: %s", action, exc)
        return False


def run_itch_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the itch.io automation runner."""
    try:
        from automations.itch import runner as itch_runner
    except ImportError as exc:
        logger.error("itch.io automation module not available: %s", exc)
        print("⚠️  automations.itch is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing itch.io action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "devlog":
            res = itch_runner.run_devlog(settings, dry_run=dry_run, force=auto_publish)
        elif action == "radar":
            res = itch_runner.run_radar(settings, dry_run=dry_run)
        elif action == "analytics":
            res = itch_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = itch_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "skipped")
    except Exception as exc:
        logger.error("Failed to execute itch %s: %s", action, exc)
        return False


def run_qiita_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Qiita automation runner."""
    try:
        from automations.qiita import runner as qiita_runner
    except ImportError as exc:
        logger.error("Qiita automation module not available: %s", exc)
        print("⚠️  automations.qiita is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing Qiita action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "article":
            res = qiita_runner.run_article(settings, dry_run=dry_run, force=auto_publish)
        elif action == "radar":
            res = qiita_runner.run_radar(settings, dry_run=dry_run)
        elif action == "analytics":
            res = qiita_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = qiita_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "skipped")
    except Exception as exc:
        logger.error("Failed to execute Qiita %s: %s", action, exc)
        return False


def run_velog_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Velog automation runner."""
    try:
        from automations.velog import runner as velog_runner
    except ImportError as exc:
        logger.error("Velog automation module not available: %s", exc)
        print("⚠️  automations.velog is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing Velog action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "article":
            res = velog_runner.run_article(settings, dry_run=dry_run, force=auto_publish)
        elif action == "radar":
            res = velog_runner.run_radar(settings, dry_run=dry_run)
        elif action == "analytics":
            res = velog_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = velog_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "published", "skipped", "cooldown", "dry_run")
    except Exception as exc:
        logger.error("Failed to execute Velog %s: %s", action, exc)
        return False


def run_devto_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Dev.to automation runner."""
    try:
        from automations.devto import runner as devto_runner
    except ImportError as exc:
        logger.error("Dev.to automation module not available: %s", exc)
        print("⚠️  automations.devto is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing Dev.to action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "article":
            res = devto_runner.run_article(settings, dry_run=dry_run, force=auto_publish)
        elif action == "radar":
            res = devto_runner.run_radar(settings, dry_run=dry_run)
        elif action == "analytics":
            res = devto_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = devto_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "published", "skipped", "cooldown", "dry_run")
    except Exception as exc:
        logger.error("Failed to execute Dev.to %s: %s", action, exc)
        return False


def run_gist_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the GitHub Gist automation runner."""
    try:
        from automations.gist import runner as gist_runner
    except ImportError as exc:
        logger.error("GitHub Gist automation module not available: %s", exc)
        print("⚠️  automations.gist is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing GitHub Gist action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "post":
            res = gist_runner.run_post(settings, dry_run=dry_run, force=auto_publish)
        elif action == "analytics":
            res = gist_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = gist_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "published", "skipped", "cooldown", "dry_run")
    except Exception as exc:
        logger.error("Failed to execute GitHub Gist %s: %s", action, exc)
        return False


def run_hf_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Hugging Face automation runner."""
    try:
        from automations.huggingface import runner as hf_runner
    except ImportError as exc:
        logger.error("Hugging Face automation module not available: %s", exc)
        print("⚠️  automations.huggingface is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing Hugging Face action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "dataset":
            res = hf_runner.run_dataset(settings, dry_run=dry_run, force=auto_publish)
        elif action == "analytics":
            res = hf_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = hf_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "published", "skipped", "cooldown", "dry_run")
    except Exception as exc:
        logger.error("Failed to execute Hugging Face %s: %s", action, exc)
        return False


def run_kaggle_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Kaggle automation runner."""
    try:
        from automations.kaggle import runner as kaggle_runner
    except ImportError as exc:
        logger.error("Kaggle automation module not available: %s", exc)
        print("⚠️  automations.kaggle is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing Kaggle action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "dataset":
            res = kaggle_runner.run_dataset(settings, dry_run=dry_run, force=auto_publish)
        elif action == "analytics":
            res = kaggle_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = kaggle_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "published", "skipped", "cooldown", "dry_run")
    except Exception as exc:
        logger.error("Failed to execute Kaggle %s: %s", action, exc)
        return False


def run_gitlab_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the GitLab automation runner."""
    try:
        from automations.gitlab import runner as gitlab_runner
    except ImportError as exc:
        logger.error("GitLab automation module not available: %s", exc)
        print("⚠️  automations.gitlab is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing GitLab action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "snippet":
            res = gitlab_runner.run_snippet(settings, dry_run=dry_run, force=auto_publish)
        elif action == "analytics":
            res = gitlab_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = gitlab_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "published", "skipped", "cooldown", "dry_run")
    except Exception as exc:
        logger.error("Failed to execute GitLab %s: %s", action, exc)
        return False


def run_codeberg_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Codeberg automation runner."""
    try:
        from automations.codeberg import runner as codeberg_runner
    except ImportError as exc:
        logger.error("Codeberg automation module not available: %s", exc)
        print("⚠️  automations.codeberg is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing Codeberg action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "repo":
            res = codeberg_runner.run_repo(settings, dry_run=dry_run, force=auto_publish)
        elif action == "analytics":
            res = codeberg_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = codeberg_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "published", "skipped", "cooldown", "dry_run")
    except Exception as exc:
        logger.error("Failed to execute Codeberg %s: %s", action, exc)
        return False


def run_dockerhub_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Docker Hub automation runner."""
    try:
        from automations.dockerhub import runner as dockerhub_runner
    except ImportError as exc:
        logger.error("Docker Hub automation module not available: %s", exc)
        print("⚠️  automations.dockerhub is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing Docker Hub action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "repo":
            res = dockerhub_runner.run_repo(settings, dry_run=dry_run, force=auto_publish)
        elif action == "analytics":
            res = dockerhub_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = dockerhub_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "published", "skipped", "cooldown", "dry_run", "rate_limited")
    except Exception as exc:
        logger.error("Failed to execute Docker Hub %s: %s", action, exc)
        return False


def run_pypi_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the PyPI automation runner."""
    try:
        from automations.pypi import runner as pypi_runner
    except ImportError as exc:
        logger.error("PyPI automation module not available: %s", exc)
        print("⚠️  automations.pypi is currently not installed or under construction.")
        return False

    try:
        logger.info("Executing PyPI action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "package":
            res = pypi_runner.run_package(settings, dry_run=dry_run, force=auto_publish)
        elif action == "analytics":
            res = pypi_runner.run_analytics(settings, dry_run=dry_run)
        elif action == "all":
            res = pypi_runner.run_all(settings, dry_run=dry_run, force=auto_publish)
        else:
            return False
        return res.get("status") in ("success", "published", "skipped", "cooldown", "dry_run", "rate_limited", "already_exists")
    except Exception as exc:
        logger.error("Failed to execute PyPI %s: %s", action, exc)
        return False


def run_bluesky_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Bluesky automation runner."""
    try:
        from automations.bluesky import runner as bsky_runner
    except ImportError as exc:
        logger.error("Bluesky automation module not available: %s", exc)
        return False
    try:
        logger.info("Executing Bluesky action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        if action == "post":
            res = bsky_runner.run_post(settings, dry_run=dry_run)
        elif action == "engagement":
            res = bsky_runner.run_engagement(settings, dry_run=dry_run)
        else:
            res = bsky_runner.run_all(settings, dry_run=dry_run)
        return res.get("status") in ("success", "published", "dry_run", "empty", "skipped")
    except Exception as exc:
        logger.error("Failed to execute Bluesky %s: %s", action, exc)
        return False


def run_instagram_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Instagram automation is permanently disabled."""
    logger.info("Instagram automation is permanently disabled.")
    return False


def run_youtube_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the YouTube Shorts automation runner."""
    try:
        from automations.youtube import runner as yt_runner
    except ImportError as exc:
        logger.error("YouTube automation module not available: %s", exc)
        return False
    try:
        logger.info("Executing YouTube action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        res = yt_runner.run_all(settings, dry_run=dry_run, force=False)
        return res.get("status") in ("generated", "dry_run", "cooldown", "success")
    except Exception as exc:
        logger.error("Failed to execute YouTube %s: %s", action, exc)
        return False


def run_mastodon_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Mastodon automation runner."""
    try:
        from automations.mastodon import runner as mstdn_runner
    except ImportError as exc:
        logger.error("Mastodon automation module not available: %s", exc)
        return False
    try:
        logger.info("Executing Mastodon action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        runner = mstdn_runner.MastodonRunner(settings)
        if action == "post":
            res = runner.run_post(dry_run=dry_run, force=auto_publish)
        elif action == "engagement":
            res = runner.run_engagement(dry_run=dry_run)
        else:
            res = runner.run_all(dry_run=dry_run, force=auto_publish)
        return True
    except Exception as exc:
        logger.error("Failed to execute Mastodon %s: %s", action, exc)
        return False


def run_buffer_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Buffer Omnichannel runner (Twitter/X, Instagram, LinkedIn)."""
    try:
        from automations.buffer import runner as buf_runner
    except ImportError as exc:
        logger.error("Buffer automation module not available: %s", exc)
        return False
    try:
        logger.info("Executing Buffer action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        runner = buf_runner.BufferRunner(settings)
        if action == "twitter":
            res = runner.run_twitter(dry_run=dry_run, force=False)
        elif action == "instagram":
            res = runner.run_instagram(dry_run=dry_run, force=False)
        elif action == "linkedin":
            res = runner.run_linkedin(dry_run=dry_run, force=False)
        else:
            res = runner.run_all(dry_run=dry_run, force=False)
        return True
    except Exception as exc:
        logger.error("Failed to execute Buffer %s: %s", action, exc)
        return False


def run_omni_cycle(settings, dry_run: bool = False, live: bool = False) -> bool:
    """Executes a unified omnichannel distribution sweep across all social & engineering channels."""
    logger.info("🚀 Initiating Omnichannel Content & Engagement Distribution Sweep...")
    # 1. LinkedIn 1-Tap Mobile Comment Copilot (Priority 1: Immediate scheduled mobile alerts)
    run_linkedin_action("radar", settings, dry_run=dry_run, auto_publish=live)

    # 2. Social Virality: Bluesky
    run_bluesky_action("all", settings, dry_run=dry_run, auto_publish=live)
    # Instagram permanently disabled:
    # run_instagram_action("all", settings, dry_run=dry_run, auto_publish=live)

    # 3. Tech Discussions & Radar: Hacker News
    run_hn_action("all", settings, dry_run=dry_run, auto_publish=live)

    # 4. Technical Blogs & Articles: Dev.to / Qiita / Velog
    for mod_name in ("devto", "qiita", "velog"):
        try:
            mod = __import__(f"automations.{mod_name}.runner", fromlist=["run_all"])
            mod.run_all(settings, dry_run=dry_run)
        except Exception as e:
            logger.warning("Error running %s: %s", mod_name, e)

    # 5. Verified Developer Authority & Packages: Gist + PyPI + Docker Hub (24h Cooldowns)
    run_gist_action("all", settings, dry_run=dry_run, auto_publish=live)
    run_pypi_action("all", settings, dry_run=dry_run, auto_publish=live)
    run_dockerhub_action("all", settings, dry_run=dry_run, auto_publish=live)

    # 6. YouTube Shorts Engineering Engine (24h Cooldown)
    run_youtube_action("all", settings, dry_run=dry_run, auto_publish=live)

    # 7. Mastodon Fediverse Status Engine (8h Cooldown)
    run_mastodon_action("all", settings, dry_run=dry_run, auto_publish=live)

    # 8. Buffer Omnichannel Engine: LinkedIn + X/Twitter + Instagram (8h Cooldown)
    run_buffer_action("all", settings, dry_run=dry_run, auto_publish=live)

    # 9. Quora 1-Tap Question Radar Copilot (3-4 answers/day ceiling)
    run_quora_action("radar", settings, dry_run=dry_run, auto_publish=live)

    return True


def run_quora_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the Quora Question Radar & 1-Tap Mobile Answer Copilot."""
    try:
        from automations.quora import runner as quora_runner
    except ImportError as exc:
        logger.error("Quora automation module not available: %s", exc)
        return False
    try:
        logger.info("Executing Quora action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        res = quora_runner.run_radar(settings, dry_run=dry_run, force=auto_publish)
        return res.get("status") in ("success", "cooldown", "outside_window", "ceiling_reached")
    except Exception as exc:
        logger.error("Failed to execute Quora action %s: %s", action, exc)
        return False


def run_linkedin_action(
    action: str,
    settings,
    dry_run: bool = False,
    auto_publish: bool = False,
) -> bool:
    """Invokes the LinkedIn Opportunity Radar & 1-Tap Mobile Comment Copilot."""
    try:
        from automations.linkedin import runner as li_runner
    except ImportError as exc:
        logger.error("LinkedIn automation module not available: %s", exc)
        return False
    try:
        logger.info("Executing LinkedIn action '%s' (dry_run=%s, auto_publish=%s)...", action, dry_run, auto_publish)
        res = li_runner.run_radar(settings, dry_run=dry_run, force=auto_publish)
        return res.get("status") in ("success", "cooldown", "outside_window", "ceiling_reached")
    except Exception as exc:
        logger.error("Failed to execute LinkedIn action %s: %s", action, exc)
        return False


def main() -> int:
    parser = _cli_parser()
    args = parser.parse_args()
    settings = load_settings()
    if args.live:
        # Override settings with live publishing active
        object.__setattr__(settings, "hn_auto_publish", True) if hasattr(settings, "__dataclass_fields__") else None

    # 1. Test Telegram Ping
    if args.test_telegram:
        print("\n📲 Verifying Telegram Bot connectivity...")
        ok = test_telegram_ping(settings)
        return 0 if ok else 1

    # 2. Test AI Providers
    if args.test_ai:
        print("\n🤖 Testing AI Model Connectivity across providers...")
        results = test_ai_connectivity(settings)
        for provider, status in results.items():
            mark = "✅ ONLINE" if status else "❌ OFFLINE / UNCONFIGURED"
            print(f"  • {provider.capitalize():12s}: {mark}")
        all_passed = any(results.values())
        return 0 if all_passed else 1

    # 3. HTTP Server
    if args.server:
        from server import run_server
        print(f"\n🌐 Starting Free-Automations HTTP server on port {args.port or settings.port}...")
        run_server(port=args.port)
        return 0

    # 4. Daemon loop
    if args.daemon:
        interval_secs = max(args.interval * 60, 60)
        mode_label = "AUTONOMOUS LIVE AUTO-PILOT (OMNICHANNEL)" if args.live else "DRY-RUN SIMULATION"
        logger.info("Starting background daemon. Mode: %s. Interval: %d minutes", mode_label, args.interval)
        try:
            while True:
                logger.info("--- Starting scheduled omnichannel distribution cycle ---")
                run_omni_cycle(settings, dry_run=args.dry_run, live=args.live)
                logger.info("Cycle complete. Sleeping for %d minutes...", args.interval)
                time.sleep(interval_secs)
        except KeyboardInterrupt:
            logger.info("Daemon stopped by user.")
            return 0

    # 5. Individual or All HN commands
    if args.hn_hiring:
        ok = run_hn_action("hiring", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.hn_discussion:
        ok = run_hn_action("discussion", settings, dry_run=args.dry_run, auto_publish=args.live, discussion_mode=args.discussion_mode)
        return 0 if ok else 1

    if args.hn_showcase:
        ok = run_hn_action("showcase", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.hn_all:
        ok = run_hn_action("all", settings, dry_run=args.dry_run, auto_publish=args.live, discussion_mode=args.discussion_mode)
        return 0 if ok else 1

    # 6. itch.io commands
    if args.itch_devlog:
        ok = run_itch_action("devlog", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.itch_radar:
        ok = run_itch_action("radar", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.itch_analytics:
        ok = run_itch_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.itch_all:
        ok = run_itch_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 7. Qiita commands
    if args.qiita_article:
        ok = run_qiita_action("article", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.qiita_radar:
        ok = run_qiita_action("radar", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.qiita_analytics:
        ok = run_qiita_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.qiita_all:
        ok = run_qiita_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 8. Velog commands
    if args.velog_article:
        ok = run_velog_action("article", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.velog_radar:
        ok = run_velog_action("radar", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.velog_analytics:
        ok = run_velog_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.velog_all:
        ok = run_velog_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 9. Dev.to commands
    if args.devto_article:
        ok = run_devto_action("article", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.devto_radar:
        ok = run_devto_action("radar", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.devto_analytics:
        ok = run_devto_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.devto_all:
        ok = run_devto_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 10. GitHub Gist commands
    if args.gist_post:
        ok = run_gist_action("post", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.gist_analytics:
        ok = run_gist_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.gist_all:
        ok = run_gist_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 11. Hugging Face commands
    if args.hf_dataset:
        ok = run_hf_action("dataset", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.hf_analytics:
        ok = run_hf_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.hf_all:
        ok = run_hf_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 12. Kaggle commands
    if args.kaggle_dataset:
        ok = run_kaggle_action("dataset", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.kaggle_analytics:
        ok = run_kaggle_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.kaggle_all:
        ok = run_kaggle_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 13. GitLab commands
    if args.gitlab_snippet:
        ok = run_gitlab_action("snippet", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.gitlab_analytics:
        ok = run_gitlab_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.gitlab_all:
        ok = run_gitlab_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 14. Codeberg commands
    if args.codeberg_repo:
        ok = run_codeberg_action("repo", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.codeberg_analytics:
        ok = run_codeberg_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.codeberg_all:
        ok = run_codeberg_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 15. Docker Hub commands
    if args.dockerhub_repo:
        ok = run_dockerhub_action("repo", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.dockerhub_analytics:
        ok = run_dockerhub_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.dockerhub_all:
        ok = run_dockerhub_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 16. PyPI commands
    if args.pypi_package:
        ok = run_pypi_action("package", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.pypi_analytics:
        ok = run_pypi_action("analytics", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.pypi_all:
        ok = run_pypi_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 17. Bluesky commands
    if args.bluesky_post:
        ok = run_bluesky_action("post", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.bluesky_engagement:
        ok = run_bluesky_action("engagement", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.bluesky_all:
        ok = run_bluesky_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 18. Instagram commands
    if args.instagram_post:
        ok = run_instagram_action("post", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.instagram_all:
        ok = run_instagram_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 19. Mastodon commands (Multi-Instance: mstdn.party & mstdn.plus)
    if args.mastodon_post:
        ok = run_mastodon_action("post", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.mastodon_engagement:
        ok = run_mastodon_action("engagement", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.mastodon_all:
        ok = run_mastodon_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 20. YouTube Shorts
    if args.youtube_short:
        ok = run_youtube_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 21. Buffer Omnichannel (Twitter, Instagram, LinkedIn)
    if args.buffer_twitter:
        ok = run_buffer_action("twitter", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.buffer_instagram:
        ok = run_buffer_action("instagram", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.buffer_linkedin:
        ok = run_buffer_action("linkedin", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    if args.buffer_all:
        ok = run_buffer_action("all", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 22. LinkedIn Opportunity Radar & 1-Tap Mobile Comment Copilot
    if args.linkedin_radar or args.linkedin_all:
        ok = run_linkedin_action("radar", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 23. Quora Question Radar & 1-Tap Mobile Answer Copilot
    if args.quora_radar or args.quora_all:
        ok = run_quora_action("radar", settings, dry_run=args.dry_run, auto_publish=args.live)
        return 0 if ok else 1

    # 22. Unified Omnichannel Full Sweep
    if args.omni_all:
        ok = run_omni_cycle(settings, dry_run=args.dry_run, live=args.live)
        return 0 if ok else 1

    # 22. Hermes Interactive Telegram Cockpit
    if args.hermes_bot:
        logger.info("Starting Hermes Telegram Approval Cockpit Daemon...")
        from hermes.poll import run_polling
        run_polling()
        return 0

    # Default if no arguments provided: print help
    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
