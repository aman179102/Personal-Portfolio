from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


class ConfigError(RuntimeError):
    """Raised when critical configuration is missing or invalid."""
    pass


DEFAULT_GEMINI_MODELS = (
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
    "gemini-flash-lite-latest",
)

DEFAULT_GROQ_MODELS = (
    "openai/gpt-oss-120b",
    "qwen/qwen3.8-27b",
    "openai/gpt-oss-20b",
)

DEFAULT_OPENROUTER_MODELS = (
    "openrouter/free",
    "google/gemma-4-26b-a4b-it:free",
)


def _model_list(plural: str, singular: str, default: tuple[str, ...]) -> tuple[str, ...]:
    raw = os.getenv(plural) or os.getenv(singular)
    if not raw:
        return default
    values = tuple(v.strip() for v in raw.split(",") if v.strip())
    return values or default


@dataclass(frozen=True)
class Settings:
    # Personal Branding & Author Details
    author_name: str = "Aman Kumar"
    author_handle: str = "@aman179102"
    author_title: str = "Systems & AI Engineer"
    github_user: str = "aman179102"
    portfolio_url: str = "https://github.com/aman179102"

    # AI API Keys & Fallback Configurations
    gemini_api_key: str = ""
    gemini_api_key_fallback: str = ""
    gemini_api_keys: tuple[str, ...] = ()

    groq_api_key: str = ""
    groq_api_key_fallback: str = ""
    groq_api_keys: tuple[str, ...] = ()

    openrouter_api_key: str = ""
    openrouter_api_key_fallback: str = ""
    openrouter_api_keys: tuple[str, ...] = ()

    gemini_models: tuple[str, ...] = DEFAULT_GEMINI_MODELS
    groq_models: tuple[str, ...] = DEFAULT_GROQ_MODELS
    openrouter_models: tuple[str, ...] = DEFAULT_OPENROUTER_MODELS

    # Telegram Bot (1-Tap Mobile Co-Pilot)
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""

    # Hacker News Autonomous Authentication
    hn_username: str = ""
    hn_password: str = ""
    hn_cookie: str = ""
    hn_auto_publish: bool = False

    # Tumblr Official API v2 Authentication
    tumblr_consumer_key: str = ""
    tumblr_consumer_secret: str = ""
    tumblr_oauth_token: str = ""
    tumblr_oauth_token_secret: str = ""
    tumblr_blog_name: str = ""
    tumblr_auto_publish: bool = False

    # itch.io Autonomous Engine
    itch_api_key: str = ""
    itch_username: str = ""
    itch_auto_publish: bool = False

    # Qiita Official API v2 Engine
    qiita_access_token: str = ""
    qiita_username: str = ""
    qiita_auto_publish: bool = False

    # Velog Official GraphQL Engine
    velog_access_token: str = ""
    velog_refresh_token: str = ""
    velog_username: str = ""
    velog_auto_publish: bool = False

    # Dev.to Official Forem API v1 Engine
    devto_api_key: str = ""
    devto_username: str = ""
    devto_auto_publish: bool = False

    # GitHub Gist Official REST API Engine
    github_gist_token: str = ""
    github_username: str = ""
    github_auto_publish: bool = False

    # Hugging Face Official REST API Engine
    huggingface_token: str = ""
    huggingface_username: str = ""
    huggingface_auto_publish: bool = False

    # Kaggle Autonomous Engine
    kaggle_api_token: str = ""
    kaggle_username: str = ""
    kaggle_auto_publish: bool = False

    # GitLab Official REST API Engine
    gitlab_token: str = ""
    gitlab_username: str = ""
    gitlab_auto_publish: bool = False

    # Codeberg Official REST API Engine
    codeberg_token: str = ""
    codeberg_username: str = ""
    codeberg_auto_publish: bool = False

    # Docker Hub Official REST API v2 Engine
    dockerhub_token: str = ""
    dockerhub_username: str = ""
    dockerhub_auto_publish: bool = False

    # PyPI Official Package Engine
    pypi_token: str = ""
    pypi_username: str = ""
    pypi_auto_publish: bool = False

    # Bluesky AT Protocol Engine
    bsky_handle: str = "aman179102.bsky.social"
    bsky_app_password: str = ""
    bsky_pds_url: str = "https://bsky.social"
    bsky_auto_publish: bool = True
    bsky_engagement_enabled: bool = True

    # Instagram Mobile API Session Engine (Hermes)
    instagram_sessionid: str = ""
    instagram_csrf: str = ""
    instagram_user_id: str = ""
    instagram_access_token: str = ""
    instagram_auto_publish: bool = True
    ig_settings_path: str = "data/ig_settings.json"

    # Mastodon / Fediverse Engine (Multi-Instance: mstdn.party + mstdn.plus)
    mastodon_instance_url: str = "https://mstdn.party"
    mastodon_access_token: str = ""
    mastodon_auto_publish: bool = True

    mastodon_plus_instance_url: str = "https://mstdn.plus"
    mastodon_plus_access_token: str = ""
    mastodon_plus_client_key: str = ""
    mastodon_plus_client_secret: str = ""
    mastodon_plus_auto_publish: bool = True
    mastodon_engagement_enabled: bool = True

    # Buffer Omnichannel Engine (LinkedIn + Twitter/X + Instagram)
    buffer_api_key: str = ""
    buffer_org_id: str = "6b06ec1467b2f24d7982f876"
    buffer_instagram_channel_id: str = "6b06f3108541f09ecb9dd6aa"
    buffer_twitter_channel_id: str = "6b06f17d8541f09ecb9dc713"
    buffer_linkedin_channel_id: str = "6b06ee488541f09ecb9da300"
    buffer_auto_publish: bool = True

    # Runtime & Paths
    timezone: str = "Asia/Kolkata"
    port: int = 10000
    render_external_url: str = ""
    state_dir: Path = field(default_factory=lambda: ROOT / "state")
    output_dir: Path = field(default_factory=lambda: ROOT / "output")

    @property
    def gemini_keys(self) -> tuple[str, ...]:
        if self.gemini_api_keys:
            return self.gemini_api_keys
        keys: list[str] = []
        if self.gemini_api_key:
            keys.append(self.gemini_api_key)
        if self.gemini_api_key_fallback and self.gemini_api_key_fallback not in keys:
            keys.append(self.gemini_api_key_fallback)
        return tuple(keys)

    @property
    def groq_keys(self) -> tuple[str, ...]:
        if self.groq_api_keys:
            return self.groq_api_keys
        keys: list[str] = []
        if self.groq_api_key:
            keys.append(self.groq_api_key)
        if self.groq_api_key_fallback and self.groq_api_key_fallback not in keys:
            keys.append(self.groq_api_key_fallback)
        return tuple(keys)

    @property
    def openrouter_keys(self) -> tuple[str, ...]:
        if self.openrouter_api_keys:
            return self.openrouter_api_keys
        keys: list[str] = []
        if self.openrouter_api_key:
            keys.append(self.openrouter_api_key)
        if self.openrouter_api_key_fallback and self.openrouter_api_key_fallback not in keys:
            keys.append(self.openrouter_api_key_fallback)
        return tuple(keys)

    @property
    def has_ai(self) -> bool:
        """Returns True if at least one AI provider API key is present."""
        return bool(self.gemini_keys or self.groq_keys or self.openrouter_keys)

    @property
    def has_telegram(self) -> bool:
        """Returns True if Telegram credentials are fully set."""
        return bool(self.telegram_bot_token and self.telegram_chat_id)

    @property
    def has_tumblr(self) -> bool:
        """Returns True if all Tumblr OAuth credentials and blog name are present."""
        return bool(
            self.tumblr_consumer_key
            and self.tumblr_consumer_secret
            and self.tumblr_oauth_token
            and self.tumblr_oauth_token_secret
            and self.tumblr_blog_name
        )

    @property
    def has_itch(self) -> bool:
        """Returns True if itch.io API key is present."""
        return bool(self.itch_api_key)

    @property
    def has_qiita(self) -> bool:
        """Returns True if Qiita access token is present."""
        return bool(self.qiita_access_token)

    @property
    def has_velog(self) -> bool:
        """Returns True if Velog authentication cookies/tokens are present."""
        return bool(self.velog_access_token or self.velog_refresh_token)

    @property
    def has_devto(self) -> bool:
        """Returns True if Dev.to API key is present."""
        return bool(self.devto_api_key)

    @property
    def has_gist(self) -> bool:
        """Returns True if GitHub Gist token is present."""
        return bool(self.github_gist_token)

    @property
    def has_huggingface(self) -> bool:
        """Returns True if Hugging Face token is present."""
        return bool(self.huggingface_token)

    @property
    def has_kaggle(self) -> bool:
        """Returns True if Kaggle API token or key is present."""
        return bool(self.kaggle_api_token)

    @property
    def has_gitlab(self) -> bool:
        """Returns True if GitLab token is present."""
        return bool(self.gitlab_token)

    @property
    def has_codeberg(self) -> bool:
        """Returns True if Codeberg token is present."""
        return bool(self.codeberg_token)

    @property
    def has_dockerhub(self) -> bool:
        """Returns True if Docker Hub PAT is present."""
        return bool(self.dockerhub_token)

    @property
    def has_pypi(self) -> bool:
        """Returns True if PyPI API token is present."""
        return bool(self.pypi_token)

    @property
    def has_bluesky(self) -> bool:
        """Returns True if Bluesky handle and app password are set."""
        return bool(self.bsky_handle and self.bsky_app_password)

    @property
    def has_instagram(self) -> bool:
        """Returns True if Instagram sessionid or access token are set."""
        return bool(self.instagram_sessionid or (self.instagram_access_token and self.instagram_user_id))


def load_settings(overrides: dict[str, Any] | None = None) -> Settings:
    """Loads application settings from environment variables and optional overrides."""
    overrides = overrides or {}

    def get_str(name: str, alt_names: tuple[str, ...] = (), default: str = "") -> str:
        for n in (name, *alt_names):
            val = os.getenv(n)
            if val is not None and val.strip():
                return val.strip()
        return default

    author_name = str(overrides.get("author_name") or get_str("AUTHOR_NAME", default="Aman Kumar"))
    author_handle = str(overrides.get("author_handle") or get_str("AUTHOR_HANDLE", default="@aman179102"))
    author_title = str(overrides.get("author_title") or get_str("AUTHOR_TITLE", default="Systems & AI Engineer"))
    github_user = str(overrides.get("github_user") or get_str("GITHUB_USER", default="aman179102"))
    portfolio_url = str(overrides.get("portfolio_url") or get_str("PORTFOLIO_URL", default=f"https://github.com/{github_user}"))

    def _collect_keys(primary_name: str, fallback_name: str, list_name: str, override_val: Any = None, override_fb: Any = None) -> tuple[str, ...]:
        keys: list[str] = []
        if override_val:
            if isinstance(override_val, (list, tuple)):
                keys.extend(str(k).strip() for k in override_val if str(k).strip())
            elif isinstance(override_val, str) and override_val.strip():
                keys.extend(k.strip() for k in override_val.split(",") if k.strip())
        if override_fb:
            fb_str = str(override_fb).strip()
            if fb_str and fb_str not in keys:
                keys.append(fb_str)

        p = get_str(primary_name)
        if p and p not in keys:
            keys.append(p)
        fb = get_str(fallback_name)
        if fb and fb not in keys:
            keys.append(fb)
        multi = get_str(list_name)
        if multi:
            for k in multi.split(","):
                k = k.strip()
                if k and k not in keys:
                    keys.append(k)
        return tuple(keys)

    gemini_keys_tuple = _collect_keys(
        "GEMINI_API_KEY", "GEMINI_API_KEY_FALLBACK", "GEMINI_API_KEYS",
        overrides.get("gemini_api_key"), overrides.get("gemini_api_key_fallback")
    )
    groq_keys_tuple = _collect_keys(
        "GROQ_API_KEY", "GROQ_API_KEY_FALLBACK", "GROQ_API_KEYS",
        overrides.get("groq_api_key"), overrides.get("groq_api_key_fallback")
    )
    openrouter_keys_tuple = _collect_keys(
        "OPENROUTER_API_KEY", "OPENROUTER_API_KEY_FALLBACK", "OPENROUTER_API_KEYS",
        overrides.get("openrouter_api_key"), overrides.get("openrouter_api_key_fallback")
    )

    gemini_key = gemini_keys_tuple[0] if gemini_keys_tuple else ""
    gemini_key_fallback = gemini_keys_tuple[1] if len(gemini_keys_tuple) > 1 else ""
    groq_key = groq_keys_tuple[0] if groq_keys_tuple else ""
    groq_key_fallback = groq_keys_tuple[1] if len(groq_keys_tuple) > 1 else ""
    openrouter_key = openrouter_keys_tuple[0] if openrouter_keys_tuple else ""
    openrouter_key_fallback = openrouter_keys_tuple[1] if len(openrouter_keys_tuple) > 1 else ""

    telegram_bot_token = str(overrides.get("telegram_bot_token") or get_str("TELEGRAM_BOT_TOKEN"))
    telegram_chat_id = str(overrides.get("telegram_chat_id") or get_str("TELEGRAM_CHAT_ID"))

    hn_username = str(overrides.get("hn_username") or get_str("HN_USERNAME"))
    hn_password = str(overrides.get("hn_password") or get_str("HN_PASSWORD"))
    hn_cookie = str(overrides.get("hn_cookie") or get_str("HN_COOKIE"))
    raw_auto = overrides.get("hn_auto_publish")
    if raw_auto is None:
        raw_auto = os.getenv("HN_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    hn_auto_publish = bool(raw_auto)

    tumblr_consumer_key = str(overrides.get("tumblr_consumer_key") or get_str("TUMBLR_CONSUMER_KEY"))
    tumblr_consumer_secret = str(overrides.get("tumblr_consumer_secret") or get_str("TUMBLR_CONSUMER_SECRET"))
    tumblr_oauth_token = str(overrides.get("tumblr_oauth_token") or get_str("TUMBLR_OAUTH_TOKEN"))
    tumblr_oauth_token_secret = str(overrides.get("tumblr_oauth_token_secret") or get_str("TUMBLR_OAUTH_TOKEN_SECRET"))
    tumblr_blog_name = str(overrides.get("tumblr_blog_name") or get_str("TUMBLR_BLOG_NAME"))
    raw_tumblr_auto = overrides.get("tumblr_auto_publish")
    if raw_tumblr_auto is None:
        raw_tumblr_auto = os.getenv("TUMBLR_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    tumblr_auto_publish = bool(raw_tumblr_auto)

    itch_api_key = str(overrides.get("itch_api_key") or get_str("ITCH_API_KEY"))
    itch_username = str(overrides.get("itch_username") or get_str("ITCH_USERNAME", default="aman179102"))
    raw_itch_auto = overrides.get("itch_auto_publish")
    if raw_itch_auto is None:
        raw_itch_auto = os.getenv("ITCH_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    itch_auto_publish = bool(raw_itch_auto)

    qiita_access_token = str(overrides.get("qiita_access_token") or get_str("QIITA_ACCESS_TOKEN"))
    qiita_username = str(overrides.get("qiita_username") or get_str("QIITA_USERNAME", default="aman179102"))
    raw_qiita_auto = overrides.get("qiita_auto_publish")
    if raw_qiita_auto is None:
        raw_qiita_auto = os.getenv("QIITA_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    qiita_auto_publish = bool(raw_qiita_auto)

    velog_access_token = str(overrides.get("velog_access_token") or get_str("VELOG_ACCESS_TOKEN"))
    velog_refresh_token = str(overrides.get("velog_refresh_token") or get_str("VELOG_REFRESH_TOKEN"))
    velog_username = str(overrides.get("velog_username") or get_str("VELOG_USERNAME", default="aman179102"))
    raw_velog_auto = overrides.get("velog_auto_publish")
    if raw_velog_auto is None:
        raw_velog_auto = os.getenv("VELOG_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    velog_auto_publish = bool(raw_velog_auto)

    devto_api_key = str(overrides.get("devto_api_key") or get_str("DEVTO_API_KEY"))
    devto_username = str(overrides.get("devto_username") or get_str("DEVTO_USERNAME", default="aman179102"))
    raw_devto_auto = overrides.get("devto_auto_publish")
    if raw_devto_auto is None:
        raw_devto_auto = os.getenv("DEVTO_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    devto_auto_publish = bool(raw_devto_auto)

    github_gist_token = str(overrides.get("github_gist_token") or get_str("GITHUB_GIST_TOKEN"))
    github_username = str(
        overrides.get("github_username")
        or get_str("GITHUB_USERNAME", alt_names=("GITHUB_USER",), default="aman179102")
    )
    raw_gist_auto = overrides.get("github_auto_publish")
    if raw_gist_auto is None:
        raw_gist_auto = os.getenv("GITHUB_AUTO_PUBLISH", os.getenv("GIST_AUTO_PUBLISH", "false")).lower() in ("true", "1", "yes")
    github_auto_publish = bool(raw_gist_auto)

    huggingface_token = str(overrides.get("huggingface_token") or get_str("HUGGINGFACE_TOKEN"))
    huggingface_username = str(
        overrides.get("huggingface_username")
        or get_str("HUGGINGFACE_USERNAME", alt_names=("HF_USERNAME", "HF_USER"), default="aman179102")
    )
    raw_hf_auto = overrides.get("huggingface_auto_publish")
    if raw_hf_auto is None:
        raw_hf_auto = os.getenv("HUGGINGFACE_AUTO_PUBLISH", os.getenv("HF_AUTO_PUBLISH", "false")).lower() in ("true", "1", "yes")
    huggingface_auto_publish = bool(raw_hf_auto)

    kaggle_api_token = str(
        overrides.get("kaggle_api_token")
        or get_str("KAGGLE_API_TOKEN", alt_names=("KAGGLE_KEY",))
    )
    kaggle_username = str(
        overrides.get("kaggle_username")
        or get_str("KAGGLE_USERNAME", alt_names=("KAGGLE_USER",), default="aman179102")
    )
    raw_kaggle_auto = overrides.get("kaggle_auto_publish")
    if raw_kaggle_auto is None:
        raw_kaggle_auto = os.getenv("KAGGLE_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    kaggle_auto_publish = bool(raw_kaggle_auto)

    gitlab_token = str(overrides.get("gitlab_token") or get_str("GITLAB_TOKEN"))
    gitlab_username = str(
        overrides.get("gitlab_username")
        or get_str("GITLAB_USERNAME", alt_names=("GITLAB_USER",), default="aman179102")
    )
    raw_gitlab_auto = overrides.get("gitlab_auto_publish")
    if raw_gitlab_auto is None:
        raw_gitlab_auto = os.getenv("GITLAB_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    gitlab_auto_publish = bool(raw_gitlab_auto)

    codeberg_token = str(overrides.get("codeberg_token") or get_str("CODEBERG_TOKEN"))
    codeberg_username = str(
        overrides.get("codeberg_username")
        or get_str("CODEBERG_USERNAME", alt_names=("CODEBERG_USER",), default="aman179102")
    )
    raw_codeberg_auto = overrides.get("codeberg_auto_publish")
    if raw_codeberg_auto is None:
        raw_codeberg_auto = os.getenv("CODEBERG_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    codeberg_auto_publish = bool(raw_codeberg_auto)

    dockerhub_token = str(
        overrides.get("dockerhub_token")
        or get_str("DOCKER_ACCESS_TOKEN", alt_names=("DOCKERHUB_TOKEN", "DOCKER_TOKEN"))
    )
    dockerhub_username = str(
        overrides.get("dockerhub_username")
        or get_str("DOCKER_USERNAME", alt_names=("DOCKERHUB_USERNAME", "DOCKER_USER"), default="aman179102")
    )
    raw_dockerhub_auto = overrides.get("dockerhub_auto_publish")
    if raw_dockerhub_auto is None:
        raw_dockerhub_auto = os.getenv("DOCKER_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    dockerhub_auto_publish = bool(raw_dockerhub_auto)

    pypi_token = str(
        overrides.get("pypi_token")
        or get_str("PYPI_API_TOKEN", alt_names=("PYPI_TOKEN",))
    )
    pypi_username = str(
        overrides.get("pypi_username")
        or get_str("PYPI_USERNAME", alt_names=("PYPI_USER",), default="aman179102")
    )
    raw_pypi_auto = overrides.get("pypi_auto_publish")
    if raw_pypi_auto is None:
        raw_pypi_auto = os.getenv("PYPI_AUTO_PUBLISH", "false").lower() in ("true", "1", "yes")
    pypi_auto_publish = bool(raw_pypi_auto)

    bsky_handle = str(overrides.get("bsky_handle") or get_str("BSKY_HANDLE", default="aman179102.bsky.social"))
    bsky_app_password = str(overrides.get("bsky_app_password") or get_str("BSKY_APP_PASSWORD"))
    bsky_pds_url = str(overrides.get("bsky_pds_url") or get_str("BSKY_PDS_URL", default="https://bsky.social"))
    raw_bsky_auto = overrides.get("bsky_auto_publish")
    if raw_bsky_auto is None:
        raw_bsky_auto = os.getenv("POSTING_ENABLED", os.getenv("BSKY_AUTO_PUBLISH", "true")).lower() in ("true", "1", "yes")
    bsky_auto_publish = bool(raw_bsky_auto)
    raw_bsky_eng = overrides.get("bsky_engagement_enabled")
    if raw_bsky_eng is None:
        raw_bsky_eng = os.getenv("ENGAGEMENT_ENABLED", "true").lower() in ("true", "1", "yes")
    bsky_engagement_enabled = bool(raw_bsky_eng)

    instagram_sessionid = str(overrides.get("instagram_sessionid") or get_str("INSTAGRAM_SESSIONID"))
    instagram_csrf = str(overrides.get("instagram_csrf") or get_str("INSTAGRAM_CSRFTOKEN", alt_names=("INSTAGRAM_CSRF",)))
    instagram_user_id = str(overrides.get("instagram_user_id") or get_str("INSTAGRAM_USER_ID"))
    instagram_access_token = str(overrides.get("instagram_access_token") or get_str("INSTAGRAM_ACCESS_TOKEN"))
    raw_ig_auto = overrides.get("instagram_auto_publish")
    if raw_ig_auto is None:
        raw_ig_auto = os.getenv("INSTAGRAM_AUTO_PUBLISH", "true").lower() in ("true", "1", "yes")
    instagram_auto_publish = bool(raw_ig_auto)
    ig_settings_path = str(overrides.get("ig_settings_path") or get_str("IG_SETTINGS_PATH", default="data/ig_settings.json"))

    mastodon_instance_url = str(overrides.get("mastodon_instance_url") or get_str("MASTODON_INSTANCE_URL", default="https://mstdn.party"))
    mastodon_access_token = str(overrides.get("mastodon_access_token") or get_str("MASTODON_ACCESS_TOKEN"))
    raw_mstdn_auto = overrides.get("mastodon_auto_publish")
    if raw_mstdn_auto is None:
        raw_mstdn_auto = os.getenv("MASTODON_AUTO_PUBLISH", "true").lower() in ("true", "1", "yes")
    mastodon_auto_publish = bool(raw_mstdn_auto)

    mastodon_plus_instance_url = str(overrides.get("mastodon_plus_instance_url") or get_str("MASTODON_PLUS_INSTANCE_URL", default="https://mstdn.plus"))
    mastodon_plus_access_token = str(overrides.get("mastodon_plus_access_token") or get_str("MASTODON_PLUS_ACCESS_TOKEN"))
    mastodon_plus_client_key = str(overrides.get("mastodon_plus_client_key") or get_str("MASTODON_PLUS_CLIENT_KEY"))
    mastodon_plus_client_secret = str(overrides.get("mastodon_plus_client_secret") or get_str("MASTODON_PLUS_CLIENT_SECRET"))
    raw_plus_auto = overrides.get("mastodon_plus_auto_publish")
    if raw_plus_auto is None:
        raw_plus_auto = os.getenv("MASTODON_PLUS_AUTO_PUBLISH", "true").lower() in ("true", "1", "yes")
    mastodon_plus_auto_publish = bool(raw_plus_auto)

    raw_mstdn_eng = overrides.get("mastodon_engagement_enabled")
    if raw_mstdn_eng is None:
        raw_mstdn_eng = os.getenv("MASTODON_ENGAGEMENT_ENABLED", "true").lower() in ("true", "1", "yes")
    mastodon_engagement_enabled = bool(raw_mstdn_eng)

    buffer_api_key = str(overrides.get("buffer_api_key") or get_str("BUFFER_API_KEY"))
    buffer_org_id = str(overrides.get("buffer_org_id") or get_str("BUFFER_ORG_ID", default="6b06ec1467b2f24d7982f876"))
    buffer_instagram_channel_id = str(overrides.get("buffer_instagram_channel_id") or get_str("BUFFER_INSTAGRAM_CHANNEL_ID", default="6b06f3108541f09ecb9dd6aa"))
    buffer_twitter_channel_id = str(overrides.get("buffer_twitter_channel_id") or get_str("BUFFER_TWITTER_CHANNEL_ID", default="6b06f17d8541f09ecb9dc713"))
    buffer_linkedin_channel_id = str(overrides.get("buffer_linkedin_channel_id") or get_str("BUFFER_LINKEDIN_CHANNEL_ID", default="6b06ee488541f09ecb9da300"))
    raw_buffer_auto = overrides.get("buffer_auto_publish")
    if raw_buffer_auto is None:
        raw_buffer_auto = os.getenv("BUFFER_AUTO_PUBLISH", "true").lower() in ("true", "1", "yes")
    buffer_auto_publish = bool(raw_buffer_auto)

    tz_str = str(overrides.get("timezone") or get_str("TIMEZONE", default="Asia/Kolkata"))
    port = int(overrides.get("port") or int(os.getenv("PORT", "10000")))
    render_external_url = str(overrides.get("render_external_url") or get_str("RENDER_EXTERNAL_URL", default=""))

    state_dir_path = overrides.get("state_dir")
    state_dir = Path(str(state_dir_path)) if state_dir_path else ROOT / "state"

    output_dir_path = overrides.get("output_dir")
    output_dir = Path(str(output_dir_path)) if output_dir_path else ROOT / "output"

    return Settings(
        author_name=author_name,
        author_handle=author_handle,
        author_title=author_title,
        github_user=github_user,
        portfolio_url=portfolio_url,
        gemini_api_key=gemini_key,
        gemini_api_key_fallback=gemini_key_fallback,
        gemini_api_keys=gemini_keys_tuple,
        groq_api_key=groq_key,
        groq_api_key_fallback=groq_key_fallback,
        groq_api_keys=groq_keys_tuple,
        openrouter_api_key=openrouter_key,
        openrouter_api_key_fallback=openrouter_key_fallback,
        openrouter_api_keys=openrouter_keys_tuple,
        gemini_models=_model_list("GEMINI_MODELS", "GEMINI_MODEL", DEFAULT_GEMINI_MODELS),
        groq_models=_model_list("GROQ_MODELS", "GROQ_MODEL", DEFAULT_GROQ_MODELS),
        openrouter_models=_model_list("OPENROUTER_MODELS", "OPENROUTER_MODEL", DEFAULT_OPENROUTER_MODELS),
        telegram_bot_token=telegram_bot_token,
        telegram_chat_id=telegram_chat_id,
        hn_username=hn_username,
        hn_password=hn_password,
        hn_cookie=hn_cookie,
        hn_auto_publish=hn_auto_publish,
        tumblr_consumer_key=tumblr_consumer_key,
        tumblr_consumer_secret=tumblr_consumer_secret,
        tumblr_oauth_token=tumblr_oauth_token,
        tumblr_oauth_token_secret=tumblr_oauth_token_secret,
        tumblr_blog_name=tumblr_blog_name,
        tumblr_auto_publish=tumblr_auto_publish,
        itch_api_key=itch_api_key,
        itch_username=itch_username,
        itch_auto_publish=itch_auto_publish,
        qiita_access_token=qiita_access_token,
        qiita_username=qiita_username,
        qiita_auto_publish=qiita_auto_publish,
        velog_access_token=velog_access_token,
        velog_refresh_token=velog_refresh_token,
        velog_username=velog_username,
        velog_auto_publish=velog_auto_publish,
        devto_api_key=devto_api_key,
        devto_username=devto_username,
        devto_auto_publish=devto_auto_publish,
        github_gist_token=github_gist_token,
        github_username=github_username,
        github_auto_publish=github_auto_publish,
        huggingface_token=huggingface_token,
        huggingface_username=huggingface_username,
        huggingface_auto_publish=huggingface_auto_publish,
        kaggle_api_token=kaggle_api_token,
        kaggle_username=kaggle_username,
        kaggle_auto_publish=kaggle_auto_publish,
        gitlab_token=gitlab_token,
        gitlab_username=gitlab_username,
        gitlab_auto_publish=gitlab_auto_publish,
        codeberg_token=codeberg_token,
        codeberg_username=codeberg_username,
        codeberg_auto_publish=codeberg_auto_publish,
        dockerhub_token=dockerhub_token,
        dockerhub_username=dockerhub_username,
        dockerhub_auto_publish=dockerhub_auto_publish,
        pypi_token=pypi_token,
        pypi_username=pypi_username,
        pypi_auto_publish=pypi_auto_publish,
        bsky_handle=bsky_handle,
        bsky_app_password=bsky_app_password,
        bsky_pds_url=bsky_pds_url,
        bsky_auto_publish=bsky_auto_publish,
        bsky_engagement_enabled=bsky_engagement_enabled,
        instagram_sessionid=instagram_sessionid,
        instagram_csrf=instagram_csrf,
        instagram_user_id=instagram_user_id,
        instagram_access_token=instagram_access_token,
        instagram_auto_publish=instagram_auto_publish,
        ig_settings_path=ig_settings_path,
        mastodon_instance_url=mastodon_instance_url,
        mastodon_access_token=mastodon_access_token,
        mastodon_auto_publish=mastodon_auto_publish,
        mastodon_plus_instance_url=mastodon_plus_instance_url,
        mastodon_plus_access_token=mastodon_plus_access_token,
        mastodon_plus_client_key=mastodon_plus_client_key,
        mastodon_plus_client_secret=mastodon_plus_client_secret,
        mastodon_plus_auto_publish=mastodon_plus_auto_publish,
        mastodon_engagement_enabled=mastodon_engagement_enabled,
        buffer_api_key=buffer_api_key,
        buffer_org_id=buffer_org_id,
        buffer_instagram_channel_id=buffer_instagram_channel_id,
        buffer_twitter_channel_id=buffer_twitter_channel_id,
        buffer_linkedin_channel_id=buffer_linkedin_channel_id,
        buffer_auto_publish=buffer_auto_publish,
        timezone=tz_str,
        port=port,
        render_external_url=render_external_url,
        state_dir=state_dir,
        output_dir=output_dir,
    )
