"""Universal Stock Image Watermarking & Lifecycle Engine.

Guarantees:
1. High-resolution, premium technical stock photography (servers, Linux, code, terminals, workstations).
2. Zero personal self-photos.
3. Aesthetic Tokyo Night frosted watermark pill: '⚡ @aman179102'.
4. Zero repeated images: Tracks used images in state/used_stock_images.json.
5. Permanent public CDN uploads via catbox.moe for Buffer and direct local paths for Mastodon.
"""
from __future__ import annotations

import hashlib
import io
import json
import logging
import random
from pathlib import Path
from typing import Optional

import httpx
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont

from common.state import load_state, save_state

logger = logging.getLogger(__name__)

ROOT_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT_DIR / "output" / "watermarked"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
STATE_FILE = ROOT_DIR / "state" / "used_stock_images.json"

# Curated High-Resolution Technical & Systems Stock Photos (Unsplash Verified Direct URLs)
# No personal self-photos, pure premium developer/engineering aesthetics:
CURATED_TECH_STOCK_PHOTOS = [
    "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&h=800&fit=crop", # Tokyo Night code editor
    "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=1200&h=800&fit=crop", # Enterprise cloud datacenter rack
    "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=1200&h=800&fit=crop", # Developer laptop with terminal
    "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1200&h=800&fit=crop", # Matrix cybersecurity data stream
    "https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200&h=800&fit=crop", # Microprocessor silicon wafer & traces
    "https://images.unsplash.com/photo-1504639725590-34d0984388bd?w=1200&h=800&fit=crop", # Clean minimalist developer desk & coffee
    "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=1200&h=800&fit=crop", # Web architecture monitor & code
    "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=1200&h=800&fit=crop", # Server room fiber optic glowing cables
    "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?w=1200&h=800&fit=crop", # Python code on dark screen
    "https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=1200&h=800&fit=crop", # System design flowchart & wireframes
    "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=1200&h=800&fit=crop", # Cybersecurity circuit glowing lines
    "https://images.unsplash.com/photo-1629654297299-c8506221ca97?w=1200&h=800&fit=crop", # Linux command terminal & bash shell
    "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=1200&h=800&fit=crop", # Tech engineer building hardware system
    "https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=1200&h=800&fit=crop", # Clean setup with mechanical keyboard
    "https://images.unsplash.com/photo-1607799279861-4dd421887fb3?w=1200&h=800&fit=crop", # Coding algorithm on IDE
    "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=1200&h=800&fit=crop", # Network architecture dashboard metrics
    "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=1200&h=800&fit=crop", # Tech workspace with dual monitors
    "https://images.unsplash.com/photo-1542838132-92c53300491e?w=1200&h=800&fit=crop", # Colorful syntax highlighting on screen
    "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=800&fit=crop", # Data analytics graph & metrics
    "https://images.unsplash.com/photo-1526374879815-568913e64887?w=1200&h=800&fit=crop", # Terminal and cyber matrix code
    "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1200&h=800&fit=crop", # Cloud platform dashboard
]


def _get_font(size: int = 24) -> ImageFont.FreeTypeFont:
    font_path = ROOT_DIR / "assets" / "fonts" / "JetBrainsMono-Medium.ttf"
    if font_path.exists():
        try:
            return ImageFont.truetype(str(font_path), size)
        except Exception:
            pass
    fallback_path = ROOT_DIR / "assets" / "fonts" / "Inter-Bold.ttf"
    if fallback_path.exists():
        try:
            return ImageFont.truetype(str(fallback_path), size)
        except Exception:
            pass
    return ImageFont.load_default()  # type: ignore


def watermark_image(image_bytes: bytes, watermark_text: str = "⚡ @aman179102") -> Path:
    """Applies a professional Tokyo Night frosted glass watermark badge to an image."""
    img = Image.open(io.BytesIO(image_bytes)).convert("RGBA")

    # Resize if excessive
    max_w, max_h = 1600, 1000
    if img.width > max_w or img.height > max_h:
        img.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)

    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    font_size = max(20, int(img.width * 0.022))
    font = _get_font(font_size)

    bbox = draw.textbbox((0, 0), watermark_text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]

    pad_x = int(font_size * 0.75)
    pad_y = int(font_size * 0.45)
    margin = int(font_size * 1.1)

    bx2 = img.width - margin
    by2 = img.height - margin
    bx1 = bx2 - tw - (pad_x * 2)
    by1 = by2 - th - (pad_y * 2)

    # Tokyo Night dark frosted pill with neon cyan/blue accent border
    draw.rounded_rectangle(
        [bx1, by1, bx2, by2],
        radius=int(font_size * 0.4),
        fill=(26, 27, 38, 230),            # #1a1b26 semi-transparent
        outline=(122, 162, 247, 240),       # #7aa2f7 glowing accent
        width=2,
    )

    draw.text(
        (bx1 + pad_x, by1 + pad_y - 2),
        watermark_text,
        font=font,
        fill=(192, 202, 245, 255),          # #c0caf5 crisp primary text
    )

    final = Image.alpha_composite(img, overlay).convert("RGB")

    hasher = hashlib.md5(image_bytes).hexdigest()[:12]
    out_path = OUTPUT_DIR / f"stock_{hasher}.jpg"
    final.save(out_path, format="JPEG", quality=95, optimize=True)
    return out_path


def upload_to_catbox(file_path: Path, timeout: float = 25.0) -> str:
    """Uploads local image to catbox.moe for permanent direct CDN hosting."""
    url = "https://catbox.moe/user/api.php"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
    with open(file_path, "rb") as f:
        with httpx.Client(timeout=timeout, headers=headers) as client:
            resp = client.post(
                url,
                data={"reqtype": "fileupload"},
                files={"fileToUpload": (file_path.name, f, "image/jpeg")},
            )
            resp.raise_for_status()
            cdn_url = resp.text.strip()
            if not cdn_url.startswith("http"):
                raise RuntimeError(f"Unexpected catbox response: {cdn_url}")
            return cdn_url


def get_next_watermarked_stock_image(
    platform: str = "general",
    watermark_text: str = "⚡ @aman179102",
) -> tuple[Path, str]:
    """
    Selects the next unused premium stock photo, applies the watermark,
    uploads to permanent CDN, and marks as used.
    
    Returns: (local_file_path, public_cdn_url)
    """
    state = load_state(STATE_FILE)
    used_urls = set(state.get("used_urls", []))

    # Find candidates not yet used
    candidates = [u for u in CURATED_TECH_STOCK_PHOTOS if u not in used_urls]
    if not candidates:
        logger.info("All curated stock photos have been used. Resetting rotation.")
        used_urls = set()
        candidates = list(CURATED_TECH_STOCK_PHOTOS)

    selected_url = random.choice(candidates)

    # Download source stock photo
    with httpx.Client(timeout=20.0) as client:
        resp = client.get(selected_url)
        resp.raise_for_status()
        raw_bytes = resp.content

    # Apply watermark
    local_path = watermark_image(raw_bytes, watermark_text=watermark_text)

    # Upload to CDN for Buffer
    try:
        cdn_url = upload_to_catbox(local_path)
    except Exception as exc:
        logger.warning("Catbox upload failed: %s. Using source URL fallback.", exc)
        cdn_url = selected_url

    # Save used state
    used_urls.add(selected_url)
    state["used_urls"] = list(used_urls)
    state["last_used_url"] = selected_url
    state["last_platform"] = platform
    save_state(STATE_FILE, state)

    logger.info("Prepared unique watermarked stock photo for %s: %s (CDN: %s)", platform, local_path.name, cdn_url)
    return local_path, cdn_url


def format_instagram_meme(
    image_bytes: bytes,
    watermark_text: str = "⚡ @aman179102",
) -> Path:
    """Formats an arbitrary meme image into exact Instagram-supported dimensions.

    Guarantees:
    - 0% Cropping: The complete meme (text, jokes, multi-panels) fits inside the supported Instagram bounds.
    - Standard Dimensions:
        * 1080 x 1350 px (4:5 Portrait) for vertical or square-ish memes (aspect ratio <= 1.05).
        * 1080 x 1080 px (1:1 Square) for wide/landscape memes (aspect ratio > 1.05).
    - Ambient Theme Background: Sleek darkened Gaussian-blurred backdrop with soft drop-shadow.
    - Watermark Badge: Tokyo Night frosted badge with glowing cyan accent.
    - Output: Optimized sRGB JPEG format at 95% quality.
    """
    orig = Image.open(io.BytesIO(image_bytes)).convert("RGBA")
    aspect_ratio = orig.width / orig.height

    # Choose best Instagram canvas
    if aspect_ratio <= 1.05:
        canvas_w, canvas_h = 1080, 1350  # 4:5 Portrait (Maximum mobile screen real estate)
    else:
        canvas_w, canvas_h = 1080, 1080  # 1:1 Square (Clean for landscape/wide memes)

    # Ambient blurred background
    bg_scale = max(canvas_w / orig.width, canvas_h / orig.height)
    bg_w = int(orig.width * bg_scale)
    bg_h = int(orig.height * bg_scale)
    bg = orig.resize((bg_w, bg_h), Image.Resampling.LANCZOS)
    bg_x = (bg_w - canvas_w) // 2
    bg_y = (bg_h - canvas_h) // 2
    bg = bg.crop((bg_x, bg_y, bg_x + canvas_w, bg_y + canvas_h))
    bg = bg.filter(ImageFilter.GaussianBlur(radius=45))

    # Darken background to 35% brightness for optimal contrast and readability
    enhancer = ImageEnhance.Brightness(bg.convert("RGB"))
    bg = enhancer.enhance(0.35).convert("RGBA")

    # Fit foreground meme cleanly with padding
    pad_x = 36
    pad_y = 50
    max_w = canvas_w - (pad_x * 2)
    max_h = canvas_h - (pad_y * 2) - 45  # Leave bottom margin for watermark badge
    scale = min(max_w / orig.width, max_h / orig.height)
    fg_w = int(orig.width * scale)
    fg_h = int(orig.height * scale)
    fg = orig.resize((fg_w, fg_h), Image.Resampling.LANCZOS)

    pos_x = (canvas_w - fg_w) // 2
    pos_y = (canvas_h - fg_h) // 2 - 20

    # Soft ambient drop shadow around the meme
    shadow = Image.new("RGBA", (fg_w + 30, fg_h + 30), (0, 0, 0, 0))
    s_draw = ImageDraw.Draw(shadow)
    s_draw.rectangle([15, 15, fg_w + 15, fg_h + 15], fill=(0, 0, 0, 150))
    shadow = shadow.filter(ImageFilter.GaussianBlur(radius=16))

    bg.paste(shadow, (pos_x - 15, pos_y - 15), shadow)
    bg.paste(fg, (pos_x, pos_y), fg if fg.mode == "RGBA" else None)

    # Tokyo Night Watermark Badge in bottom corner
    font_size = 24
    font = _get_font(font_size)
    draw = ImageDraw.Draw(bg)
    bbox = draw.textbbox((0, 0), watermark_text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]

    bx2 = canvas_w - 30
    by2 = canvas_h - 30
    bx1 = bx2 - tw - 34
    by1 = by2 - th - 18

    draw.rounded_rectangle(
        [bx1, by1, bx2, by2],
        radius=10,
        fill=(26, 27, 38, 235),
        outline=(122, 162, 247, 240),
        width=2,
    )
    draw.text((bx1 + 17, by1 + 7), watermark_text, font=font, fill=(192, 202, 245, 255))

    final = bg.convert("RGB")
    hasher = hashlib.md5(image_bytes).hexdigest()[:12]
    out_path = OUTPUT_DIR / f"ig_meme_{hasher}.jpg"
    final.save(out_path, format="JPEG", quality=95, optimize=True)
    return out_path


DEFAULT_BROWSER_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
}


def prepare_instagram_meme_canvas(
    image_url: str,
    watermark_text: str = "⚡ @aman179102",
    timeout: float = 20.0,
) -> tuple[Path, str]:
    """Downloads an arbitrary meme image, formats it into exact Instagram dimensions,
    uploads to Catbox CDN, and returns (local_file_path, public_cdn_url)."""
    with httpx.Client(timeout=timeout, headers=DEFAULT_BROWSER_HEADERS, follow_redirects=True) as client:
        resp = client.get(image_url)
        resp.raise_for_status()
        raw_bytes = resp.content

    local_path = format_instagram_meme(raw_bytes, watermark_text=watermark_text)
    try:
        cdn_url = upload_to_catbox(local_path)
    except Exception as exc:
        logger.warning("Catbox upload failed for Instagram meme: %s. Falling back to source URL.", exc)
        cdn_url = image_url

    logger.info("Formatted Instagram meme canvas (%s): %s -> %s", local_path.name, image_url, cdn_url)
    return local_path, cdn_url
