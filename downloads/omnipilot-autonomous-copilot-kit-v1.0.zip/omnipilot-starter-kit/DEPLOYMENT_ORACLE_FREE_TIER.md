# ☁️ 24/7 Always-Free Deployment Guide: Oracle Cloud Infrastructure (OCI)

This guide walks you through deploying **OmniPilot OS** on an **Oracle Cloud Always-Free** Virtual Machine so it runs continuously 24/7/365 at **$0.00/month**.

---

## 📋 Prerequisites
1. An **Oracle Cloud Free Tier Account** (Register at [cloud.oracle.com/free](https://www.oracle.com/cloud/free/)).
2. An SSH key pair on your local machine (`ssh-keygen -t ed25519 -C "omnipilot-vm"`).
3. A Telegram Bot token (from [@BotFather](https://t.me/BotFather)) and your Telegram User ID (from [@userinfobot](https://t.me/userinfobot)).
4. A Google Gemini API key from [Google AI Studio](https://aistudio.google.com/).

---

## 🛠️ Step 1: Provision the Free-Tier Compute Instance

1. Log into your **Oracle Cloud Console**.
2. Navigate to **Compute** > **Instances** > Click **Create Instance**.
3. Configure the VM settings:
   - **Name**: `omnipilot-vm`
   - **Image**: `Canonical Ubuntu 24.04 Minimal` or `Ubuntu 22.04 LTS`
   - **Shape**:
     - *Recommended*: **VM.Standard.A1.Flex** (Ampere ARM, select 1 to 4 OCPUs, 6 to 24 GB RAM — Always Free eligible).
     - *Alternative*: **VM.Standard.E2.1.Micro** (AMD, 1 OCPU, 1 GB RAM — Always Free eligible).
   - **Networking**:
     - Virtual Cloud Network (VCN): Create new or select default VCN.
     - Subnet: Public subnet.
     - Assign a public IPv4 address: **Yes**.
   - **Add SSH Keys**:
     - Upload your public key (`~/.ssh/id_ed25519.pub` or `~/.ssh/id_rsa.pub`).
4. Click **Create** and wait 60–90 seconds for the state to turn **Running**.
5. Note down the **Public IP Address** of your instance.

---

## 🔐 Step 2: Connect to your VM via SSH

On your local terminal, connect to your instance:

```bash
ssh -i ~/.ssh/id_ed25519 ubuntu@<YOUR_INSTANCE_PUBLIC_IP>
```

*(If you get a permissions warning on the key, run `chmod 600 ~/.ssh/id_ed25519` first.)*

---

## 📦 Step 3: Install Core Prerequisites

Update packages and install Python 3, Git, and build essentials:

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3 python3-pip python3-venv git curl ufw
```

---

## 🚀 Step 4: Transfer or Clone OmniPilot

Transfer the OmniPilot starter kit archive from your local machine to the VM:

```bash
# Run this from your local machine where omnipilot-starter-kit is located:
scp -i ~/.ssh/id_ed25519 omnipilot-autonomous-copilot-kit-v1.0.zip ubuntu@<YOUR_INSTANCE_PUBLIC_IP>:~/
```

On the VM:

```bash
sudo apt install -y unzip
unzip omnipilot-autonomous-copilot-kit-v1.0.zip -d omnipilot
cd omnipilot/omnipilot-starter-kit
```

---

## ⚙️ Step 5: Run 1-Click Installer & Configure `.env`

1. Run the automated installer:
   ```bash
   chmod +x install.sh
   ./install.sh
   ```

2. Configure your environment credentials:
   ```bash
   nano .env
   ```

3. Fill in your keys:
   ```ini
   GEMINI_API_KEY=AIzaSy...your_gemini_key
   GEMINI_API_KEY_2=AIzaSy...optional_backup_key
   TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHI...
   TELEGRAM_CHAT_ID=your_chat_id
   PORTFOLIO_URL=https://yourportfolio.com
   RUN_CADENCE_MINUTES=15
   DRY_RUN=false
   ```
   Save with `Ctrl+O`, Enter, and exit with `Ctrl+X`.

---

## 🧪 Step 6: Test Execution in Dry-Run Mode

Verify that Gemini API and Telegram connectivity work properly:

```bash
source .venv/bin/activate

# Test LinkedIn copilot generator
python3 main.py --linkedin-radar --dry-run

# Test Quora copilot generator
python3 main.py --quora-radar --dry-run
```

You should see clean formatted opportunity summaries in your console!

---

## 🛡️ Step 7: Enable 24/7 Background Systemd Daemons

To keep OmniPilot operating autonomously after you disconnect from SSH:

1. Copy systemd unit templates:
   ```bash
   # Replace /path/to with current directory path in service files if needed:
   sed -i "s|/home/devaman/Videos/free-automations|$PWD|g" systemd/*.service
   sed -i "s|User=devaman|User=ubuntu|g" systemd/*.service

   sudo cp systemd/free-automations.service /etc/systemd/system/
   sudo cp systemd/hermes.service /etc/systemd/system/
   ```

2. Reload systemd daemon and activate services:
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable --now free-automations.service
   sudo systemctl enable --now hermes.service
   ```

3. Verify service status:
   ```bash
   sudo systemctl status free-automations.service hermes.service
   ```

Both services should display: `Active: active (running)`.

---

## 📊 Step 8: View Real-Time Logs

To monitor your copilot running in real-time from anywhere:

```bash
# View background automation radar logs:
journalctl -u free-automations.service -f -n 50

# View on-demand Hermes Telegram bot logs:
journalctl -u hermes.service -f -n 50
```

---

## 💡 Maintenance & Upgrades

- **Restarting Services**:
  ```bash
  sudo systemctl restart free-automations.service hermes.service
  ```
- **Checking State Persistence**:
  ```bash
  cat state/linkedin_state.json
  cat state/quora_state.json
  ```
- **Memory Footprint**:
  OmniPilot uses less than 60MB RAM, allowing it to run smoothly alongside any other web server or database on your free instance.
