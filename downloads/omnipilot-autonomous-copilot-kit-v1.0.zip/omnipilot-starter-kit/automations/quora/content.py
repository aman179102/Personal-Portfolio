"""Quora Content Engine & Technical Answer Generator.

Provides high-signal, deeply authoritative technical answers to evergreen Quora questions
across Systems Architecture, Python Performance, Linux Kernel, Database Internals, and Career.
"""
from __future__ import annotations

import logging
import random
from typing import Any

from common.ai import generate_text
from common.config import Settings

logger = logging.getLogger(__name__)

CURATED_QUORA_QUESTIONS: list[dict[str, Any]] = [
    {
        "id": 'quora_sys_01',
        "question": 'What is the difference between epoll and io_uring in Linux network programming?',
        "category": 'Linux Kernel & Networking',
        "slug": 'What-is-the-difference-between-epoll-and-io_uring-in-Linux',
        "direct_answer_url": 'https://www.quora.com/What-is-the-difference-between-epoll-and-io_uring-in-Linux/answer',
        "question_url": 'https://www.quora.com/What-is-the-difference-between-epoll-and-io_uring-in-Linux',
        "quora_url": 'https://www.quora.com/What-is-the-difference-between-epoll-and-io_uring-in-Linux/answer',
        "tags": ['Linux', 'Operating Systems', 'Computer Networking', 'Systems Programming'],
        "allow_portfolio_link": True,
    },
    {
        "id": 'quora_py_01',
        "question": 'Why is Python considered slow, and how do engineers optimize it for high-concurrency systems?',
        "category": 'Python & High Performance',
        "slug": 'Why-is-Python-considered-slow-and-how-can-it-be-optimized-for-high-concurrency',
        "direct_answer_url": 'https://www.quora.com/Why-is-Python-considered-slow-and-how-can-it-be-optimized-for-high-concurrency/answer',
        "question_url": 'https://www.quora.com/Why-is-Python-considered-slow-and-how-can-it-be-optimized-for-high-concurrency',
        "quora_url": 'https://www.quora.com/Why-is-Python-considered-slow-and-how-can-it-be-optimized-for-high-concurrency/answer',
        "tags": ['Python', 'FastAPI', 'Asyncio', 'Software Optimization'],
        "allow_portfolio_link": True,
    },
    {
        "id": 'quora_arch_01',
        "question": 'When should a startup transition from a monolithic architecture to microservices?',
        "category": 'Software Architecture',
        "slug": 'When-should-a-startup-transition-from-a-monolith-to-microservices',
        "direct_answer_url": 'https://www.quora.com/When-should-a-startup-transition-from-a-monolith-to-microservices/answer',
        "question_url": 'https://www.quora.com/When-should-a-startup-transition-from-a-monolith-to-microservices',
        "quora_url": 'https://www.quora.com/When-should-a-startup-transition-from-a-monolith-to-microservices/answer',
        "tags": ['Software Architecture', 'Microservices', 'System Design', 'Startups'],
        "allow_portfolio_link": False,
    },
    {
        "id": 'quora_db_01',
        "question": 'How do B-Trees compare to LSM-Trees in modern database storage engines?',
        "category": 'Database Internals',
        "slug": 'How-do-B-Trees-compare-to-LSM-Trees-in-modern-databases',
        "direct_answer_url": 'https://www.quora.com/How-do-B-Trees-compare-to-LSM-Trees-in-modern-databases/answer',
        "question_url": 'https://www.quora.com/How-do-B-Trees-compare-to-LSM-Trees-in-modern-databases',
        "quora_url": 'https://www.quora.com/How-do-B-Trees-compare-to-LSM-Trees-in-modern-databases/answer',
        "tags": ['Databases', 'PostgreSQL', 'Data Structures', 'Storage Engines'],
        "allow_portfolio_link": False,
    },
    {
        "id": 'quora_sys_02',
        "question": 'How do you design an idempotent payment processing system that survives network timeouts?',
        "category": 'Distributed Systems',
        "slug": 'How-do-you-design-an-idempotent-payment-processing-system',
        "direct_answer_url": 'https://www.quora.com/How-do-you-design-an-idempotent-payment-processing-system/answer',
        "question_url": 'https://www.quora.com/How-do-you-design-an-idempotent-payment-processing-system',
        "quora_url": 'https://www.quora.com/How-do-you-design-an-idempotent-payment-processing-system/answer',
        "tags": ['Distributed Systems', 'System Design', 'Fintech', 'Software Architecture'],
        "allow_portfolio_link": True,
    },
    {
        "id": 'quora_career_01',
        "question": 'What technical skills and mindset differentiate a Senior Software Engineer from a Mid-Level Engineer?',
        "category": 'Engineering Career & Leadership',
        "slug": 'What-differentiates-a-Senior-Software-Engineer-from-a-Mid-Level-Engineer',
        "direct_answer_url": 'https://www.quora.com/What-differentiates-a-Senior-Software-Engineer-from-a-Mid-Level-Engineer/answer',
        "question_url": 'https://www.quora.com/What-differentiates-a-Senior-Software-Engineer-from-a-Mid-Level-Engineer',
        "quora_url": 'https://www.quora.com/What-differentiates-a-Senior-Software-Engineer-from-a-Mid-Level-Engineer/answer',
        "tags": ['Software Engineering', 'Career Advice', 'Tech Leadership', 'Coding'],
        "allow_portfolio_link": False,
    },
    {
        "id": 'quora_py_02',
        "question": 'How does Python handle memory management and generational garbage collection for cyclic references?',
        "category": 'Python Internals',
        "slug": 'How-does-Python-handle-memory-management-and-garbage-collection',
        "direct_answer_url": 'https://www.quora.com/How-does-Python-handle-memory-management-and-garbage-collection/answer',
        "question_url": 'https://www.quora.com/How-does-Python-handle-memory-management-and-garbage-collection',
        "quora_url": 'https://www.quora.com/How-does-Python-handle-memory-management-and-garbage-collection/answer',
        "tags": ['Python', 'Memory Management', 'Compilers', 'Computer Science'],
        "allow_portfolio_link": True,
    },
    {
        "id": 'quora_arch_02',
        "question": 'What is the Strangler Fig pattern and how is it used to safely migrate legacy systems?',
        "category": 'Software Architecture',
        "slug": 'What-is-the-Strangler-Fig-pattern-and-how-is-it-used-in-software-architecture',
        "direct_answer_url": 'https://www.quora.com/What-is-the-Strangler-Fig-pattern-and-how-is-it-used-in-software-architecture/answer',
        "question_url": 'https://www.quora.com/What-is-the-Strangler-Fig-pattern-and-how-is-it-used-in-software-architecture',
        "quora_url": 'https://www.quora.com/What-is-the-Strangler-Fig-pattern-and-how-is-it-used-in-software-architecture/answer',
        "tags": ['Software Architecture', 'Refactoring', 'DevOps', 'Legacy Systems'],
        "allow_portfolio_link": False,
    },
    {
        "id": 'quora_linux_01',
        "question": 'How do Linux systemd unit files manage reliable background daemons with MemoryMax limits?',
        "category": 'Linux & DevOps',
        "slug": 'How-do-Linux-systemd-unit-files-manage-background-services-and-memory-limits',
        "direct_answer_url": 'https://www.quora.com/How-do-Linux-systemd-unit-files-manage-background-services-and-memory-limits/answer',
        "question_url": 'https://www.quora.com/How-do-Linux-systemd-unit-files-manage-background-services-and-memory-limits',
        "quora_url": 'https://www.quora.com/How-do-Linux-systemd-unit-files-manage-background-services-and-memory-limits/answer',
        "tags": ['Linux', 'Systemd', 'DevOps', 'Server Administration'],
        "allow_portfolio_link": True,
    },
    {
        "id": 'quora_db_02',
        "question": 'How do Bloom Filters eliminate unnecessary disk lookups in high-throughput database engines?',
        "category": 'Data Structures & Storage',
        "slug": 'How-do-Bloom-filters-work-and-why-are-they-used-in-databases',
        "direct_answer_url": 'https://www.quora.com/How-do-Bloom-filters-work-and-why-are-they-used-in-databases/answer',
        "question_url": 'https://www.quora.com/How-do-Bloom-filters-work-and-why-are-they-used-in-databases',
        "quora_url": 'https://www.quora.com/How-do-Bloom-filters-work-and-why-are-they-used-in-databases/answer',
        "tags": ['Data Structures', 'Algorithms', 'Databases', 'Cassandra'],
        "allow_portfolio_link": False,
    },
    {
        "id": 'quora_py_03',
        "question": 'What are the performance implications of Python 3.13 free-threading and removing the GIL?',
        "category": 'Python Internals & Concurrency',
        "slug": 'What-are-the-implications-of-removing-the-GIL-in-Python-3-13',
        "direct_answer_url": 'https://www.quora.com/What-are-the-implications-of-removing-the-GIL-in-Python-3-13/answer',
        "question_url": 'https://www.quora.com/What-are-the-implications-of-removing-the-GIL-in-Python-3-13',
        "quora_url": 'https://www.quora.com/What-are-the-implications-of-removing-the-GIL-in-Python-3-13/answer',
        "tags": ['Python', 'Multithreading', 'GIL', 'Software Performance'],
        "allow_portfolio_link": True,
    },
    {
        "id": 'quora_dist_01',
        "question": 'What are the hidden pitfalls of using Redis for distributed locks (Redlock)?',
        "category": 'Distributed Systems & Reliability',
        "slug": 'What-are-the-drawbacks-of-using-Redis-for-distributed-locks',
        "direct_answer_url": 'https://www.quora.com/What-are-the-drawbacks-of-using-Redis-for-distributed-locks/answer',
        "question_url": 'https://www.quora.com/What-are-the-drawbacks-of-using-Redis-for-distributed-locks',
        "quora_url": 'https://www.quora.com/What-are-the-drawbacks-of-using-Redis-for-distributed-locks/answer',
        "tags": ['Redis', 'Distributed Systems', 'Concurrency', 'Software Engineering'],
        "allow_portfolio_link": False,
    },
    {
        "id": 'quora_db_03',
        "question": 'Why does PostgreSQL use a process-per-connection model and when is PgBouncer mandatory?',
        "category": 'Database Architecture',
        "slug": 'Why-does-PostgreSQL-use-process-per-connection-and-when-is-PgBouncer-needed',
        "direct_answer_url": 'https://www.quora.com/Why-does-PostgreSQL-use-process-per-connection-and-when-is-PgBouncer-needed/answer',
        "question_url": 'https://www.quora.com/Why-does-PostgreSQL-use-process-per-connection-and-when-is-PgBouncer-needed',
        "quora_url": 'https://www.quora.com/Why-does-PostgreSQL-use-process-per-connection-and-when-is-PgBouncer-needed/answer',
        "tags": ['PostgreSQL', 'Database Administration', 'Scalability', 'Backend Development'],
        "allow_portfolio_link": True,
    },
    {
        "id": 'quora_arch_03',
        "question": 'How do gRPC and Protocol Buffers compare to JSON REST APIs in microservices?',
        "category": 'Microservices & Networking',
        "slug": 'How-does-gRPC-compare-to-REST-APIs-in-microservices',
        "direct_answer_url": 'https://www.quora.com/How-does-gRPC-compare-to-REST-APIs-in-microservices/answer',
        "question_url": 'https://www.quora.com/How-does-gRPC-compare-to-REST-APIs-in-microservices',
        "quora_url": 'https://www.quora.com/How-does-gRPC-compare-to-REST-APIs-in-microservices/answer',
        "tags": ['Microservices', 'gRPC', 'APIs', 'HTTP/2'],
        "allow_portfolio_link": False,
    },
    {
        "id": 'quora_career_02',
        "question": 'How do software engineers effectively write Architecture Decision Records (ADRs)?',
        "category": 'Engineering Best Practices',
        "slug": 'How-do-software-engineers-write-effective-Architecture-Decision-Records',
        "direct_answer_url": 'https://www.quora.com/How-do-software-engineers-write-effective-Architecture-Decision-Records/answer',
        "question_url": 'https://www.quora.com/How-do-software-engineers-write-effective-Architecture-Decision-Records',
        "quora_url": 'https://www.quora.com/How-do-software-engineers-write-effective-Architecture-Decision-Records/answer',
        "tags": ['Software Architecture', 'System Design', 'Engineering Management', 'Documentation'],
        "allow_portfolio_link": True,
    },
    {
        "id": 'quora_net_01',
        "question": 'Why is Server-Sent Events (SSE) often better than WebSockets for real-time dashboards?',
        "category": 'Web Networking & APIs',
        "slug": 'Why-is-Server-Sent-Events-SSE-better-than-WebSockets-for-unidirectional-streaming',
        "direct_answer_url": 'https://www.quora.com/Why-is-Server-Sent-Events-SSE-better-than-WebSockets-for-unidirectional-streaming/answer',
        "question_url": 'https://www.quora.com/Why-is-Server-Sent-Events-SSE-better-than-WebSockets-for-unidirectional-streaming',
        "quora_url": 'https://www.quora.com/Why-is-Server-Sent-Events-SSE-better-than-WebSockets-for-unidirectional-streaming/answer',
        "tags": ['WebSockets', 'Server-Sent Events', 'HTTP/2', 'Web Development'],
        "allow_portfolio_link": False,
    },
]


def generate_quora_answer(
    topic_or_input: Any,
    settings: Settings,
    include_canonical: bool = False,
) -> str:
    """
    Generates a high-IQ, authoritative Quora answer.
    Formatted with markdown headings, concise bullet points, and code/trade-offs.
    """
    question_text = ""
    category = "Systems & Software Engineering"
    allow_link = False

    if isinstance(topic_or_input, dict):
        question_text = topic_or_input.get("question", "")
        category = topic_or_input.get("category", category)
        allow_link = topic_or_input.get("allow_portfolio_link", False)
    elif isinstance(topic_or_input, str):
        question_text = topic_or_input.strip()

    if not question_text:
        return "Could not determine question text for Quora answer generation."

    link_instruction = ""
    if include_canonical and allow_link:
        link_instruction = (
            "- NATURAL AUTHORITY CITATION: At the end of the answer, add a 1-sentence natural reference "
            "pointing to your canonical engineering hub for practical benchmarks (e.g. 'For code benchmarks and low-level systems architectures, I document these patterns at https://aman179102.netlify.app.')."
        )
    else:
        link_instruction = "- NO promotional links or URLs. Answer purely on technical merit and authority."

    system_prompt = (
        "You are Aman Kumar (@aman179102), a Senior Full-Stack & Systems Software Engineer. "
        "Write a deeply authoritative, highly readable, and practical answer for Quora.\n\n"
        "Quora Answer Requirements:\n"
        "1. Start directly with the core technical insight—do NOT use fluff ('Great question!', 'In my opinion').\n"
        "2. Break down the answer using clear bold sections (e.g. **The Core Mechanism**, **Practical Trade-offs in Production**, **Key Takeaway**).\n"
        "3. Focus on real systems patterns, low-level kernel/network realities, or practical engineering benchmarks.\n"
        "4. Keep the tone conversational, objective, and deeply practitioner-informed.\n"
        "5. Avoid invented personal employers or fake war stories. Speak from first-principles systems engineering.\n"
        f"{link_instruction}\n"
        "6. Target word count: 140–220 words. Concise, crisp, and high-impact."
    )

    user_prompt = f"Question: \"{question_text}\"\nDomain: {category}\n\nDraft the complete Quora answer."

    try:
        raw_answer = generate_text(settings, system_prompt, user_prompt, temperature=0.6)
        if raw_answer and len(raw_answer.strip()) > 80:
            return raw_answer.strip()
    except Exception as exc:
        logger.warning("AI generation failed for Quora answer: %s", exc)

    return (
        f"**The Fundamental Architectural Trade-off**\n\n"
        f"When addressing {question_text.lower()}, the critical factor comes down to balancing system complexity "
        f"with real operational requirements. Premature optimization often adds unnecessary maintenance overhead.\n\n"
        f"• **Identify the True Bottleneck:** Measure real I/O latency, memory allocation profiles, and throughput limits before changing patterns.\n"
        f"• **Preserve Clear Boundaries:** Keep components modular so that low-level optimizations can be applied incrementally without ripple effects.\n\n"
        f"Focusing on measurable production metrics consistently yields more resilient architectures than following industry hype."
    )
