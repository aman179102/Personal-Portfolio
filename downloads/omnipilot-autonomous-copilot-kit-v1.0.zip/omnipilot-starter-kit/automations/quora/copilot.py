"""Quora 1-Tap Mobile Copilot & Telegram Alert Dispatcher."""
from __future__ import annotations

import html
import logging
from typing import Any

from common.config import Settings
from common.telegram import build_inline_keyboard, send_telegram_message
from automations.quora.content import generate_quora_answer

logger = logging.getLogger(__name__)


def format_quora_opportunity_message(
    topic: dict[str, Any],
    answer_text: str,
    slot_label: str = "Active Wave",
    daily_count: int = 1,
    max_daily: int = 4,
) -> tuple[str, dict[str, Any]]:
    """
    Formats the Telegram alert with HTML and monospaced <code> block.
    In mobile Telegram (Android/iOS), tapping text inside <code> instantly copies it to clipboard!
    """
    escaped_question = html.escape(topic.get("question", "Technical Systems Architecture"))
    escaped_category = html.escape(topic.get("category", "Systems Engineering"))
    escaped_answer = html.escape(answer_text)
    direct_answer_url = topic.get("direct_answer_url") or topic.get("quora_url", "https://www.quora.com/answer")
    question_url = topic.get("question_url") or "https://www.quora.com/answer"

    msg = (
        f"💡 <b>[QUORA QUESTION COPILOT]</b> • <i>{slot_label} ({daily_count}/{max_daily})</i>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"❓ <b>Question:</b> {escaped_question}\n"
        f"🏷️ <b>Category:</b> #{escaped_category.replace(' ', '').replace('&', '_')}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📝 <b>Tap answer below to AUTO-COPY:</b>\n"
        f"<code>{escaped_answer}</code>\n\n"
        f"📲 <i>How to post in 5 seconds (1-Click Direct Composer):</i>\n"
        f"1. Tap the code box above 👆 <i>(Auto-copied!)</i>\n"
        f"2. Tap <b>[✍️ 1-Click Direct Answer on Quora]</b> below <i>(Opens editor modal directly!)</i>\n"
        f"3. Paste & Submit! 🔥\n\n"
        f"💡 <i>Tip: Send or forward ANY Quora question to this bot for an instant authoritative answer!</i>"
    )

    keyboard = build_inline_keyboard([
        [
            {"text": "✍️ 1-Click Direct Answer on Quora", "url": direct_answer_url},
        ],
        [
            {"text": "❓ View Question Page", "url": question_url},
            {"text": "📋 Quora Answer Hub", "url": "https://www.quora.com/answer"},
        ],
        [
            {"text": "🌐 Aman's Hub", "url": "https://aman179102.netlify.app"},
            {"text": "🐙 GitHub @aman179102", "url": "https://github.com/aman179102"},
        ],
    ])

    return msg, keyboard


def dispatch_quora_copilot_alert(
    topic: dict[str, Any],
    settings: Settings,
    slot_label: str = "Active Wave",
    daily_count: int = 1,
    max_daily: int = 4,
    include_canonical: bool = False,
    dry_run: bool = False,
) -> bool:
    """Generates the authoritative answer and dispatches the 1-tap notification to Telegram."""
    logger.info("Generating Quora answer for topic '%s'...", topic.get("question"))
    answer_text = generate_quora_answer(topic, settings, include_canonical=include_canonical)

    text, reply_markup = format_quora_opportunity_message(
        topic=topic,
        answer_text=answer_text,
        slot_label=slot_label,
        daily_count=daily_count,
        max_daily=max_daily,
    )

    if dry_run:
        logger.info("[Dry-Run] Quora Telegram dispatch simulated:\n%s", text)
        print("\n--- SIMULATED QUORA TELEGRAM ALERT ---")
        print(text)
        print("--------------------------------------\n")
        return True

    success = send_telegram_message(
        settings=settings,
        text=text,
        reply_markup=reply_markup,
        parse_mode="HTML",
        disable_preview=True,
    )
    if success:
        logger.info("Dispatched Quora Copilot 1-tap notification to Telegram! Question: %s", topic.get("question"))
    else:
        logger.error("Failed to dispatch Quora Copilot notification to Telegram.")
    return success
