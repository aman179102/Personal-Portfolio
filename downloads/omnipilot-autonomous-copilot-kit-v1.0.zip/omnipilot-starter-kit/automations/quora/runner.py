"""Quora Question Radar & 1-Tap Answer Copilot Orchestrator."""
from __future__ import annotations

import logging
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from common.config import Settings
from common.state import load_state, save_state
from automations.quora.content import CURATED_QUORA_QUESTIONS
from automations.quora.copilot import dispatch_quora_copilot_alert

logger = logging.getLogger(__name__)

STATE_FILE_NAME = "quora_copilot_state.json"
MAX_DAILY_ANSWERS = 4
MIN_ALERT_COOLDOWN_SECONDS = 9000.0  # 2.5 hours between automated Quora alerts

IST = timezone(timedelta(hours=5, minutes=30))


def _get_current_slot(now_ist: datetime) -> tuple[str, bool]:
    """
    Evaluates current IST time and returns (Slot Label, IsActiveWindow).
    Active windows:
      - 09:00 - 11:30: Morning Wave 🌅 (Asia/India Morning Peak)
      - 13:30 - 16:00: Midday Wave ☀️ (Europe Workday Start)
      - 18:30 - 21:00: Evening Wave 🚀 (India Evening Tech Reading)
      - 21:30 - 23:45: Night Wave 🌙 (US Morning Overlap)
    """
    hour = now_ist.hour
    minute = now_ist.minute
    total_minutes = hour * 60 + minute

    if 9 * 60 <= total_minutes < 11 * 60 + 30:
        return "Morning Wave 🌅", True
    elif 13 * 60 + 30 <= total_minutes < 16 * 60:
        return "Midday Wave ☀️", True
    elif 18 * 60 + 30 <= total_minutes < 21 * 60:
        return "Evening Wave 🚀", True
    elif 21 * 60 + 30 <= total_minutes < 23 * 60 + 45:
        return "Night Wave 🌙", True
    else:
        return "Rest & Recovery Window 💤", False


def _get_state_file(settings: Settings) -> Path:
    raw_dir = getattr(settings, "state_dir", "state") if settings else "state"
    state_dir = Path(raw_dir)
    state_dir.mkdir(parents=True, exist_ok=True)
    return state_dir / STATE_FILE_NAME


def run_radar(
    settings: Settings,
    dry_run: bool = False,
    force: bool = False,
) -> dict[str, Any]:
    """
    Runs the Quora Question Radar cycle.
    Selects the next evergreen question in rotation, drafts authoritative answer,
    and dispatches a 1-tap mobile notification to Telegram.
    """
    state_file = _get_state_file(settings)
    state = load_state(state_file)

    now_utc = datetime.now(timezone.utc)
    now_ist = now_utc.astimezone(IST)
    today_str = now_ist.strftime("%Y-%m-%d")

    # 1. Reset daily counter if a new day has arrived
    daily_stats = state.get("daily_stats", {})
    if daily_stats.get("date") != today_str:
        daily_stats = {"date": today_str, "count": 0}
        state["daily_stats"] = daily_stats

    daily_count = daily_stats.get("count", 0)

    # 2. Check daily ceiling (Max 4 answers/day for high trust & zero spam)
    if daily_count >= MAX_DAILY_ANSWERS and not force:
        logger.info("[Quora Copilot] Daily ceiling reached (%d/%d). Skipping.", daily_count, MAX_DAILY_ANSWERS)
        return {"status": "ceiling_reached", "count": daily_count, "max": MAX_DAILY_ANSWERS}

    # 3. Time window evaluation
    slot_label, is_active_window = _get_current_slot(now_ist)
    if not is_active_window and not force:
        logger.info("[Quora Copilot] Current IST time (%02d:%02d) is in %s. Skipping automated alert.", now_ist.hour, now_ist.minute, slot_label)
        return {"status": "outside_window", "slot": slot_label}

    # 4. Cooldown evaluation (min 2.5 hours between Quora alerts)
    last_dispatched_ts = state.get("last_dispatched_ts", 0.0)
    elapsed = time.time() - last_dispatched_ts
    if elapsed < MIN_ALERT_COOLDOWN_SECONDS and not force:
        logger.info("[Quora Copilot] Cooldown active (%.1fs < %.1fs). Skipping.", elapsed, MIN_ALERT_COOLDOWN_SECONDS)
        return {"status": "cooldown", "elapsed": elapsed, "required": MIN_ALERT_COOLDOWN_SECONDS}

    # 5. Topic selection with circular rotation
    seen_ids = state.get("dispatched_question_ids", [])
    available_topics = [t for t in CURATED_QUORA_QUESTIONS if t.get("id") not in seen_ids]

    if not available_topics:
        seen_ids = []
        available_topics = CURATED_QUORA_QUESTIONS

    topic = available_topics[0]
    next_count = daily_count + 1

    # Include canonical portfolio link on 1 out of 3 answers
    include_canonical = (next_count % 3 == 0)

    # 6. Dispatch 1-tap notification
    success = dispatch_quora_copilot_alert(
        topic=topic,
        settings=settings,
        slot_label=slot_label,
        daily_count=next_count,
        max_daily=MAX_DAILY_ANSWERS,
        include_canonical=include_canonical,
        dry_run=dry_run,
    )

    if success and not dry_run:
        daily_stats["count"] = next_count
        seen_ids.append(topic.get("id"))
        state["daily_stats"] = daily_stats
        state["dispatched_question_ids"] = seen_ids
        state["last_dispatched_ts"] = time.time()
        state["last_dispatched_at"] = now_utc.isoformat()
        save_state(state_file, state)
        logger.info("[Quora Copilot] State successfully persisted. Daily count: %d", next_count)

    return {
        "status": "success" if success else "error",
        "question": topic.get("question"),
        "daily_count": next_count if success else daily_count,
        "slot": slot_label,
    }


def run_all(settings: Settings, dry_run: bool = False, force: bool = False) -> dict[str, Any]:
    """Unified entrypoint for the Quora automation module."""
    return run_radar(settings, dry_run=dry_run, force=force)
