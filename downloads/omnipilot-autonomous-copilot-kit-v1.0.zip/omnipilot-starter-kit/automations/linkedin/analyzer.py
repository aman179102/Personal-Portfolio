"""LinkedIn Post Context Analyzer.

Performs deep semantic understanding of LinkedIn posts before comment generation:
- Identifies category (Technical, Career, Hiring, Leadership, Educational, Personal)
- Extracts central thesis and specific author arguments
- Determines author perspective and intended audience
- Defines on-topic discussion angles
- Enforces prohibited unrelated concepts
"""
from __future__ import annotations

import logging
from typing import Any

from common.ai import generate_json
from common.config import Settings

logger = logging.getLogger(__name__)

ANALYZER_SYSTEM_PROMPT = """You are an expert LinkedIn content analyst and communications strategist.
Your job is to thoroughly analyze a LinkedIn post before any comment is written.

You must:
1. Identify the primary post category (Technical, Career, Hiring, Leadership, Educational, or Personal).
2. Summarize the central thesis and main points the author ACTUALLY argued.
3. Identify the author's tone and target audience.
4. Define 2-3 relevant, thoughtful angles a peer could contribute that stay 100% on-topic.
5. Explicitly identify prohibited concepts—unrelated technical buzzwords or tangents that would look ridiculous or tone-deaf if introduced.

Return ONLY a valid JSON object matching this schema:
{
  "category": "Technical | Career | Hiring | Leadership | Educational | Personal",
  "central_topic": "One sentence summary of the exact post topic",
  "key_points": ["Point 1 mentioned by author", "Point 2 mentioned by author"],
  "author_perspective": "Author's stance or intent (e.g. giving actionable interview advice)",
  "intended_audience": "e.g. Software engineers interviewing for senior roles",
  "recommended_angles": ["Practical tip on story banks", "How interviewers evaluate the Result in STAR"],
  "prohibited_concepts": ["epoll", "kernel bypass", "io_uring", "unrelated systems buzzwords"]
}
"""


def analyze_post_context(post_data: dict[str, Any], settings: Settings) -> dict[str, Any]:
    """
    Analyzes post content to extract semantic structure and boundaries.
    Falls back gracefully to a heuristic analysis if AI fails.
    """
    title = post_data.get("title", "")
    author = post_data.get("author", "Post Author")
    text = post_data.get("text", "")

    if not text:
        text = title or "LinkedIn Professional Discussion"

    user_prompt = (
        f"Post Author: {author}\n"
        f"Post Title: {title}\n"
        f"Full Post Content:\n\"\"\"\n{text[:2500]}\n\"\"\"\n\n"
        f"Analyze this LinkedIn post and output the JSON structure."
    )

    try:
        analysis = generate_json(
            settings=settings,
            system=ANALYZER_SYSTEM_PROMPT,
            user=user_prompt,
            temperature=0.2,
        )
        if analysis and isinstance(analysis, dict) and "central_topic" in analysis:
            logger.info("Successfully analyzed LinkedIn post context. Category: %s | Topic: %s", analysis.get("category"), analysis.get("central_topic"))
            return analysis
    except Exception as exc:
        logger.warning("AI post analysis failed: %s. Using heuristic fallback.", exc)

    # Heuristic fallback analysis
    lower_text = text.lower()
    if any(k in lower_text for k in ["interview", "resume", "career", "salary", "star format", "job search"]):
        category = "Career"
        prohibited = ["epoll", "kernel bypass", "io_uring", "p99 latency", "memory allocations", "syscalls"]
    elif any(k in lower_text for k in ["hiring", "recruit", "talent", "candidate", "job opening"]):
        category = "Hiring"
        prohibited = ["epoll", "kernel bypass", "io_uring", "p99 latency", "database indexing"]
    elif any(k in lower_text for k in ["leadership", "manager", "1:1", "delegat", "team culture", "mentorship"]):
        category = "Leadership"
        prohibited = ["epoll", "kernel bypass", "io_uring", "p99 latency", "caching layers"]
    elif any(k in lower_text for k in ["latency", "database", "distributed", "concurrency", "redis", "kafka", "architecture"]):
        category = "Technical"
        prohibited = ["fake personal stories", "hiring spam"]
    else:
        category = "General Professional"
        prohibited = ["unrelated deep technical plumbing", "contrived metrics"]

    return {
        "category": category,
        "central_topic": title or text[:100],
        "key_points": [text[:150]],
        "author_perspective": "Sharing industry observations",
        "intended_audience": "LinkedIn tech and engineering professionals",
        "recommended_angles": ["Share practical experience relevant to author's point"],
        "prohibited_concepts": prohibited,
    }
