"""LinkedIn 1-Tap Mobile Comment Copilot & Telegram Notification Formatter."""
from __future__ import annotations

import html
import logging
from typing import Any

from common.config import Settings
from common.telegram import build_inline_keyboard, send_telegram_message
from automations.linkedin.content import generate_linkedin_comment

logger = logging.getLogger(__name__)


def format_linkedin_opportunity_message(
    topic: dict[str, Any],
    comment_text: str,
    slot_label: str = "Active Wave",
    daily_count: int = 1,
    max_daily: int = 30,
) -> tuple[str, dict[str, Any]]:
    """
    Formats the Telegram alert with HTML and monospaced <code> block.
    In mobile Telegram (Android/iOS), tapping text wrapped in <code> instantly copies it to clipboard!
    """
    escaped_title = html.escape(topic.get("title", "Technical Systems Architecture"))
    escaped_category = html.escape(topic.get("category", "Systems Engineering"))
    escaped_creator = html.escape(topic.get("creator", "Industry Tech Lead"))
    escaped_comment = html.escape(comment_text)
    post_url = topic.get("post_url") or topic.get("linkedin_url", "https://www.linkedin.com/feed/")
    
    category_slug = topic.get("category", "systemdesign").lower().replace(" ", "").replace("&", "")
    hashtag = topic.get("hashtag") or ("systemdesign" if "system" in category_slug else "softwareengineering")
    community_stream_url = f"https://www.linkedin.com/feed/hashtag/{hashtag}/"

    msg = (
        f"🎯 <b>[LINKEDIN COMMENT COPILOT]</b> • <i>{slot_label} ({daily_count}/{max_daily})</i>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📌 <b>Post:</b> {escaped_title}\n"
        f"👤 <b>Author:</b> {escaped_creator}\n"
        f"🏷️ <b>Domain:</b> #{escaped_category.replace(' ', '')}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"💬 <b>Tap comment below to AUTO-COPY:</b>\n"
        f"<code>{escaped_comment}</code>\n\n"
        f"📲 <i>How to post (3 Flexible Ways):</i>\n"
        f"1. <b>For this post:</b> Tap code box 👆 ➡️ Tap <b>[🚀 Open This Exact Post]</b> ➡️ Paste & Comment!\n"
        f"2. <b>For fresh posts by anyone:</b> Tap <b>[🌍 Open Live Community Stream]</b> to see live posts by developers right now!\n"
        f"3. <b>For ANY person's post on your feed:</b> Simply forward/send any post link to this bot for an instant custom comment! 🔥"
    )

    keyboard = build_inline_keyboard([
        [
            {"text": "🚀 Open This Exact Post", "url": post_url},
        ],
        [
            {"text": f"🌍 Open Live Community Stream (#{hashtag})", "url": community_stream_url},
        ],
        [
            {"text": "🌐 Aman's Systems Hub", "url": "https://aman179102.netlify.app"},
            {"text": "🐙 GitHub @aman179102", "url": "https://github.com/aman179102"},
        ],
    ])

    return msg, keyboard


def dispatch_linkedin_copilot_alert(
    topic: dict[str, Any],
    settings: Settings,
    slot_label: str = "Active Wave",
    daily_count: int = 1,
    max_daily: int = 30,
    dry_run: bool = False,
) -> bool:
    """Generates the technical comment and dispatches the 1-tap notification to Telegram."""
    logger.info("Generating high-signal comment for topic '%s'...", topic.get("title"))
    comment_text = generate_linkedin_comment(topic, settings)

    text, reply_markup = format_linkedin_opportunity_message(
        topic=topic,
        comment_text=comment_text,
        slot_label=slot_label,
        daily_count=daily_count,
        max_daily=max_daily,
    )

    if dry_run:
        logger.info("[Dry-Run] Telegram dispatch simulated:\n%s", text)
        print("\n--- SIMULATED TELEGRAM ALERT ---")
        print(text)
        print("--------------------------------\n")
        return True

    success = send_telegram_message(
        settings=settings,
        text=text,
        reply_markup=reply_markup,
        parse_mode="HTML",
        disable_preview=True,
    )
    if success:
        logger.info("Dispatched LinkedIn Copilot 1-tap notification to Telegram! Topic: %s", topic.get("title"))
    else:
        logger.error("Failed to dispatch LinkedIn Copilot notification to Telegram.")
    return success
