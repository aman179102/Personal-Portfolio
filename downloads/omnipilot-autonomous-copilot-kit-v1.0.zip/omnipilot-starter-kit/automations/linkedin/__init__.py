"""LinkedIn Opportunity Radar & 1-Tap Mobile Comment Copilot for Aman Kumar (@aman179102)."""
from __future__ import annotations

from automations.linkedin.runner import run_all, run_radar

__all__ = ["run_all", "run_radar"]
