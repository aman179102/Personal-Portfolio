"""LinkedIn Post & Metadata Extractor.

Extracts post text, author, title, and media from:
- LinkedIn URLs (public OpenGraph tags and article schema)
- Raw forwarded post text
- Topic dictionaries
Handles Unicode normalization (e.g. mathematical bold/italic to plain text).
"""
from __future__ import annotations

import logging
import re
import unicodedata
from typing import Any, Optional

import httpx

logger = logging.getLogger(__name__)

LINKEDIN_URL_PATTERN = re.compile(
    r"https?://(?:www\.)?linkedin\.com/(?:feed/update/urn:li:activity:\d+|posts/[a-zA-Z0-9_\-]+|pulse/[a-zA-Z0-9_\-]+)"
)

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}


def normalize_text(text: str) -> str:
    """Normalizes Unicode mathematical alphanumeric characters and cleans whitespace."""
    if not text:
        return ""
    # Normalize unicode (converts fancy bold/italic unicode characters to standard ascii/latin)
    normalized = unicodedata.normalize("NFKD", text)
    # Remove control characters except newline and tab
    cleaned = "".join(ch for ch in normalized if ch == "\n" or ch == "\t" or unicodedata.category(ch)[0] != "C")
    # Clean up excessive blank lines
    lines = [line.strip() for line in cleaned.splitlines()]
    # Collapse multiple consecutive blank lines
    collapsed: list[str] = []
    blank_count = 0
    for line in lines:
        if not line:
            blank_count += 1
            if blank_count <= 1:
                collapsed.append("")
        else:
            blank_count = 0
            collapsed.append(line)
    return "\n".join(collapsed).strip()


def extract_url_from_text(text: str) -> Optional[str]:
    """Finds the first LinkedIn URL in a string."""
    match = LINKEDIN_URL_PATTERN.search(text)
    if match:
        return match.group(0).rstrip(".,)>\"'")
    # Fallback search for any linkedin.com link
    for word in text.split():
        clean_word = word.strip("<>\"'(),;")
        if "linkedin.com" in clean_word and clean_word.startswith("http"):
            return clean_word
    return None


def fetch_linkedin_url_content(url: str, timeout: float = 12.0) -> dict[str, Any]:
    """
    Fetches the public metadata and text of a LinkedIn post using OpenGraph tags.
    Detects auth walls, login redirects, 999 blocks, and missing descriptions.
    """
    result: dict[str, Any] = {
        "url": url,
        "title": "",
        "author": "",
        "text": "",
        "image_url": "",
        "success": False,
        "error_type": "",
        "error_detail": "",
    }

    try:
        from bs4 import BeautifulSoup
    except ImportError:
        logger.warning("BeautifulSoup not installed. Fallback to raw string extraction.")
        BeautifulSoup = None  # type: ignore

    try:
        with httpx.Client(headers=DEFAULT_HEADERS, follow_redirects=True, timeout=timeout) as client:
            resp = client.get(url)
            final_url = str(resp.url).lower()

            # Detect login redirects / auth walls
            if any(p in final_url for p in ["/login", "/checkpoint", "/authwall", "/uas/login", "/signup"]):
                logger.warning("LinkedIn URL redirected to authwall/login: %s -> %s", url, final_url)
                result["error_type"] = "authwall"
                result["error_detail"] = "LinkedIn redirected request to login/authwall."
                return result

            if resp.status_code != 200:
                logger.warning("LinkedIn fetch returned HTTP %d for %s", resp.status_code, url)
                result["error_type"] = f"http_{resp.status_code}"
                result["error_detail"] = f"LinkedIn returned HTTP status {resp.status_code}"
                return result

            html_text = resp.text
            lower_html = html_text.lower()

            # Check for authwall / sign in indicators in HTML
            if "join linkedin" in lower_html and "<meta property=\"og:description\"" not in lower_html:
                result["error_type"] = "authwall"
                result["error_detail"] = "Page contains LinkedIn join/login barrier without public metadata."
                return result

            if not BeautifulSoup:
                desc_match = re.search(r'<meta\s+property=["\']og:description["\']\s+content=["\'](.*?)["\']', html_text, re.DOTALL | re.IGNORECASE)
                if desc_match:
                    clean_text = normalize_text(desc_match.group(1))
                    if len(clean_text) >= 30:
                        result["text"] = clean_text
                        result["success"] = True
                    else:
                        result["error_type"] = "truncated_content"
                        result["error_detail"] = f"Extracted text too short ({len(clean_text)} chars)."
                else:
                    result["error_type"] = "missing_metadata"
                    result["error_detail"] = "No og:description meta tag found in HTML."
                return result

            soup = BeautifulSoup(html_text, "html.parser")

            # Check title for login wall
            title_tag = soup.find("meta", property="og:title") or soup.find("meta", attrs={"name": "twitter:title"}) or soup.find("title")
            raw_title = title_tag.get("content", "") if hasattr(title_tag, "get") else (title_tag.get_text() if title_tag else "")
            if "sign in" in raw_title.lower() or "login" in raw_title.lower():
                result["error_type"] = "authwall"
                result["error_detail"] = "Page title indicates login barrier."
                return result

            # 1. Post text from og:description or name="description"
            desc_tag = soup.find("meta", property="og:description") or soup.find("meta", attrs={"name": "description"})
            post_text = desc_tag.get("content", "") if desc_tag else ""

            # Check article body elements if meta description is truncated or missing
            articles = soup.find_all("p", class_=lambda c: c and "attributed-text" in c)
            if articles:
                article_text = "\n\n".join(a.get_text() for a in articles if a.get_text().strip())
                if len(article_text) > len(post_text):
                    post_text = article_text

            clean_text = normalize_text(post_text)

            # Validate extracted content length
            if len(clean_text) < 30:
                logger.warning("Extracted LinkedIn text is empty or too short (%d chars) for %s", len(clean_text), url)
                result["error_type"] = "insufficient_content"
                result["error_detail"] = f"Extracted content is too short ({len(clean_text)} chars). Post may be private or restricted."
                return result

            result["text"] = clean_text

            # 2. Title and Author from og:title
            if raw_title:
                result["title"] = normalize_text(raw_title)
                segments = [s.strip() for s in raw_title.split("|") if s.strip()]
                author_cand = ""
                for seg in segments:
                    seg_clean = seg.split(" on LinkedIn")[0].strip()
                    lower_seg = seg_clean.lower()
                    if "comment" in lower_seg or "like" in lower_seg or "linkedin" in lower_seg:
                        continue
                    if len(seg_clean.split()) <= 4 and len(seg_clean) < 40:
                        author_cand = seg_clean
                        break
                result["author"] = author_cand or (segments[0] if segments else "Post Author")

            # 3. Image URL from og:image
            img_tag = soup.find("meta", property="og:image") or soup.find("meta", attrs={"name": "twitter:image"})
            if img_tag and img_tag.get("content"):
                result["image_url"] = img_tag.get("content", "").strip()

            result["success"] = True
            logger.info("Successfully extracted LinkedIn post content (%d chars, author: %s)", len(result["text"]), result["author"])

    except Exception as exc:
        logger.warning("Failed to fetch LinkedIn URL content (%s): %s", url, exc)
        result["error_type"] = "network_error"
        result["error_detail"] = str(exc)

    return result


def extract_post_context(raw_input: Any) -> dict[str, Any]:
    """
    Unified extraction entrypoint.
    Returns:
      - is_valid: bool (True only if actual substantive post content exists)
      - extraction_status: 'success' | 'failed' | 'insufficient_content'
      - error_message: str (User-friendly message if extraction failed)
    NEVER silently falls back to bare URLs or generic assumptions.
    """
    if isinstance(raw_input, dict):
        text = raw_input.get("context") or raw_input.get("text") or raw_input.get("fallback_comment") or ""
        url = raw_input.get("linkedin_url") or raw_input.get("url") or ""
        author = raw_input.get("creator") or raw_input.get("author") or ""
        title = raw_input.get("title") or ""
        category = raw_input.get("category") or ""

        # If context is brief but URL is a specific post, try fetching full post
        if url and LINKEDIN_URL_PATTERN.search(url) and (len(text) < 200 or not author):
            fetched = fetch_linkedin_url_content(url)
            if fetched.get("success") and len(fetched.get("text", "")) > len(text):
                text = fetched["text"]
                author = author or fetched.get("author", "")
                title = title or fetched.get("title", "")

        clean_text = normalize_text(text)
        is_valid = len(clean_text) >= 25
        return {
            "title": title,
            "author": author or "Industry Leader",
            "category": category or "Professional Discussion",
            "text": clean_text,
            "url": url,
            "raw_input": raw_input,
            "is_valid": is_valid,
            "extraction_status": "success" if is_valid else "insufficient_content",
            "error_message": "" if is_valid else "Provided post content is too short to generate a relevant comment.",
        }

    raw_str = str(raw_input or "").strip()
    found_url = extract_url_from_text(raw_str)

    if found_url:
        fetched = fetch_linkedin_url_content(found_url)
        user_notes = raw_str.replace(found_url, "").strip()

        if fetched.get("success"):
            combined_text = fetched["text"]
            if user_notes:
                combined_text = f"{fetched['text']}\n\n[Context Notes: {user_notes}]"
            return {
                "title": fetched.get("title") or "LinkedIn Post",
                "author": fetched.get("author") or "Post Author",
                "category": "General Professional",
                "text": normalize_text(combined_text),
                "url": found_url,
                "image_url": fetched.get("image_url", ""),
                "raw_input": raw_input,
                "is_valid": True,
                "extraction_status": "success",
                "error_message": "",
            }

        # URL extraction failed! Check if user supplied post notes/text alongside URL
        if len(user_notes) >= 30:
            logger.info("URL fetch failed but user provided %d chars of context text.", len(user_notes))
            return {
                "title": user_notes.splitlines()[0][:80],
                "author": "Post Author",
                "category": "General Professional",
                "text": normalize_text(user_notes),
                "url": found_url,
                "raw_input": raw_input,
                "is_valid": True,
                "extraction_status": "success_from_user_text",
                "error_message": "",
            }

        # Total extraction failure: DO NOT proceed with bare URL
        logger.warning("LinkedIn URL extraction failed (%s). Bare URL cannot be used for comment generation.", fetched.get("error_detail"))
        err_msg = (
            "Could not extract post content from LinkedIn URL (login wall, private post, or restricted metadata). "
            "Please paste or forward the actual post text directly."
        )
        return {
            "title": "",
            "author": "",
            "category": "Extraction Failure",
            "text": "",
            "url": found_url,
            "raw_input": raw_input,
            "is_valid": False,
            "extraction_status": "failed",
            "error_type": fetched.get("error_type", "unknown_failure"),
            "error_detail": fetched.get("error_detail", ""),
            "error_message": err_msg,
        }

    # Plain text input without URL
    clean_text = normalize_text(raw_str)
    if len(clean_text) < 20:
        logger.warning("Raw post text is too short (%d chars).", len(clean_text))
        return {
            "title": "",
            "author": "",
            "category": "Insufficient Content",
            "text": clean_text,
            "url": "",
            "image_url": "",
            "raw_input": raw_input,
            "is_valid": False,
            "extraction_status": "insufficient_content",
            "error_message": "Post text is too short or empty. Please provide the complete post content.",
        }

    first_line = clean_text.splitlines()[0][:80]
    return {
        "title": first_line,
        "author": "Post Author",
        "category": "General Professional",
        "text": clean_text,
        "url": "",
        "image_url": "",
        "raw_input": raw_input,
        "is_valid": True,
        "extraction_status": "success",
        "error_message": "",
    }
