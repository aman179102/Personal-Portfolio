"""Quality Control & Validation Layer for LinkedIn Comments.

Evaluates generated comments against 6 core criteria:
1. post_relevance (1-5)
2. contextual_accuracy (1-5)
3. originality (1-5)
4. naturalness (1-5)
5. discussion_potential (1-5)
6. clarity (1-5)

Enforces word count (40-90 words), checks for AI cliches, detects forced buzzwords/hallucinations,
and persists rejection records to state/linkedin_qc_rejections.log.
"""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from common.ai import generate_json
from common.config import Settings

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent
QC_LOG_FILE = BASE_DIR / "state" / "linkedin_qc_rejections.log"

# Detects fabricated first-person claims about past employers, imaginary companies, or fake metrics
FABRICATED_CLAIM_PATTERNS = [
    re.compile(r"\b(?:in|at)\s+(?:my|our)\s+(?:previous|last|former|past)\s+(?:role|job|company|team|org|workplace)\b", re.I),
    re.compile(r"\bat\s+(?:my|our)\s+(?:company|startup|firm)\b", re.I),
    re.compile(r"\bwhen\s+(?:i|we)\s+(?:was|were)\s+(?:scaling|leading|managing|running|building)\s+(?:at|for)\b", re.I),
    re.compile(r"\bin\s+(?:my|our)\s+(?:production\s+cluster|datacenter|infrastructure)\b", re.I),
    re.compile(r"\b(?:my|our)\s+(?:former|previous)\s+colleagues?\b", re.I),
    re.compile(r"\b(?:i|we)\s+(?:personally\s+)?(?:shipped|scaled|built|handled)\s+(?:a|an)?\s*(?:system|app|service|cluster)\s+(?:to|handling)\s+\d+", re.I),
]

FORBIDDEN_OPENERS = [
    "great post!",
    "great post.",
    "awesome post!",
    "awesome post.",
    "thanks for sharing!",
    "thanks for sharing.",
    "thank you for sharing",
]

GENERIC_CLOSINGS = [
    "what are your thoughts?",
    "what do you think?",
    "agree?",
    "do you agree?",
    "thoughts?",
    "would love to hear your thoughts",
]

QC_EVALUATOR_SYSTEM_PROMPT = """You are a strict editorial reviewer and quality control judge for LinkedIn professional comments.

Your task is to critique a candidate comment based strictly on the original post context.

Evaluate the comment against these 6 criteria (1 to 5 scale, 5 being best):
1. post_relevance: Does it directly address what the author discussed without derailing into unrelated concepts?
2. contextual_accuracy: Does it accurately understand the author's message without introducing unsupported assumptions?
3. originality: Does it add a fresh perspective or practical observation rather than just repeating post keywords?
4. naturalness: Does it sound like an authentic human professional?
5. discussion_potential: Does it create an inviting, natural opportunity for conversation without engagement bait?
6. clarity: Can an average LinkedIn professional in the field understand it easily?

MANDATORY REJECTION (Score 1 in relevant criteria):
- If the comment invents first-person personal experiences, achievements, or imaginary past employers ("In my previous role", "At our company", "When we scaled to 100M") -> naturalness MUST be 1.
- If the comment introduces technical buzzwords or plumbing (epoll, io_uring, kernel bypass, p99 SLAs) on a post that was NOT about that specific low-level topic -> post_relevance MUST be 1.
- If the comment repeats keywords from the post without adding any actual insight or perspective -> originality MUST be 1.
- If the comment ends with lazy engagement bait ("Agree?", "What are your thoughts?") -> discussion_potential MUST be 1.
- If the comment is merely sycophantic ("Great post, couldn't agree more!") -> naturalness MUST be 1.

Return ONLY a valid JSON object matching this schema:
{
  "passed": true | false,
  "scores": {
    "post_relevance": 1-5,
    "contextual_accuracy": 1-5,
    "originality": 1-5,
    "naturalness": 1-5,
    "discussion_potential": 1-5,
    "clarity": 1-5
  },
  "overall_score": 1.0-5.0,
  "rejection_reasons": ["Specific flaw 1", "Specific flaw 2"],
  "remediation_guidance": "Exact advice on how to rewrite the comment to pass"
}
"""


def log_rejection(
    post_title: str,
    author: str,
    candidate_comment: str,
    reasons: list[str],
    scores: dict[str, Any],
) -> None:
    """Appends rejected comment details to state/linkedin_qc_rejections.log for auditing."""
    try:
        QC_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        now_str = datetime.now(timezone.utc).isoformat()
        entry = {
            "timestamp": now_str,
            "post_title": post_title,
            "author": author,
            "comment": candidate_comment,
            "reasons": reasons,
            "scores": scores,
        }
        with open(QC_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
        logger.warning(
            "[LinkedIn QC REJECTED] Post: '%s' | Reasons: %s",
            post_title[:60],
            "; ".join(reasons),
        )
    except Exception as exc:
        logger.error("Failed writing to QC rejection log: %s", exc)


def evaluate_comment_quality(
    candidate_comment: str,
    post_data: dict[str, Any],
    analysis: dict[str, Any],
    settings: Settings,
) -> dict[str, Any]:
    """
    Runs deterministic checks first (word count, banned phrases, forbidden keywords),
    then invokes LLM semantic review for relevance and naturalness.
    """
    clean_comment = candidate_comment.strip()
    words = clean_comment.split()
    word_count = len(words)
    lower_comment = clean_comment.lower()

    deterministic_reasons: list[str] = []

    # 1. Flexible word count constraint (approx 20-100 words, buffer 18-110)
    if word_count < 18:
        deterministic_reasons.append(f"Comment is too short ({word_count} words). Minimum is 18 words to communicate a meaningful point.")
    elif word_count > 110:
        deterministic_reasons.append(f"Comment is too long ({word_count} words). Maximum is 100 words for mobile readability.")

    # 2. Hard check for fabricated first-person claims (past roles, imaginary companies, fake metrics)
    for pattern in FABRICATED_CLAIM_PATTERNS:
        match = pattern.search(clean_comment)
        if match:
            deterministic_reasons.append(f"Fabricated first-person career history/employer claim detected: '{match.group(0)}'")
            break

    # 3. Forbidden openers
    for opener in FORBIDDEN_OPENERS:
        if lower_comment.startswith(opener) or lower_comment.startswith(f"hi {opener}"):
            deterministic_reasons.append(f"Contains robotic sycophantic opener: '{opener}'")
            break

    # 4. Generic lazy endings
    for closing in GENERIC_CLOSINGS:
        if closing in lower_comment:
            deterministic_reasons.append(f"Contains lazy generic ending: '{closing}'")
            break

    # 5. Prohibited concept injection check
    prohibited_concepts = analysis.get("prohibited_concepts", [])
    for concept in prohibited_concepts:
        if concept.lower() in lower_comment:
            deterministic_reasons.append(f"Introduced prohibited off-topic concept: '{concept}'")

    # If severe deterministic failures occurred, reject immediately without wasting LLM call
    if deterministic_reasons:
        scores = {
            "post_relevance": 1 if any("prohibited" in r for r in deterministic_reasons) else 3,
            "contextual_accuracy": 1 if any("Fabricated" in r for r in deterministic_reasons) else 2,
            "originality": 2,
            "naturalness": 1 if any("opener" in r or "ending" in r or "Fabricated" in r for r in deterministic_reasons) else 3,
            "discussion_potential": 1,
            "clarity": 4,
        }
        log_rejection(
            post_title=post_data.get("title", ""),
            author=post_data.get("author", ""),
            candidate_comment=clean_comment,
            reasons=deterministic_reasons,
            scores=scores,
        )
        return {
            "passed": False,
            "scores": scores,
            "overall_score": 1.5 if any("Fabricated" in r for r in deterministic_reasons) else 2.0,
            "rejection_reasons": deterministic_reasons,
            "remediation_guidance": " ".join(deterministic_reasons),
        }

    # 6. Semantic LLM Review (receives complete post text up to 2500 chars)
    user_prompt = (
        f"Post Author: {post_data.get('author', 'Author')}\n"
        f"Post Category: {analysis.get('category', 'General')}\n"
        f"Central Topic: {analysis.get('central_topic', '')}\n"
        f"Key Points: {', '.join(analysis.get('key_points', []))}\n"
        f"Full Post Text:\n\"\"\"\n{post_data.get('text', '')[:2500]}\n\"\"\"\n\n"
        f"CANDIDATE COMMENT TO REVIEW ({word_count} words):\n\"\"\"\n{clean_comment}\n\"\"\"\n\n"
        f"Perform strict QC evaluation against the criteria and output JSON."
    )

    try:
        eval_res = generate_json(
            settings=settings,
            system=QC_EVALUATOR_SYSTEM_PROMPT,
            user=user_prompt,
            temperature=0.1,
        )
        if eval_res and isinstance(eval_res, dict) and "scores" in eval_res:
            scores = eval_res.get("scores", {})
            relevance = scores.get("post_relevance", 0)
            accuracy = scores.get("contextual_accuracy", 0)
            naturalness = scores.get("naturalness", 0)
            originality = scores.get("originality", 0)

            # Strict passing thresholds:
            # relevance >= 4, accuracy >= 4, naturalness >= 4, originality >= 3
            passed = (
                eval_res.get("passed", False)
                and relevance >= 4
                and accuracy >= 4
                and naturalness >= 4
                and originality >= 3
            )
            eval_res["passed"] = passed

            if not passed:
                reasons = eval_res.get("rejection_reasons", [])
                if not reasons:
                    reasons = [f"Scores below quality threshold (relevance={relevance}, accuracy={accuracy}, naturalness={naturalness}, originality={originality})"]
                log_rejection(
                    post_title=post_data.get("title", ""),
                    author=post_data.get("author", ""),
                    candidate_comment=clean_comment,
                    reasons=reasons,
                    scores=scores,
                )
            else:
                logger.info(
                    "[LinkedIn QC PASSED] Post: '%s' | Overall: %.1f/5.0",
                    post_data.get("title", "")[:60],
                    eval_res.get("overall_score", 4.5),
                )

            return eval_res
    except Exception as exc:
        logger.warning("LLM QC evaluation call failed: %s. Relying on deterministic checks.", exc)

    # Fallback to passing if deterministic checks passed and LLM failed
    return {
        "passed": True,
        "scores": {
            "post_relevance": 4,
            "contextual_accuracy": 4,
            "originality": 4,
            "naturalness": 4,
            "discussion_potential": 4,
            "clarity": 4,
        },
        "overall_score": 4.0,
        "rejection_reasons": [],
        "remediation_guidance": "",
    }
