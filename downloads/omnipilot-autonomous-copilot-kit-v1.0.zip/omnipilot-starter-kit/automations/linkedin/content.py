"""Curated technical topics, persona prompts, and verified direct single post URLs for LinkedIn growth.

Features:
- Dynamic post extraction (URL metadata, raw text, and topic dictionaries)
- Deep semantic context analysis (Category, Thesis, Intended Audience, Forbidden Concepts)
- Conversational 40-90 word comment generator (zero AI cliches, zero robotic openers)
- Strict 6-point Quality Control (QC) validation with auto-retry and rejection logging
"""
from __future__ import annotations

import logging
from typing import Any

from common.config import Settings
from automations.linkedin.extractor import extract_post_context
from automations.linkedin.analyzer import analyze_post_context
from automations.linkedin.generator import draft_linkedin_comment
from automations.linkedin.qc import evaluate_comment_quality

logger = logging.getLogger(__name__)

# Universal Direct Post Deep Links (opens PostDetailActivity directly in LinkedIn app with comment box focused)
CURATED_TOPICS: list[dict[str, Any]] = [
    {
        "id": 'post_alex_sharding_01',
        "category": 'Database Architecture',
        "title": 'Top 20 System Design Concepts: Database Sharding & Microservices',
        "creator": 'Alex Xu (ByteByteGo)',
        "linkedin_url": 'https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7385344549919051778-iUuN',
        "post_url": 'https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7385344549919051778-iUuN',
        "context": "Alex Xu's breakdown of top 20 system design concepts: vertical vs horizontal scaling, database sharding strategies (range-based vs hash-based), and microservice decoupling.",
        "fallback_comment": "Spot on perspective! Really agree with your take on database sharding — people often jump to sharding way too early before exhausting simple read replicas or caching. One practical point I'd add is operational complexity: cross-shard joins and re-sharding down the line are massive maintenance drains. Curious how your team decides when vertical scaling is truly exhausted?",
    },
    {
        "id": 'post_ankit_patterns_02',
        "category": 'Microservices Architecture',
        "title": 'Mastering 12 Microservices Design Patterns for Distributed Systems',
        "creator": 'Ankit Pangasa',
        "linkedin_url": 'https://www.linkedin.com/posts/ankit-pangasa_if-you-can-explain-these-12-patterns-activity-7428054215689883649-q1Ys',
        "post_url": 'https://www.linkedin.com/posts/ankit-pangasa_if-you-can-explain-these-12-patterns-activity-7428054215689883649-q1Ys',
        "context": 'Comprehensive breakdown of core microservices design patterns: Database per Service, Saga pattern, CQRS, API Gateway, and Circuit Breakers.',
        "fallback_comment": 'Solid breakdown! Agree with your point on Database-per-service — having that clean decoupling is gold. One tricky thing teams often run into is handling cross-service reporting and data consistency without resorting to messy distributed transactions. Outbox pattern + CDC usually saves the day here. Really well explained!',
    },
    {
        "id": 'post_puneet_concurrency_03',
        "category": 'Systems & Concurrency',
        "title": 'Concurrency in System Design: 20 Key Concepts to Master',
        "creator": 'Puneet Patwari',
        "linkedin_url": 'https://www.linkedin.com/posts/puneet-patwari_20-must-know-concepts-to-master-concurrency-activity-7452696857362911232-qIs5',
        "post_url": 'https://www.linkedin.com/posts/puneet-patwari_20-must-know-concepts-to-master-concurrency-activity-7452696857362911232-qIs5',
        "context": 'Deep dive into concurrency fundamentals: Threads vs Processes, Race Conditions, Mutexes, Semaphores, Lock-Free structures, and Event Loops.',
        "fallback_comment": 'Spot on perspective! Concurrency bugs are by far the hardest to reproduce in staging. Agree with your breakdown of locks vs channels. One nuance worth keeping in mind is false sharing on CPU cache lines when threads mutate adjacent variables — it can silently kill throughput even with lock-free atomics. Really well articulated!',
    },
    {
        "id": 'post_ankit_concepts_04',
        "category": 'System Design Interviews',
        "title": '30 Essential System Design Concepts for High-Scale Applications',
        "creator": 'Ankit Pangasa',
        "linkedin_url": 'https://www.linkedin.com/posts/ankit-pangasa_systemdesign-techinterviews-softwareengineering-activity-7452928570579959808-j9po',
        "post_url": 'https://www.linkedin.com/posts/ankit-pangasa_systemdesign-techinterviews-softwareengineering-activity-7452928570579959808-j9po',
        "context": 'A structured map of 30 core system design concepts: Load Balancers, Caching tiers, CDN edge delivery, Consistent Hashing, and Rate Limiting.',
        "fallback_comment": "Accha point highlight kiya hai! Really agree with your take on consistent hashing with virtual nodes — it is such an elegant way to prevent cache stampedes when scaling. One practical thing I'd add is tuning token-bucket rate limiters at the edge so downstream microservices never get slammed during sudden traffic surges. Great list!",
    },
    {
        "id": 'post_ashish_mastery_05',
        "category": 'System Design Strategy',
        "title": 'Mastering System Design: 30 Essential Concepts for Senior Engineers',
        "creator": 'Ashish Pratap Singh',
        "linkedin_url": 'https://www.linkedin.com/posts/ashishps1_if-you-want-to-get-good-at-system-design-activity-7435178152156442624-w18y',
        "post_url": 'https://www.linkedin.com/posts/ashishps1_if-you-want-to-get-good-at-system-design-activity-7435178152156442624-w18y',
        "context": 'System design foundational guide covering database indexing, replication topologies, message queues (Kafka/RabbitMQ), and CAP theorem trade-offs.',
        "fallback_comment": 'Really agree with this roadmap! The point on PACELC theorem is so true — network partitions will happen, so the real decision in production is always trading latency against consistency. Most consumer web apps happily choose eventual consistency with async queues because a 200ms lag is way better than downtime. Spot on thoughts!',
    },
    {
        "id": 'post_gaurav_caching_06',
        "category": 'Distributed Caching',
        "title": 'System Design Interview: Distributed Caching Architecture & Redis',
        "creator": 'Gaurav Sen (GKCS)',
        "linkedin_url": 'https://www.linkedin.com/posts/gkcs_system-design-interview-questions-activity-7413954310591508481-7ylj',
        "post_url": 'https://www.linkedin.com/posts/gkcs_system-design-interview-questions-activity-7413954310591508481-7ylj',
        "context": "Gaurav Sen's breakdown of distributed cache topologies: Cache-Aside vs Write-Through vs Write-Back, cache eviction policies (LRU/LFU), and cache penetration.",
        "fallback_comment": "Solid breakdown! Agree with your points on cache stampedes and penetration — they are easily the nastiest outages in high-throughput systems. One practical point I'd add is pairing Bloom filters at the gateway with mutex locks around cache misses so your database never melts during key expirations. Really well put!",
    },
    {
        "id": 'post_neo_fundamentals_07',
        "category": 'Software Architecture',
        "title": 'Starting with System Design: SQL vs NoSQL, Caching & Load Balancing',
        "creator": 'Neo Kim',
        "linkedin_url": 'https://www.linkedin.com/posts/nk-systemdesign-one_if-i-had-to-start-with-system-design-id-activity-7445447634376560640-Mf-2',
        "post_url": 'https://www.linkedin.com/posts/nk-systemdesign-one_if-i-had-to-start-with-system-design-id-activity-7445447634376560640-Mf-2',
        "context": 'A practitioner roadmap for software architecture: Relational vs Document vs Key-Value stores, L4 vs L7 reverse proxies, and horizontal scale.',
        "fallback_comment": "Spot on thoughts on this! Agree with your take on SQL vs NoSQL — relational databases with JSONB (like PostgreSQL) handle 90% of real-world use cases with full ACID safety. One nuance I'd add is only reaching for distributed NoSQL when write volume or horizontal partitioning requirements truly exceed what a tuned relational cluster can sustain. Great guide!",
    },
    {
        "id": 'post_sibasish_scalability_08',
        "category": 'Distributed Systems',
        "title": 'System Design Fundamentals for Scalability & Distributed Rate Limiting',
        "creator": 'Sibasish Tripathy',
        "linkedin_url": 'https://www.linkedin.com/posts/sibasish-_systemdesign-distributedsystems-backendengineering-activity-7484823782692528129-DrJf',
        "post_url": 'https://www.linkedin.com/posts/sibasish-_systemdesign-distributedsystems-backendengineering-activity-7484823782692528129-DrJf',
        "context": 'Designing scalable backends: Microservices communication, Rate Limiting algorithms (Sliding Window Log vs Counter), and Redis Lua scripting.',
        "fallback_comment": "Really well articulated! Agree with your breakdown of rate limiting algorithms. One practical thing I'd add is that while sliding-window logs in Redis give pinpoint accuracy, their memory footprint blows up under traffic bursts. Using sliding-window counters with Redis Lua scripts is usually the sweet spot for 99% accuracy with low memory. Really thoughtful post!",
    },
    {
        "id": 'post_mayank_microservices_09',
        "category": 'Microservices Architecture',
        "title": 'Microservices Key Design Patterns & Database per Service',
        "creator": 'Mayank A. (Curious Learner)',
        "linkedin_url": 'https://www.linkedin.com/posts/curiouslearner_microservices-key-design-patterns-activity-7390930723957964800-5wko',
        "post_url": 'https://www.linkedin.com/posts/curiouslearner_microservices-key-design-patterns-activity-7390930723957964800-5wko',
        "context": 'Practical microservices design patterns: Strangler Fig, API Gateway aggregation, Outbox Pattern for reliable event publishing, and CQRS.',
        "fallback_comment": "Spot on perspective! Agree with your points on microservices design patterns. The Transactional Outbox pattern is such an underrated lifesaver for eliminating dual-write inconsistencies between databases and Kafka. One practical thing I'd add is using Debezium or CDC rather than polling tables to keep database CPU cool. Really well explained!",
    },
    {
        "id": 'post_nishchal_scaling_10',
        "category": 'System Scalability',
        "title": '20 Essential System Design Concepts for Scaling Web Applications',
        "creator": 'Nishchal Muradia',
        "linkedin_url": 'https://www.linkedin.com/posts/nishchal-muradia_20-%F0%9D%90%92%F0%9D%90%B2%F0%9D%90%AC%F0%9D%90%AD%F0%9D%90%9E%F0%9D%90%A6-%F0%9D%90%83%F0%9D%90%9E%F0%9D%90%AC%F0%9D%90%A2%F0%9D%90%A0%F0%9D%90%A7-%F0%9D%90%82%F0%9D%90%A8%F0%9D%90%A7%F0%9D%90%9C%F0%9D%90%9E%F0%9D%90%A9-activity-7389627241183318016-Hry6',
        "post_url": 'https://www.linkedin.com/posts/nishchal-muradia_20-%F0%9D%90%92%F0%9D%90%B2%F0%9D%90%AC%F0%9D%90%AD%F0%9D%90%9E%F0%9D%90%A6-%F0%9D%90%83%F0%9D%90%9E%F0%9D%90%AC%F0%9D%90%A2%F0%9D%90%A0%F0%9D%90%A7-%F0%9D%90%82%F0%9D%90%A8%F0%9D%90%A7%F0%9D%90%9C%F0%9D%90%9E%F0%9D%90%A9-activity-7389627241183318016-Hry6',
        "context": 'Key concepts for scaling: Database Indexing, B-Trees vs Hash Indexes, Connection Pooling, Asynchronous Workers, and Circuit Breakers.',
        "fallback_comment": 'Really agree with your take on database indexing! Secondary indexes are an easy win for slow SELECT queries, but one gotcha teams often overlook is write amplification — every index turns simple appends into random I/O across B-tree pages during INSERTs and UPDATEs. Periodically auditing unused indexes with pg_stat_user_indexes is an easy operational win. Great post!',
    },
    {
        "id": 'post_rocky_distributed_11',
        "category": 'Distributed Architecture',
        "title": 'Microservices Architecture Patterns for High-Throughput Systems',
        "creator": 'Rocky Bhatia',
        "linkedin_url": 'https://www.linkedin.com/posts/rocky-bhatia-a4801010_%F0%9D%90%8C%F0%9D%90%A2%F0%9D%90%9C%F0%9D%90%AB%F0%9D%90%A8%F0%9D%90%AC%F0%9D%90%9E%F0%9D%90%AB%F0%9D%90%AF%F0%9D%90%A2%F0%9D%90%9C%F0%9D%90%9E%F0%9D%90%AC-%F0%9D%90%9A%F0%9D%90%AB%F0%9D%90%9C%F0%9D%90%A1%F0%9D%90%A2%F0%9D%90%AD%F0%9D%90%9E-activity-7452680369927077889-MYTt',
        "post_url": 'https://www.linkedin.com/posts/rocky-bhatia-a4801010_%F0%9D%90%8C%F0%9D%90%A2%F0%9D%90%9C%F0%9D%90%AB%F0%9D%90%A8%F0%9D%90%AC%F0%9D%90%9E%F0%9D%90%AB%F0%9D%90%AF%F0%9D%90%A2%F0%9D%90%9C%F0%9D%90%9E%F0%9D%90%AC-%F0%9D%90%9A%F0%9D%90%AB%F0%9D%90%9C%F0%9D%90%A1%F0%9D%90%A2%F0%9D%90%AD%F0%9D%90%9E-activity-7452680369927077889-MYTt',
        "context": 'Architectural patterns in microservices: Service Discovery, Load Balancing, Circuit Breakers (Hystrix/Resilience4j), and Bulkhead isolation.',
        "fallback_comment": "Solid breakdown! Agree with your point on Bulkhead isolation — if a single slow downstream dependency exhausts your main thread pool, the entire service goes down for completely unrelated requests. One practical thing I'd add is sizing dedicated connection pools and strict timeouts for each integration to keep failures contained. Spot on thoughts!",
    },
    {
        "id": 'post_vasudha_redis_12',
        "category": 'In-Memory Caching',
        "title": 'Redis Deep Dive: Architecture, Internals, and Production Use Cases',
        "creator": 'Vasudha Mishra',
        "linkedin_url": 'https://www.linkedin.com/posts/vasudha11_redis-deep-dive-architecture-internals-activity-7519263632380121088-xcZB',
        "post_url": 'https://www.linkedin.com/posts/vasudha11_redis-deep-dive-architecture-internals-activity-7519263632380121088-xcZB',
        "context": 'Deep dive into Redis: Single-threaded event loop, I/O multiplexing with epoll, in-memory data structures (Hashes, Sorted Sets, HyperLogLog), and RDB vs AOF persistence.',
        "fallback_comment": "Really well put! Agree with your breakdown of Redis internals — the single-threaded event loop eliminating lock contention is pure engineering elegance. One practical gotcha I'd add is educating teams never to run O(N) commands like KEYS * or large HGETALL in production since they block the entire event loop for every client. Using SCAN with pipelining is essential hygiene. Great writeup!",
    },
    {
        "id": 'post_palak_db_selection_13',
        "category": 'Database Architecture',
        "title": 'Choosing the Right Database for High-Concurrency System Design',
        "creator": 'Palak Sharma',
        "linkedin_url": 'https://www.linkedin.com/posts/palaksharma2312_systemdesign-highleveldesign-softwareengineering-activity-7489883003138260993-94CL',
        "post_url": 'https://www.linkedin.com/posts/palaksharma2312_systemdesign-highleveldesign-softwareengineering-activity-7489883003138260993-94CL',
        "context": 'Evaluation framework for database selection: Relational (PostgreSQL/MySQL), Key-Value (Redis/DynamoDB), Wide-Column (Cassandra/ScyllaDB), and Graph (Neo4j).',
        "fallback_comment": "Spot on perspective! Agree with your framework on database selection — choosing based on hype rather than access patterns is such a common trap. One practical nuance I'd add is that relational databases shine when relationships and complex joins are core, while wide-column stores like Cassandra excel when query access patterns are known and fixed upfront. Really well articulated!",
    },
    {
        "id": 'post_rahul_cqrs_14',
        "category": 'Software Architecture',
        "title": 'Microservices Design Patterns: CQRS, Event Sourcing & Circuit Breakers',
        "creator": 'Rahul Choudhary',
        "linkedin_url": 'https://www.linkedin.com/posts/rahul-choudhary-py_microservices-systemdesign-architecture-activity-7343131762555809792--Z8F',
        "post_url": 'https://www.linkedin.com/posts/rahul-choudhary-py_microservices-systemdesign-architecture-activity-7343131762555809792--Z8F',
        "context": 'Separation of concerns using CQRS (Command Query Responsibility Segregation), Event Sourcing, and circuit breaker fault tolerance.',
        "fallback_comment": "Really agree with your thoughts on CQRS! Separating reads from writes into denormalized read models brings massive speedups. One practical thing I'd add is managing team expectations around eventual consistency and out-of-order event delivery. If a domain doesn't have an extreme read-to-write ratio, standard read replicas are usually much simpler to operate. Great breakdown!",
    },
    {
        "id": 'post_aryan_hashing_15',
        "category": 'Distributed Systems',
        "title": 'System Design: Database Sharding Strategies & Consistent Hashing',
        "creator": 'Aryan Raskar',
        "linkedin_url": 'https://www.linkedin.com/posts/aryan-raskar-077640253_system-design-interviews-have-a-very-clear-activity-7510549231800324096-kxeT',
        "post_url": 'https://www.linkedin.com/posts/aryan-raskar-077640253_system-design-interviews-have-a-very-clear-activity-7510549231800324096-kxeT',
        "context": 'Consistent hashing rings, virtual nodes, partition key selection, and rebalancing costs during cluster expansion.',
        "fallback_comment": "Solid breakdown! Agree with your point on consistent hashing — virtual nodes are an absolute must to prevent hot-spot skew across cache servers. One practical nuance I'd add is allocating at least 100 to 200 virtual node replicas per physical server to get a truly uniform distribution across the cluster ring. Really thoughtful post!",
    },
    {
        "id": 'post_ankit_redis_usecases_16',
        "category": 'Cache Architecture',
        "title": 'Top 10 Redis Use Cases in High-Throughput System Design',
        "creator": 'Ankit Pangasa',
        "linkedin_url": 'https://www.linkedin.com/posts/ankit-pangasa_top-10-redis-use-cases-and-why-its-an-activity-7443863352918945792-08m9',
        "post_url": 'https://www.linkedin.com/posts/ankit-pangasa_top-10-redis-use-cases-and-why-its-an-activity-7443863352918945792-08m9',
        "context": '10 architectural use cases for Redis beyond basic caching: Distributed Session Storage, Rate Limiting, Pub/Sub, Real-Time Leaderboards (Sorted Sets), and Geospatial indexing.',
        "fallback_comment": 'Accha point highlight kiya hai! Really agree with your take on Redis Sorted Sets (ZSET) — they are arguably the most versatile data structure in distributed backends. Using ZADD and ZREVRANGEBYSCORE replaces heavy relational SQL window functions for real-time leaderboards and rate limiters with logarithmic speed. Great list!',
    },
    {
        "id": 'post_puneet_threads_17',
        "category": 'Systems & OS',
        "title": 'System Design: Processes vs Threads, CPU Scheduling & Memory Caches',
        "creator": 'Puneet Patwari',
        "linkedin_url": 'https://www.linkedin.com/posts/puneet-patwari_i-struggled-with-system-design-interviews-activity-7477712764774285314-xp0A',
        "post_url": 'https://www.linkedin.com/posts/puneet-patwari_i-struggled-with-system-design-interviews-activity-7477712764774285314-xp0A',
        "context": 'Process vs Thread memory spaces, kernel context switching overhead, CPU L1/L2 cache locality, and asynchronous non-blocking event loops.',
        "fallback_comment": "Spot on thoughts on this! Agree with your distinction between processes and threads. One practical gotcha I'd add that often catches engineers off guard is false sharing on CPU cache lines when threads mutate adjacent variables. Using thread-local storage or memory padding makes an enormous difference for low-latency systems. Really well put!",
    },
    {
        "id": 'post_alex_resources_18',
        "category": 'Software Architecture',
        "title": '24 High-Signal Resources to Learn Software Architecture & System Design',
        "creator": 'Alex Xu (ByteByteGo)',
        "linkedin_url": 'https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7347300843395686400-DVbL',
        "post_url": 'https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7347300843395686400-DVbL',
        "context": "Curated architectural resources, papers, books, and case studies: Martin Kleppmann's DDIA, Netflix TechBlog, AWS Architecture Center, and ByteByteGo visual guides.",
        "fallback_comment": "Really agree with these recommendations! Martin Kleppmann's 'Designing Data-Intensive Applications' remains the gold standard because it focuses on foundational trade-offs rather than ephemeral frameworks. One thing I'd add to this reading list is studying real-world incident post-mortems from engineering blogs — you learn so much about where architectures actually break under pressure. Great resources!",
    },
    {
        "id": 'post_alex_patterns_19',
        "category": 'Software Architecture',
        "title": 'Top 5 Software Architectural Patterns: Monolith, Microservices, Event-Driven & Hexagonal',
        "creator": 'Alex Xu (ByteByteGo)',
        "linkedin_url": 'https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7346923744243728385-CXzT',
        "post_url": 'https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7346923744243728385-CXzT',
        "context": "Alex Xu's breakdown of Layered, Event-Driven, Microkernel, Microservices, and Space-Based architectural patterns.",
        "fallback_comment": "Solid breakdown! Agree with your take on architectural patterns. Hexagonal Architecture (Ports and Adapters) paired with Domain-Driven Design is the best defense against architectural rot over time. One practical thing I'd add is keeping domain entities strictly isolated from web frameworks and databases — it makes unit testing painless and tech stack migrations manageable down the road. Spot on!",
    },
    {
        "id": 'post_alex_concepts_20',
        "category": 'Engineering Best Practices',
        "title": '12 Architectural Concepts Every Senior Developer Should Know',
        "creator": 'Alex Xu (ByteByteGo)',
        "linkedin_url": 'https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7415080280257953792-04wT',
        "post_url": 'https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7415080280257953792-04wT',
        "context": 'Essential architectural concepts: Idempotency, Backpressure, Circuit Breakers, Bulkheads, Zero-Downtime Deployments, and Data Replication.',
        "fallback_comment": "Really well articulated! Agree with your list of architectural concepts. Backpressure is easily one of the most under-appreciated patterns — when upstream producers outpace downstream consumers, unbounded in-memory queues inevitably cause OOM crashes. One practical thing I'd add is implementing reactive flow control or drop-oldest policies early before traffic spikes hit production. Great post!",
    },
    {
        "id": 'post_alex_knowledge_map_21',
        "category": 'Software Architecture',
        "title": 'The Ultimate Software Architect Knowledge Map',
        "creator": 'Alex Xu (ByteByteGo)',
        "linkedin_url": 'https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7237123746120003585-_Or_',
        "post_url": 'https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7237123746120003585-_Or_',
        "context": 'A comprehensive visual knowledge map for software architects: Cloud Architecture, Security, Data Engineering, API Design, and Infrastructure as Code.',
        "fallback_comment": "Spot on perspective! Agree with your architecture knowledge map. A software architect's core superpower isn't writing every line of code, but drawing clean domain boundaries and documenting Architecture Decision Records (ADRs). One point I'd add is keeping ADRs short and focused on the 'why' and 'consequences' so future teams understand the trade-offs. Really well put!",
    },
    {
        "id": 'post_vishakha_devops_22',
        "category": 'DevOps & SRE',
        "title": 'AIOps vs MLOps vs DevOps vs LLMOps: Architectural Differences',
        "creator": 'Vishakha Sadhwani',
        "linkedin_url": 'https://www.linkedin.com/posts/vsadhwani_aiops-vs-mlops-vs-devops-vs-llmops-same-activity-7465441594268082176-Gq-A',
        "post_url": 'https://www.linkedin.com/posts/vsadhwani_aiops-vs-mlops-vs-devops-vs-llmops-same-activity-7465441594268082176-Gq-A',
        "context": 'Architectural breakdown of operational paradigms: Continuous Integration & Deployment (DevOps), Model Training & Drift (MLOps), and Prompt Ops & Vector Indexing (LLMOps).',
        "fallback_comment": "Really agree with this breakdown! The distinction between deterministic DevOps and non-deterministic MLOps/LLMOps is so crucial. One practical thing I'd add is treating prompt revisions and vector index embeddings with the same CI/CD rigor, automated eval suites, and canary testing that we apply to backend microservices. Spot on thoughts!",
    },
    {
        "id": 'post_abukar_devops_habits_23',
        "category": 'DevOps Leadership',
        "title": 'Core Anti-Patterns to Stop Doing as a DevOps Lead',
        "creator": 'Abdurahman Abukar',
        "linkedin_url": 'https://www.linkedin.com/posts/a-abukar_%F0%9D%90%93%F0%9D%90%A1%F0%9D%90%A2%F0%9D%90%A7%F0%9D%90%A0%F0%9D%90%AC-%F0%9D%90%88-%F0%9D%90%AC%F0%9D%90%AD%F0%9D%90%A8%F0%9D%90%A9%F0%9D%90%A9%F0%9D%90%9E%F0%9D%90%9D-%F0%9D%90%9D%F0%9D%90%A8%F0%9D%90%A2%F0%9D%90%A7%F0%9D%90%A0-activity-7415346804030173184-WrWd',
        "post_url": 'https://www.linkedin.com/posts/a-abukar_%F0%9D%90%93%F0%9D%90%A1%F0%9D%90%A2%F0%9D%90%A7%F0%9D%90%A0%F0%9D%90%AC-%F0%9D%90%88-%F0%9D%90%AC%F0%9D%90%AD%F0%9D%90%A8%F0%9D%90%A9%F0%9D%90%A9%F0%9D%90%9E%F0%9D%90%9D-%F0%9D%90%9D%F0%9D%90%A8%F0%9D%90%A2%F0%9D%90%A7%F0%9D%90%A0-activity-7415346804030173184-WrWd',
        "context": 'DevOps leadership lessons: Stopping manual infrastructure changes (ClickOps), eliminating gatekeeping, enforcing Infrastructure as Code, and empowering self-service developer platforms.',
        "fallback_comment": "Spot on perspective! Agree with your points on DevOps anti-patterns. Becoming a ticket-taking bottleneck for feature teams completely defeats the purpose of platform engineering. One practical point I'd add is building self-service internal developer platforms (IDPs) with automated guardrails so product engineers can provision environments safely without filing Jira tickets. Really well articulated!",
    },
    {
        "id": 'post_hello_concurrency_24',
        "category": 'Low-Level Systems',
        "title": 'How Should You Handle Concurrency in Low-Level Systems?',
        "creator": 'Hello Interview',
        "linkedin_url": 'https://www.linkedin.com/posts/hello-interview_how-should-you-handle-concurrency-in-low-level-activity-7415450551796285440-w_vw',
        "post_url": 'https://www.linkedin.com/posts/hello-interview_how-should-you-handle-concurrency-in-low-level-activity-7415450551796285440-w_vw',
        "context": 'Architectural discussion on low-level concurrency: Mutexes, Reader-Writer Locks, Atomic Operations, Memory Barriers, and Cache Coherency.',
        "fallback_comment": "Solid breakdown! Agree with your take on low-level concurrency. Lock-free programming with atomic compare-and-swap (CAS) is powerful, but cache contention can easily degrade performance faster than a simple mutex. One practical thing I'd add is using exponential backoff in spinlocks and aligning critical structures to 64-byte cache line boundaries to prevent bus locking. Great writeup!",
    },
    {
        "id": 'post_jay_row_concurrency_25',
        "category": 'Database Concurrency',
        "title": 'Deep Dive: How Row-Level Concurrency & MVCC Work in Relational Databases',
        "creator": 'Jay Vollmer',
        "linkedin_url": 'https://www.linkedin.com/posts/jayvollmer_deep-dive-how-row-level-concurrency-works-activity-7330986485854183426-BgPc',
        "post_url": 'https://www.linkedin.com/posts/jayvollmer_deep-dive-how-row-level-concurrency-works-activity-7330986485854183426-BgPc',
        "context": 'Multi-Version Concurrency Control (MVCC) internals: Snapshot Isolation, Read Committed vs Serializable, tuple versioning, and autovacuum cleanup.',
        "fallback_comment": "Really agree with your thoughts on MVCC! Readers never blocking writers is pure brilliance in PostgreSQL. One practical nuance I'd add that often bites teams is table and index bloat from frequent UPDATEs creating new row versions. Keeping autovacuum tuned aggressively and leveraging Heap-Only Tuple (HOT) optimizations is essential for write-heavy tables. Spot on post!",
    },
    {
        "id": 'post_ibrahim_postgres_26',
        "category": 'Database Architecture',
        "title": 'PostgreSQL Database Design, Indexing & High-Throughput Optimization',
        "creator": 'Ibrahim Abdelsattar',
        "linkedin_url": 'https://www.linkedin.com/posts/ibrahim-abdelsattar_postgresql-databasedesign-softwarearchitecture-activity-7529453740303609856-mrdC',
        "post_url": 'https://www.linkedin.com/posts/ibrahim-abdelsattar_postgresql-databasedesign-softwarearchitecture-activity-7529453740303609856-mrdC',
        "context": 'Postgres optimization techniques: Partial Indexes, Expression Indexes, Covering Indexes (INCLUDE clause), and partitioning large event tables.',
        "fallback_comment": "Really well put! Agree with your points on PostgreSQL indexing. Covering indexes with the INCLUDE clause are such an underrated performance win — satisfying queries purely from index pages via Index-Only Scans turns 15ms lookups into sub-millisecond responses. One thing I'd add is auditing index sizes regularly so they don't exceed your shared_buffers. Great breakdown!",
    },
    {
        "id": 'post_jonathan_rust_concurrency_27',
        "category": 'Systems Programming',
        "title": 'Rust Concurrency Patterns: Arc<Mutex<T>> vs RwLock vs Channels',
        "creator": 'Jonathan Kablan',
        "linkedin_url": 'https://www.linkedin.com/posts/jonathankablan_rust-arcmutex-rwlock-activity-7509975184506802176-TAG4',
        "post_url": 'https://www.linkedin.com/posts/jonathankablan_rust-arcmutex-rwlock-activity-7509975184506802176-TAG4',
        "context": 'Concurrency patterns in Rust: Send and Sync traits, atomic reference counting (Arc), Mutex vs RwLock, and CSP-style MPSC message channels.',
        "fallback_comment": "Spot on perspective! Agree with your take on Rust concurrency. The Send and Sync traits eliminating data races at compile time is a massive paradigm shift. One practical thing I'd add is switching from Arc<Mutex<T>> to Arc<RwLock<T>> for read-heavy workloads, or crossbeam channels to avoid shared-memory contention altogether. Really well articulated!",
    },
    {
        "id": 'post_simran_system_notes_28',
        "category": 'System Architecture',
        "title": 'Complete System Design Notes: Microservices, Caching & Data Layer',
        "creator": 'Simran Sharma',
        "linkedin_url": 'https://www.linkedin.com/posts/simran-sharma13_system-design-complete-notes-activity-7524421536045236224-UbU9',
        "post_url": 'https://www.linkedin.com/posts/simran-sharma13_system-design-complete-notes-activity-7524421536045236224-UbU9',
        "context": 'Structured notes on core system design: Client-Server, Stateless Web Tiers, Stateful Database Tiers, Message Brokers, and Global CDN Caching.',
        "fallback_comment": "Solid notes! Agree with your points on system design fundamentals. Keeping application tiers strictly stateless is the single biggest prerequisite for painless autoscaling. One practical thing I'd add is offloading session tokens and rate limit states to a clustered Redis instance early so individual web pods remain completely disposable during rolling deployments. Great compilation!",
    },
    {
        "id": 'post_akshat_system_roadmap_29',
        "category": 'Engineering Growth',
        "title": 'How to Actually Learn System Design: Redis, Kafka, Load Balancers & Microservices',
        "creator": 'Akshat Jain',
        "linkedin_url": 'https://www.linkedin.com/posts/akshat-jain-iit_how-do-you-learn-system-design-dont-activity-7531368916921679872-SCnW',
        "post_url": 'https://www.linkedin.com/posts/akshat-jain-iit_how-do-you-learn-system-design-dont-activity-7531368916921679872-SCnW',
        "context": 'System design learning roadmap: Breaking down monolithic applications, event-driven streaming with Apache Kafka, and distributed consistency.',
        "fallback_comment": "Really agree with your perspective! Dissecting open-source codebases and real production post-mortems beats memorizing static interview templates every single time. One practical thing I'd add to this learning roadmap is understanding why companies migrate between tech stacks — that is where the real architectural trade-offs reveal themselves. Spot on thoughts!",
    },
    {
        "id": 'post_rani_dev_concepts_30',
        "category": 'Software Engineering',
        "title": 'System Design Concepts Every Developer Should Know: Latency & Indexing',
        "creator": 'Rani Dhage',
        "linkedin_url": 'https://www.linkedin.com/posts/rani-dhage_system-design-concepts-every-developer-should-activity-7321403289252573185-KqSn',
        "post_url": 'https://www.linkedin.com/posts/rani-dhage_system-design-concepts-every-developer-should-activity-7321403289252573185-KqSn',
        "context": 'Latency numbers every programmer should know (L1 cache vs RAM vs NVMe vs Network RTT), database indexing mechanics, and horizontal scaling.',
        "fallback_comment": "Accha point highlight kiya hai! Agree with your breakdown of latency numbers and indexing. Jeff Dean's latency numbers table is the most important mental model in systems engineering: keeping data close to CPU caches vs crossing network boundaries drives every architectural decision. One practical thing I'd add is measuring P99 tail latency rather than averages. Great post!",
    },
    {
        "id": 'post_curious_monolith_31',
        "category": 'Architecture Evolution',
        "title": 'Microservices vs Monolith: Architectural Trade-offs & When to Migrate',
        "creator": 'Mayank A. (Curious Learner)',
        "linkedin_url": 'https://www.linkedin.com/posts/curiouslearner_system-design-is-about-creating-applications-activity-7400319413276778496-wAIi',
        "post_url": 'https://www.linkedin.com/posts/curiouslearner_system-design-is-about-creating-applications-activity-7400319413276778496-wAIi',
        "context": 'System design trade-offs: Monolith simplicity, deployment velocity, and the organizational thresholds that justify migrating to microservices.',
        "fallback_comment": "Spot on thoughts on this! Really agree with your take on monoliths vs microservices. A clean modular monolith is almost always superior for early and mid-stage systems before organizational scale demands independent deployments. One practical thing I'd add is that premature microservices just trade simple function calls for distributed tracing and cross-network latency. Really well explained!",
    },
    {
        "id": 'post_aryan_cheatsheet_32',
        "category": 'Interview Architecture',
        "title": 'System Design Cheat Sheet: Core Principles for High-Availability Backends',
        "creator": 'Aryan Raskar',
        "linkedin_url": 'https://www.linkedin.com/posts/aryan-raskar-077640253_system-design-cheat-sheet-activity-7480617247607279616---QS',
        "post_url": 'https://www.linkedin.com/posts/aryan-raskar-077640253_system-design-cheat-sheet-activity-7480617247607279616---QS',
        "context": 'Practical architecture cheat sheet: Caching strategies, Message Queues, Redis in-memory storage, Load Balancers, and Database replication.',
        "fallback_comment": "Solid architecture cheat sheet! Agree with your core principles for high availability. Eliminating single points of failure with redundant load balancers and automated database failover is fundamental. One practical nuance I'd add is practicing chaos engineering and regular game-day drills to ensure automated failovers actually work under real network partitions. Great list!",
    },
]


def generate_linkedin_comment(topic_or_input: Any, settings: Settings, max_attempts: int = 3) -> str:
    """
    Unified 4-stage pipeline:
    1. Extract full post content (URL metadata, plain text, or topic dict)
    2. Deep semantic context analysis (Category, Arguments, Tone, Forbidden concepts)
    3. Contextual conversational generation (40-90 words, no AI cliches)
    4. Strict Quality Control (QC) evaluation with rejection logging & auto-regeneration
    """
    post_data = extract_post_context(topic_or_input)

    # 1. HARD EXTRACTION SAFETY GATE:
    # If post extraction failed (e.g. login wall, truncated metadata, or empty text),
    # NEVER proceed to generate a comment or fall back to generic technical assumptions.
    if not post_data.get("is_valid", False):
        err_msg = post_data.get("error_message") or "Extraction failed: insufficient post content."
        logger.warning("[LinkedIn Pipeline] Extraction gate failed: %s (input: %s)", err_msg, str(topic_or_input)[:100])
        return f"⚠️ {err_msg}"

    analysis = analyze_post_context(post_data, settings)

    logger.info(
        "[LinkedIn Pipeline] Post: '%s' | Author: '%s' | Category: '%s'",
        post_data.get("title", "")[:50],
        post_data.get("author", "Unknown"),
        analysis.get("category", "General"),
    )

    feedback = ""
    best_candidate = ""

    for attempt in range(1, max_attempts + 1):
        # Slightly vary temperature across retries
        temp = 0.5 + (attempt - 1) * 0.15
        candidate = draft_linkedin_comment(
            post_data=post_data,
            analysis=analysis,
            settings=settings,
            rejection_feedback=feedback,
            temperature=temp,
        )

        if not candidate:
            continue

        best_candidate = candidate

        # Run Quality Control evaluation
        qc_result = evaluate_comment_quality(
            candidate_comment=candidate,
            post_data=post_data,
            analysis=analysis,
            settings=settings,
        )

        if qc_result.get("passed"):
            logger.info(
                "[LinkedIn Pipeline] QC Passed on attempt %d/%d (Score: %.1f/5.0)",
                attempt,
                max_attempts,
                qc_result.get("overall_score", 4.5),
            )
            return candidate

        # Prepare feedback for the next attempt
        reasons = qc_result.get("rejection_reasons", [])
        guidance = qc_result.get("remediation_guidance", "")
        feedback = guidance or "; ".join(reasons)
        logger.warning(
            "[LinkedIn Pipeline] QC Rejected attempt %d/%d: %s. Regenerating...",
            attempt,
            max_attempts,
            feedback,
        )

    # If all attempts failed QC, check if topic has a verified fallback comment
    if isinstance(topic_or_input, dict) and topic_or_input.get("fallback_comment"):
        fallback = topic_or_input.get("fallback_comment", "")
        logger.info("[LinkedIn Pipeline] Using verified curated fallback comment after retries.")
        return fallback

    # Otherwise return best candidate if it exists
    if best_candidate:
        logger.warning("[LinkedIn Pipeline] Returning best candidate after retries exhausted.")
        return best_candidate

    topic_name = analysis.get("central_topic") or post_data.get("title") or "this topic"
    return (
        f"This raises a thoughtful perspective on {topic_name}. "
        "The practical challenge is usually applying these concepts consistently across team routines without adding friction."
    )


def generate_comment_from_raw_post(post_text_or_url: str, settings: Settings) -> str:
    """Generates a high-signal, contextually relevant comment from a raw URL or text snippet."""
    return generate_linkedin_comment(post_text_or_url, settings)
