"""Contextual LinkedIn Comment Generator.

Drafts human, conversational, high-value LinkedIn comments tailored strictly to the post context.
Enforces:
- 40-90 words length
- Natural professional tone (zero AI cliches, zero robotic openers)
- Relevance to author's actual arguments
- Specific, organic discussion starters (no generic 'Agree?' or 'Thoughts?')
- Zero unrelated jargon or forced buzzwords
"""
from __future__ import annotations

import logging
from typing import Any

from common.ai import generate_text
from common.config import Settings

logger = logging.getLogger(__name__)

COMMENT_GENERATOR_SYSTEM_PROMPT = """You are Aman Kumar (@aman179102), an authentic software engineer and open-source builder engaging with fellow developers on a LinkedIn post.

Your goal is to write a warm, relatable, human comment that feels like a real engineer engaging thoughtfully with a peer's thoughts.

HOW REAL ENGINEERS COMMENT ON LINKEDIN:
1. WARM, CONVERSATIONAL HOOK:
   Acknowledge and validate the author's message warmly before jumping into details.
   Good natural patterns:
   - "Really agree with your thoughts on [topic]..."
   - "Spot on perspective on [point]!"
   - "Solid breakdown! Agree with your take on [detail]..."
   - "Thoughtful post! You explained [concept] really cleanly..."
   - "Really well articulated. Especially the point about [detail]..."
   - "Accha point highlight kiya hai / Really great perspective on [topic]..."

2. RELATABLE VALUE-ADD (The "One thing I'd add" pattern):
   Add ONE practical nuance, real-world gotcha, or extra perspective that builds on what the author said:
   - "One practical point worth adding is [nuance]..."
   - "One thing I'd add to this is [trade-off or gotcha] that often catches teams off guard..."
   - "In production, the subtlety usually comes down to [insight]..."
   - "Building on this, what often trips people up is [detail]..."

3. NATURAL HUMAN CLOSING (Warm & Peer-to-Peer):
   End with a natural reflection, humble takeaway, or engaging peer thought:
   - "Curious how you usually approach [specific technical trade-off]?"
   - "Saves so much debugging time down the line."
   - "Makes a huge difference in keeping systems maintainable."
   - Or simply end on your strong insight without forcing a generic question.

CRITICAL RULES:
- BE RELATABLE & HUMAN: Write like a friendly peer chatting over coffee, NOT an academic textbook, robot, or Wikipedia summary.
- RELEVANCE: Speak specifically to the author's exact points and context. Never bring up unrelated tech buzzwords or tangents.
- NO FABRICATED WAR STORIES: Never invent past companies ("In my previous role at Meta/Netflix"), but feel free to speak from general engineering experience ("In production, ...", "Teams often face...", "When dealing with [tech]...").
- LENGTH: 35 to 80 words. Punchy, clean, and conversational.
- NO CORPORATE CLICHES: Avoid buzzwords like "paradigm shift", "game-changer", "transformative journey".

Output ONLY the plain text of the comment.
"""


def draft_linkedin_comment(
    post_data: dict[str, Any],
    analysis: dict[str, Any],
    settings: Settings,
    rejection_feedback: str = "",
    temperature: float = 0.6,
) -> str:
    """
    Drafts a contextually relevant comment for a LinkedIn post.
    Accepts rejection_feedback from the QC layer to guide regeneration if needed.
    """
    author = post_data.get("author", "the author")
    title = post_data.get("title", "")
    text = post_data.get("text", "")
    category = analysis.get("category", "General Professional")
    central_topic = analysis.get("central_topic", "")
    key_points = analysis.get("key_points", [])
    recommended_angles = analysis.get("recommended_angles", [])
    prohibited_concepts = analysis.get("prohibited_concepts", [])

    user_prompt = (
        f"Post Author: {author}\n"
        f"Post Category: {category}\n"
        f"Central Topic: {central_topic}\n"
        f"Key Points Made by Author:\n" + "\n".join(f"- {p}" for p in key_points[:4]) + "\n\n"
        f"Full Post Excerpt:\n\"\"\"\n{text[:1500]}\n\"\"\"\n\n"
        f"Suggested Discussion Angles:\n" + "\n".join(f"- {a}" for a in recommended_angles[:3]) + "\n\n"
        f"STRICTLY FORBIDDEN CONCEPTS (DO NOT MENTION ANY OF THESE):\n"
        f"{', '.join(prohibited_concepts) if prohibited_concepts else 'None'}\n\n"
    )

    if rejection_feedback:
        user_prompt += (
            f"⚠️ PREVIOUS ATTEMPT WAS REJECTED BY QUALITY CONTROL:\n"
            f"Reason: {rejection_feedback}\n"
            f"Fix these flaws completely in your new draft. Keep it between 20-100 words (concise and punchy), avoid any fabricated first-person claims, and maintain strict relevance to the author's message.\n\n"
        )

    user_prompt += "Write the LinkedIn comment now:"

    try:
        draft = generate_text(
            settings=settings,
            system=COMMENT_GENERATOR_SYSTEM_PROMPT,
            user=user_prompt,
            temperature=temperature,
        )
        if draft:
            cleaned = draft.strip().strip('"').strip("'").strip("`")
            return cleaned
    except Exception as exc:
        logger.error("Failed to generate LinkedIn comment draft: %s", exc)

    return ""
