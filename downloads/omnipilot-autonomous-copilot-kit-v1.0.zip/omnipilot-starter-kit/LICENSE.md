# Commercial Software License Agreement: OmniPilot OS

**Copyright (c) 2026 Aman Kumar (@aman179102). All rights reserved.**

IMPORTANT: PLEASE READ THIS LICENSE AGREEMENT CAREFULLY BEFORE DOWNLOADING, INSTALLING, OR USING OMNIPILOT OS ("THE SOFTWARE").

---

### 1. Grant of License
Subject to the terms and conditions of this Agreement, the Author grants you (an individual or a single legal entity) a perpetual, worldwide, non-exclusive, non-transferable license to:
- Install and execute the Software on your own computers, servers, virtual machines, or cloud infrastructure.
- Customize, configure, and modify the source code solely for your own internal operational, commercial, or personal use.

### 2. Restrictions
You expressly agree NOT to:
- Sublicense, resell, rent, lease, redistribute, assign, host as a public multi-tenant SaaS service, or publicly share the raw source code or any packaged version thereof.
- Distribute or publish the Software in any public code repository, file hosting service, forum, or marketplace.
- Claim ownership or original authorship of the Software or its proprietary algorithms.

### 3. Ownership
The Author retains all intellectual property rights, copyright, and title in and to the Software, including any documentation, code samples, templates, and derivatives created by the Author.

### 4. Disclaimer of Warranty
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM OR OUT OF THE USE OF THE SOFTWARE.

### 5. Termination
This license is effective until terminated. It will terminate automatically without notice if you fail to comply with any provision of this agreement. Upon termination, you must cease all use and destroy all copies of the Software.

---

For licensing inquiries, commercial SaaS rights, or enterprise customizations, contact:
**Aman Kumar** | `https://aman179102.netlify.app`
